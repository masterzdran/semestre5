// IntroSincronismoComSemaphoreWin32.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include "..\..\Include\BeginThreadex.h"

int x;
HANDLE hSem;

DWORD WINAPI IncFunc(LPVOID args)
{
	int tmp;
	for(int i=0; i<50; i++){
		
		WaitForSingleObject(hSem, INFINITE);
		
		/* Inicio da regi�o critica */
		tmp = x;
		tmp++;
		x = tmp;
		/* Fim da regi�o critica */

		ReleaseSemaphore(hSem, 1, NULL);
	}
    return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE ht, ht2;
    DWORD	threadId, threadId2;
    x = 0;

	hSem = CreateSemaphore(NULL, 1, 1, NULL);
	if(hSem == NULL){
		_tprintf(TEXT("Erro na cria��o do Semaphore\n"));
		ExitProcess(0);
	}

   // Criar as duas tarefas
    ht  = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId);
    ht2 = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId2);

    //Esperar a termina��o das tarefas
    WaitForSingleObject(ht, INFINITE);
    WaitForSingleObject(ht2, INFINITE);
    _tprintf(TEXT("Terminei com o valor de x = %d\n"), x);

	CloseHandle(hSem);

	return 0;
}
