
#define _WIN32_WINNT  0x0400

#include <windows.h>
#include <Mmsystem.h>
#include <tchar.h>


// Entry Point da Aplica��o
int _tmain(int argc, _TCHAR* argv[])
{
  HANDLE hTimer;
  LARGE_INTEGER li;

  hTimer=CreateWaitableTimer(NULL,FALSE,NULL);
  const int nTimerUnitsPerSecond=10000000; // 10.000.000 unidades de 100 nanosegundos
  li.QuadPart=-(5*nTimerUnitsPerSecond);
  SetWaitableTimer(hTimer,&li,20*1000,NULL,NULL,FALSE);
  for (int i=0; i < 3;i++) {
      WaitForSingleObject(hTimer,INFINITE);
      //PlaySound(TEXT("SO.wav"),NULL,SND_FILENAME);
	  PlaySound(TEXT("MKD_fight.wav"),NULL,SND_FILENAME);
  }
  CancelWaitableTimer(hTimer);
  CloseHandle(hTimer);
  return 0;
} // end WinMain
