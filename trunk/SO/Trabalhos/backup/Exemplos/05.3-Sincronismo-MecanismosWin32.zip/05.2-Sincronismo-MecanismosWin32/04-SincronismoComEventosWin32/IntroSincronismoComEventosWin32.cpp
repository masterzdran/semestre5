// IntroSincronismoComEventosWin32.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <locale.h>
#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <StrSafe.h>

#include "..\..\Include\BeginThreadex.h"

int					x;
CRITICAL_SECTION	cs;
HANDLE				hEventoDeArranque;

DWORD WINAPI IncFunc(LPVOID args)
{
	int tmp;

	// esperar pela ordem de arranque
	_tprintf(TEXT("Esperando ordem de arranque.\n"));
	WaitForSingleObject(hEventoDeArranque, INFINITE);
	_tprintf(TEXT("Vou come�ar...\n"));

	for(int i=0; i<50; i++){
		
		EnterCriticalSection(&cs);
		/* Inicio da regi�o critica */
		tmp = x;
		tmp++;
		x = tmp;
		/* Fim da regi�o critica */
		LeaveCriticalSection(&cs);
	}
	_tprintf(TEXT("Terminei...\n"));
    return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE ht, ht2;
    DWORD	threadId, threadId2;
    x = 0;

	_tsetlocale(LC_ALL, TEXT("portuguese_portugal"));

	InitializeCriticalSection(&cs);

	hEventoDeArranque = CreateEvent(NULL, TRUE, FALSE, NULL);
	if(hEventoDeArranque == NULL){
		_tprintf(TEXT("Erro na cria��o do Evento.\n"));
		ExitProcess(0);
	}

   // Criar as duas tarefas
    ht  = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId);
    ht2 = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId2);

	_tprintf(TEXT("Carregue no enter para desbloquear as tarefas.\n"));

	TCHAR line[80];
	StringCchGets(line, 80);

	SetEvent(hEventoDeArranque);

    //Esperar a termina��o das tarefas
    WaitForSingleObject(ht, INFINITE);
    WaitForSingleObject(ht2, INFINITE);
    _tprintf(TEXT("Terminei com o valor de x = %d\n"), x);

	DeleteCriticalSection(&cs);
	CloseHandle(hEventoDeArranque);

	return 0;
}
