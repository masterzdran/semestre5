// IntroSincronismoComSemaforos.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "..\..\Include\Semaforo.h"
#include "..\..\Include\SesError.h"

int x;
Semaforo *Sem;

DWORD WINAPI IncFunc(LPVOID args)
{
	int tmp;
	for(int i=0; i<50; i++){
		/* Inicio da regi�o critica */
		Sem->Wait();

		tmp = x;
		tmp++;
		x = tmp;
		Sleep(1);

		Sem->Signal();
		/* Fim da regi�o critica */
	}
    return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE ht, ht2;
    DWORD	threadId, threadId2;
    x = 0;
	Sem = new Semaforo(1);

   // Criar as duas tarefas
    ht  = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId);
    ht2 = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId2);

    //Esperar a termina��o das tarefas
    WaitForSingleObject(ht, INFINITE);
    WaitForSingleObject(ht2, INFINITE);
    _tprintf(TEXT("Terminei com o valor de x = %d\n"), x);
	return 0;
}

