// IntroSincronismoComCriticalSectionsWin32.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include "..\..\Include\BeginThreadex.h"

int x;
CRITICAL_SECTION cs;

DWORD WINAPI IncFunc(LPVOID args)
{
	int tmp;
	for(int i=0; i<50; i++){
		
		EnterCriticalSection(&cs);
		/* Inicio da regi�o critica */
		tmp = x;
		tmp++;
		x = tmp;
		
		/* Fim da regi�o critica */
		LeaveCriticalSection(&cs);	
	}
    return 0;
}


int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE ht, ht2;
    DWORD	threadId, threadId2;
    x = 0;

	InitializeCriticalSection(&cs);

   // Criar as duas tarefas
    ht  = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId);
    ht2 = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId2);

    //Esperar a termina��o das tarefas
    WaitForSingleObject(ht, INFINITE);
    WaitForSingleObject(ht2, INFINITE);
    _tprintf(TEXT("Terminei com o valor de x = %d\n"), x);

	DeleteCriticalSection(&cs);

	return 0;
}
