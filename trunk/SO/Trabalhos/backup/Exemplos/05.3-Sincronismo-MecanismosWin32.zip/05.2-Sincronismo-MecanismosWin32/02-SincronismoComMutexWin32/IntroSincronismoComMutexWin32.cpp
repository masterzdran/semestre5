// IntroSincronismoComMutexWin32.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"



#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include "..\..\Include\BeginThreadex.h"

int x;
HANDLE hMutex;

DWORD WINAPI IncFunc(LPVOID args)
{
	int tmp;
	for(int i=0; i<50; i++){
		
		WaitForSingleObject(hMutex, INFINITE);
		/* Inicio da regi�o critica */
		tmp = x;
		tmp++;
		x = tmp;
		
		/* Fim da regi�o critica */
		ReleaseMutex(hMutex);
	}
    return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE ht, ht2;
    DWORD	threadId, threadId2;
    x = 0;

	hMutex = CreateMutex(NULL, FALSE, NULL);
	if(hMutex == NULL){
		_tprintf(TEXT("Erro na cria��o do mutex\n"));
		ExitProcess(0);
	}

   // Criar as duas tarefas
    ht  = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId);
    ht2 = chBEGINTHREADEX ( NULL, 0, IncFunc, NULL, NULL, &threadId2);

    //Esperar a termina��o das tarefas
    WaitForSingleObject(ht, INFINITE);
    WaitForSingleObject(ht2, INFINITE);
    _tprintf(TEXT("Terminei com o valor de x = %d\n"), x);

	CloseHandle(hMutex);

	return 0;
}
