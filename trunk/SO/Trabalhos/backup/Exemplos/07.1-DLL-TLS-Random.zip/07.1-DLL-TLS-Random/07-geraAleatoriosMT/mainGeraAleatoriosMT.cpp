#include <windows.h>
#include <locale.h>
#include <tchar.h>
#include <stdio.h>


#include "..\..\include\BeginThreadex.h"

#include "..\06-randomMT\random.h"



DWORD WINAPI threadProc(LPVOID thArg)
{
    TCHAR *fname = (TCHAR *)thArg;
return 0;
    FILE *fout;
    errno_t status = _tfopen_s(&fout, fname, _T("w")); //Ficheiro de output da sequ�ncia
    if (status != 0) 
        _tprintf(_T("Erro na criacao do ficheiro! (%d)"), GetLastError()); 
    
    for(int i=0; i < 70; i++ ) {
        int s = 
            Rand62();
        _ftprintf(fout, _T("i=%d ->%d\n"), i, s);
        Sleep(s);
    }

    //Fechar o ficheiro
    fclose(fout);

    return 0;
}


int _tmain(int argc, _TCHAR* argv[])
{
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));


    // Criar as tarefas
    HANDLE thr[3];
    DWORD thId;
    TCHAR *fileNameToThread[3] = {_T("thread1.txt"), _T("thread2.txt"), _T("thread3.txt")};

    for (int i=0; i < 3; ++i) {
        
        thr[i]=chBEGINTHREADEX(NULL, 0, (LPTHREAD_START_ROUTINE)threadProc, fileNameToThread[i], CREATE_SUSPENDED, &thId);
        if (thr[i] == NULL) 
            _tprintf(_T("Cria��o da tarefa %d (%d)\n"), i, GetLastError());
    }
  

    _tprintf(_T("Tarefas criadas. Esperar pelo t�rmino das tarefas.\n"));


    for (int i=0; i<3; ++i) {
        ResumeThread(thr[i]);
    }

    //Esperar que as tarefas terminem
    DWORD waitret = WaitForMultipleObjects( 3,          // number of handles in array
                                            thr,        // object-handle array
                                            TRUE,       // wait option
                                            INFINITE    // time-out interval
                                          );
    if ( waitret == WAIT_FAILED ) 
        _tprintf(_T("Erro no WaitForMultipleObjects (%d)\n"), GetLastError());

    // Falta fazer o CloseHandle das tarefas

    _tprintf(_T("Enter para terminar...\n"));

    _gettchar();
}
