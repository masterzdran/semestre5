
#include <windows.h> 
#include <stdio.h> 
#include <locale.h> 
#include <tchar.h> 

#include "..\..\Include\BeginThreadex.h"
#include "..\..\Include\SesError.h"
 


/*******************************************************************************************/
/* C�digo de Biblioteca com as fun��es a ser usado  pelos threads                          */
/*******************************************************************************************/

DWORD indxRnd=-1;   // �ndice da entrada TLS



//Fun��o de inicia��o do m�dulo
void ModuleTlsInit()
{
    if ((indxRnd = TlsAlloc()) == -1)  
      FatalErrorSystem(_T(" Fallha no TlsAlloc!"));
}


//Fun��o de Fecho do m�dulo
void ModuleTlsEnd()
{
	if(indxRnd!=-1)
		if( !TlsFree(indxRnd) ) 
            FatalErrorSystem(_T(" Fallha no TlsFree!"));
}


//Inicia��o de uma entrada TLS para um thread
int *ThreadTlsInit()
{
	int *p = new int[1];  // Espa�o no heap para a informa��o local ao thread
	*p = 1;               // Valor inicial da vari�vel
	if (! TlsSetValue(indxRnd, p)) 
        FatalErrorSystem(_T("TlsSetValue error!")); 
	return p;
}

//Termino de uma entrada TLS
void ThreadTlsClose()
{
	int* p = (int*)TlsGetValue(indxRnd); //Obter a entrada TLS
	if ( p ) { 
		delete p; 
		p=NULL;
		if ( !TlsSetValue(indxRnd, p) ) 
            FatalErrorSystem(_T("TlsSetValue error!")); 
	}
}


/********************/


//Solu��o que tem problemas de multrithread
int monoRand62(){
	static int sReg = 1;

	sReg = (sReg >> 1) | (((sReg & 0x2)^((sReg & 1)<< 1))?0x20:0);
	return sReg;
}


//Solu��o correcta que recorre ao TLS
int Rand62(){

	int* psReg = (int*)TlsGetValue(indxRnd);  // Obter a entrada TLS

	// Se p==NULL ent�o ainda n�o foi iniciada 
	if( psReg==NULL) 
        psReg = ThreadTlsInit();

	//usar a entrada Tls
	*psReg = (*psReg >> 1) | (((*psReg & 0x2)^((*psReg & 1)<< 1))?0x20:0);
	return *psReg;
}


/*********************************************************************************************/
/* C�digo do thread que usa o m�dulo anterior                                                */
/*********************************************************************************************/

void threadProc(TCHAR* fname)
{
    FILE * fout;
    errno_t status = _tfopen_s(&fout, fname,_T("w")); //Ficheiro de output da sequ�ncia
    if (status != 0) 
        FatalErrorSystem(_T("Erro na criacao do ficheiro!")); 


	//------ Resto do c�digo do thread --------
	int s;
	for(int i=0; i < 70; i++ ) {
        //_tfprintf(fout, _T("i=%d ->%d\n"), i, s=monoRand62());
		_ftprintf(fout, _T("i=%d ->%d\n"), i, s=Rand62());
		Sleep(s);
	}

	//Fechar o ficheiro
	fclose(fout);

	//Libertar a mem�ria do TLS
	ThreadTlsClose();
}

//---------------------------------------

int _tmain(int argc, _TCHAR* argv[])
{
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));

    HANDLE thr[3];
    DWORD thId;

    //Criar uma entrada no TLS e guard�-la em indxRnd
    //Ap�s a cria��o a entrada fica com o valor NULL para todos os threads.

    ModuleTlsInit(); 

    //Criar os threads
    thr[0]=chBEGINTHREADEX(NULL, 0, threadProc, _T("thread1.txt"), 0, &thId);
    thr[1]=chBEGINTHREADEX(NULL, 0, threadProc, _T("thread2.txt"), 0, &thId);
    thr[2]=chBEGINTHREADEX(NULL, 0, threadProc, _T("thread3.txt"), 0, &thId);


    _tprintf(_T("TLS e thread criados. Esperar pelo t�rmino dos threads.\n"));

    //Esperar que os threads terminem


    WaitForMultipleObjects(    3,     // number of handles in array
						       thr,   // object-handle array
                              TRUE,   // wait option
                          INFINITE    // time-out interval
                          );
    //Destruir a entrada TLS
    ModuleTlsEnd();

    _tprintf(_T("Threads terminados e TLS libertado. \nVer o resultado nos ficheiros thread1.txt, thread2.txt, etc\n"));

    _gettchar();
}
