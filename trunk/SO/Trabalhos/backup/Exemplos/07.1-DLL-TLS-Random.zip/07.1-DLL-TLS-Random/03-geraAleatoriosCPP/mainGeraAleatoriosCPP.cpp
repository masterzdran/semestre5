#include "..\01-random\random.h"

#include <stdio.h>
#include <locale.h>
#include <tchar.h>


int _tmain(int argc, _TCHAR* argv[])
{
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));


    _tprintf(_T("\n--- Gera n�meros aleat�rios em C++ ---\n\n"));

    for (int i = 0; i < 12; i++) {
        _tprintf(_T("N�mero aleat�rio %02d - %d\n"), i, Rand62() );
    }

    _gettchar();
}