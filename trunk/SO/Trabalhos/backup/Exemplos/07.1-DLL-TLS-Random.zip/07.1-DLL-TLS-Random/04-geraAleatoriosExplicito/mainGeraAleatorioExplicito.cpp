
#include <stdio.h>
#include <locale.h>
#include <tchar.h>

#include "..\01-random\random.h"



int _tmain(int argc, _TCHAR* argv[])
{
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));

    _tprintf(_T("\n--- Gera n�meros aleat�rios em C++ e com carregamento expl�cito ---\n\n"));

    TpRand62 pfuncRand62 = NULL;

    HINSTANCE hRandomDll = LoadLibrary(_T("Random"));
    if (hRandomDll == NULL) {
        _tprintf(_T("Erro ao carregar a DLL: %d\n"), GetLastError());
        getchar();
        return -1;
    }
    _tprintf(_T("Biblioteca RandomDll carregada no endere�o 0x%x\n"), hRandomDll);


    pfuncRand62 = (TpRand62)GetProcAddress(hRandomDll, "Rand62");
    if (pfuncRand62 == NULL) {
        _tprintf(_T("Erro ao determinar o endereco da fun�ao Rand62: %d\n"), GetLastError());
        _gettchar(); 
        return -1;
    }
    _tprintf(_T("Endere�o da fun��o Rand62 determinado (0x%x)\n\n"), pfuncRand62);

    for (int i = 0; i < 12; i++) {
        _tprintf(_T("N�mero aleat�rio %02d - %d\n"), i, pfuncRand62() );
    }

    _gettchar();        

    FreeLibrary(hRandomDll);

    return 0;
}