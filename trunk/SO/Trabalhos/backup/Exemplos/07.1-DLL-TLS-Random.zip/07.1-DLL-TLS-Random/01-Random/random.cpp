#define randomdll_build

#include "random.h"

#include <stdio.h>
#include <locale.h>
#include <tchar.h>


static int sReg = 1;


int WINAPI Rand62()
{

    sReg = (sReg >> 1) | (((sReg & 0x2)^((sReg & 1)<< 1))?0x20:0);
    return sReg;
}


/////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////// Fun��o DllMain ///////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved )
{
    BOOL Result = TRUE;

    _tsetlocale(LC_ALL, _T("portuguese_portugal"));


    switch (fdwReason) {
        case DLL_PROCESS_ATTACH:
            // A DDL est� a ser mapeada no espa�o de endere�amento do processo
            _tprintf(_T("Random.dll: A DDL est� a ser mapeada no espa�o de endere�amento do processo\n"));
            _tprintf(_T("Random.dll: 0x%p\n"), hinstDLL);
            break;

        case DLL_THREAD_ATTACH:
            // Est� a ser criada uma thread
            _tprintf(_T("Random.dll: Est� a ser criada uma thread\n"));
            break;

        case DLL_THREAD_DETACH:
            // Existe uma thread a terminar (sem ser atrav�s do TerminateThread
            _tprintf(_T("Random.dll: Existe uma thread a terminar (sem ser atrav�s do TerminateThread\n"));
            break;

        case DLL_PROCESS_DETACH:
            // A DLL est� a ser desmapeada do espa�o de endere�amento do processo
            _tprintf(_T("Random.dll: A DLL est� a ser desmapeada do espa�o de endere�amento do processo\n"));
            break;

        default:
            _tprintf(_T("Random.dll: DllMain chamada com um motivo desconhecido (%ld)\n"), fdwReason); 
            Result = FALSE;
    }
    return Result;
}