#include "stdafx.h"


CRITICAL_SECTION sectionAndSpinCount;


void iniciarCriticalSectionAndSpinCount() {

    InitializeCriticalSectionAndSpinCount(&sectionAndSpinCount, 4000);

    // Equivalente a:
    //InitializeCriticalSection(&sectionAndSpinCount);
    //SetCriticalSectionSpinCount(&sectionAndSpinCount, 4000);
}


DWORD WINAPI Inc05ComExmutCriticalSectionAndSpinCount(LPVOID args)
{
  
  for(int i=0; i<MaxX; ++i)
  {
    EnterCriticalSection( &sectionAndSpinCount );

      ++x;

    LeaveCriticalSection( &sectionAndSpinCount );
  }

  return 0;
}