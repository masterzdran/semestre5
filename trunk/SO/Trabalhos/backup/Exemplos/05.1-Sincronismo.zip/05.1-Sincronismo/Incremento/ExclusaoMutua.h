#ifndef ExclusaoMutua_h
#define ExclusaoMutua_h

#include <windows.h>

typedef int ZonaCritica;


void Entrar(BOOL yieldRequire=FALSE);

void Sair();

#endif // ExclusaoMutua_h