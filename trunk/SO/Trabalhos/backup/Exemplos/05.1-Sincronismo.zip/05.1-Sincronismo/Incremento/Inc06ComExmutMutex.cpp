#include "stdafx.h"


HANDLE mutex;


void iniciarMutex() {

    if ( (mutex=CreateMutex(NULL, FALSE, NULL))==NULL ) {

        FatalErrorSystem( TEXT("Erro ao iniciar o mutex") );
    }
}


DWORD WINAPI Inc06ComExmutMutex(LPVOID args)
{
  
  for(int i=0; i<MaxX; ++i)
  {
    WaitForSingleObject( mutex, INFINITE );

      ++x;

    ReleaseMutex( mutex );
  }

  return 0;
}