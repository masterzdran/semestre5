// Incremento.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

const int NumThreads = 2;

const int MaxX = 50000000;

volatile int x;

void init();

LPTHREAD_START_ROUTINE menu();

void showTimes(HANDLE * hThread, int numThreads);

int _tmain(int argc, _TCHAR* argv[])
{
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));

    init();

    LPTHREAD_START_ROUTINE func = menu();

    _tprintf( TEXT("\nVai iniciar a cria��o das tarefas (%d tarefas)...\n\n"), NumThreads );


    HANDLE htThreads[NumThreads];
    DWORD idThreads[NumThreads];

    for(int idx=0; idx<NumThreads; ++idx) {

        htThreads[ idx ] = chBEGINTHREADEX( NULL, 0, func, NULL, NULL, &idThreads[ idx ] );
    }

    WaitForMultipleObjects( NumThreads, htThreads, TRUE, INFINITE);

    _tprintf( TEXT("Terminou com x = %d\n"), x );

    _tprintf( TEXT("Tempos de execu��o das threads (HH:MM:SS,sss).\n") );

    showTimes( htThreads, NumThreads );

    _tprintf( TEXT("Prima um a tecla para terminar.") );
    _gettch();

    return 0;
}


void init()
{
    // Implementa��o do sincronismo na vers�o 4
    iniciarCriticalSection();
    
    // Implementa��o do sincronismo na vers�o 5
    iniciarCriticalSectionAndSpinCount();

    // Implementa��o do sincronismo na vers�o 6
    iniciarMutex();

    // Implementa��o do sincronismo na vers�o 7
    iniciarSemaphore();
}


void toggleProcessAfinity();
void printOptionsState();
void toggleProcessPriorityBoost();

LPTHREAD_START_ROUTINE menu() 
{
    _tprintf( TEXT("Qual a vers�o que deseja testar: \n") );
    _tprintf( TEXT(" 1 - Sem exclus�o\n") );
    _tprintf( TEXT(" 2 - Com exclus�o com TestAndSet sem yield\n") );
    _tprintf( TEXT(" 3 - Com exclus�o com TestAndSet com yield\n") );
    _tprintf( TEXT(" 4 - Com exclus�o com CRITICAL_SECTION\n") );
    _tprintf( TEXT(" 5 - Com exclus�o com CRITICAL_SECTION and spin count\n") );
    _tprintf( TEXT(" 6 - Com exclus�o com Mutex\n") );
    _tprintf( TEXT(" 7 - Com exclus�o com Semaphore\n") );
    _tprintf( TEXT(" 8 - Com exclus�o com InterlockedIncrement\n") );

    _tprintf( TEXT("\n") );

    printOptionsState();

    TCHAR ch=0;

    do {
    
        ch = _gettch();

        switch ( ch ) {
            case 'p': // activa a afinidade do processo para o primeiro processador
            case 'P':
                toggleProcessAfinity();
                printOptionsState();
                break;
            case 'b':
            case 'B':
                toggleProcessPriorityBoost();
                printOptionsState();
                break;
        }

    } while( (ch<TEXT('1')) || (ch>TEXT('8')) );

    _tprintf( TEXT("\n\nA op��o escolhida foi %c\n"), ch );

    switch ( ch ) {

        case '1': return Inc01SemExmutV1; 
        case '2': return Inc02ComExmutTestAndSset; 
        case '3': return Inc03ComExmutTestAndSsetYield;
        case '4': return Inc04ComExmutCriticalSection;
        case '5': return Inc05ComExmutCriticalSectionAndSpinCount;
        case '6': return Inc06ComExmutMutex;
        case '7': return Inc07ComExmutSemaphore;
        case '8': return Inc08ComInterlockedIncrement;
    }

    return NULL;
} // end menu

static BOOL afinityToOneCPU = FALSE;
static BOOL PriorityBoostDisable = FALSE;

void printOptionsState() 
{
    static TCHAR *strProcessAfinity[] = {
        TEXT(" P - Process affinity: [all CPUs]"),
        TEXT(" P - Process affinity: [one CPU] ")
    };

    static TCHAR *strPriorityBoost[] = {
        TEXT(" B - Process Priority Boost: [enable] "),
        TEXT(" B - Process Priority Boost: [disable]")
    };


    _tprintf( TEXT("\r%s | %s"), 
              strProcessAfinity[afinityToOneCPU],
              strPriorityBoost[PriorityBoostDisable]);
}

void toggleProcessAfinity() 
{
    // toggle affinity
    afinityToOneCPU = !afinityToOneCPU;


    DWORD processAfinityMask;
    DWORD systemAffinityMask;

    if ( !GetProcessAffinityMask(GetCurrentProcess(), 
                                 &processAfinityMask, 
                                 &systemAffinityMask) ) {
        ReportErrorSystem(TEXT("Erro na obten��o da afinidade do processo"));
    }

    if (afinityToOneCPU) 
        processAfinityMask &= 1;
    else 
        processAfinityMask = systemAffinityMask;

    if ( !SetProcessAffinityMask(GetCurrentProcess(), processAfinityMask) ) {
        ReportErrorSystem(TEXT("Erro na altera��o da afinidade do processo"));
    } 
}


void toggleProcessPriorityBoost() 
{
    // toggle
    PriorityBoostDisable = !PriorityBoostDisable;

    if ( !SetProcessPriorityBoost(GetCurrentProcess(), PriorityBoostDisable) ) {
        ReportErrorSystem(TEXT("Erro na altera��o do Priority Boost do processo"));
    }
}


void showTimes(HANDLE hThread)
{
    union { // simplifies elapsed time calculation
        LONG64   li;
        FILETIME ft;
    } creationTime, exitTime, elapsedTime;


    FILETIME kernelTime;
    FILETIME userTime;

    if ( GetThreadTimes(hThread, &creationTime.ft, &exitTime.ft, &kernelTime, &userTime)==0 ) {

        ReportErrorSystem( TEXT("Erro ao obter os tempos de execu��o da tarefa %h"), hThread );
    }
    else
    {
        SYSTEMTIME syElapsedTime;
        SYSTEMTIME syKernelTime;
        SYSTEMTIME syUserTime;

        elapsedTime.li = exitTime.li - creationTime.li; 

        FileTimeToSystemTime( &elapsedTime.ft, &syElapsedTime);
        FileTimeToSystemTime( &kernelTime, &syKernelTime);
        FileTimeToSystemTime( &userTime, &syUserTime);

        _tprintf( 
          TEXT("Tempo de execu��o ------ %02d:%02d:%02d,%03d\n"), 
          syElapsedTime.wHour, 
          syElapsedTime.wMinute, 
          syElapsedTime.wSecond, 
          syElapsedTime.wMilliseconds );

        _tprintf( 
           TEXT("Tempo em modo kernel --- %02d:%02d:%02d,%03d\n"), 
           syKernelTime.wHour, 
           syKernelTime.wMinute, 
           syKernelTime.wSecond, 
           syKernelTime.wMilliseconds );

        _tprintf(
          TEXT("Tempo em modo user ----- %02d:%02d:%02d,%03d\n"),
          syUserTime.wHour, 
          syUserTime.wMinute, 
          syUserTime.wSecond, 
          syUserTime.wMilliseconds );
    }
}


void showTimes(HANDLE * hThread, int numThreads)
{
    for(int idxThread=0; idxThread<numThreads; ++idxThread)
    {
        _tprintf( TEXT("Thread %d\n"), idxThread );
        showTimes( hThread[ idxThread ] );
    }
}