
extern volatile int x;

extern const int MaxX;