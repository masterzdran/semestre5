#include "stdafx.h"



DWORD WINAPI Inc08ComInterlockedIncrement(LPVOID args)
{

  for(int i=0; i<MaxX; ++i) {

      InterlockedIncrement((LONG*)&x); 
  }

  return 0;
}