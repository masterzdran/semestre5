#include "stdafx.h"

//
//    1. Testar a thread s� com a instru��o ++x dentro do for (50000000 itera��es)
//    2. Executar a vers�o release e comparar c�digo gerado pelo compilador com a 
//       vers�o debug
//    3. Activar o ciclo
//       while (recursoOcupado==true) ;
//         recursoOcupado=true;
//       - observar que tanto o teste sobre a flag recursoOcupado como a manipula��o 
//         da vari�vel x s�o feitas nos registos resultado (final sempre 50000000)
//       - adicionar volatile na declara��o de x e verificar que em release a 
//         aplica��o por vezes entra em deadlock (ver assembly)
//       - declarar a flag recursoOcupado como volatile e a aplica��o termina sempre 
//         verificando perda de incrementos
//


volatile bool recursoOcupado = false;



DWORD WINAPI Inc01SemExmutV1(LPVOID args)
{
    for (int i=0; i<MaxX; ++i) {

        while (recursoOcupado==true)
            ;
        
        recursoOcupado=true;

        //int tmp = x;
        //Sleep(0);
        //tmp++;
        ////Sleep(0);
        //x = tmp;
        
        ++x;

        recursoOcupado=false;
  }

  return 0;
}
