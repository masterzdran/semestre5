#include "stdafx.h"



extern ZonaCritica zona;

DWORD WINAPI Inc03ComExmutTestAndSsetYield(LPVOID args)
{
  
  for(int i=0; i<MaxX; ++i)
  {
    Entrar(TRUE);

      ++x;

    Sair();
  }

  return 0;
}