#ifndef Inc07ComExmutSemaphore_h
#define Inc07ComExmutSemaphore_h


#include <windows.h>


void iniciarSemaphore();

DWORD WINAPI Inc07ComExmutSemaphore(LPVOID args);

#endif // Inc07ComExmutSemaphore_h