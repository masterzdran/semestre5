#ifndef Inc01SemExmutV1_h
#define Inc01SemExmutV1_h

#include <windows.h>

DWORD WINAPI Inc01SemExmutV1(LPVOID args);

#endif // Inc01SemExmutV1_h