#ifndef Inc05ComExmutCriticalSectionAndSpinCount_h
#define Inc05ComExmutCriticalSectionAndSpinCount_h

#include <windows.h>

void iniciarCriticalSectionAndSpinCount();

DWORD WINAPI Inc05ComExmutCriticalSectionAndSpinCount(LPVOID args);

#endif // Inc05ComExmutCriticalSectionAndSpinCount_h