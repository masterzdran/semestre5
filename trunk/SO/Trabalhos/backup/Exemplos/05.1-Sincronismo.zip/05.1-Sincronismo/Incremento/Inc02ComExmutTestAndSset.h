#ifndef Inc02ComExmutTestAndSset_h
#define Inc02ComExmutTestAndSset_h

#include <windows.h>

DWORD WINAPI Inc02ComExmutTestAndSset(LPVOID args);

#endif // Inc02ComExmutTestAndSset_h