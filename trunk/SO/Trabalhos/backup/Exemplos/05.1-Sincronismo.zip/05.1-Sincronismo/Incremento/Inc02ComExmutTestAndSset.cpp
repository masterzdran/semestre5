#include "stdafx.h"




DWORD WINAPI Inc02ComExmutTestAndSset(LPVOID args)
{
 
  for(int i=0; i<MaxX; ++i)
  {

    Entrar(FALSE);
 
      ++x;

    Sair();
  }

  return 0;
}