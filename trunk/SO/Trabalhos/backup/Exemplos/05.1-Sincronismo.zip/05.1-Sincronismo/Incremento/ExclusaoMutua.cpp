#include "stdafx.h"

int TestAndSet(ZonaCritica& zona)
{
  int x = 1;
  __asm{
    // x <-> *zona
         mov  eax, dword ptr [zona] 
         mov  ecx, dword ptr [x] 
    lock xchg ecx, dword ptr [eax] 
         mov  dword ptr [x], ecx 
   }
  return x == 0 ? 1 : 0; 
}


ZonaCritica zona = 0;

volatile long g_fResourceInUse = FALSE;


void Entrar(BOOL yieldRequire) 
{
    //while( !TestAndSet(zona) ) {

    // Vers�o test-and-set utilizando InterlockExchange
    while (InterlockedExchange(&g_fResourceInUse, TRUE) == TRUE) {
    		
        if ( yieldRequire==TRUE ) {
            Sleep(0);
        }
    }
}


void Sair() {
    
    //zona = 0;

    // Vers�o test-and-set utilizando InterlockCompareExchange      
    InterlockedExchange(&g_fResourceInUse, FALSE);
}