#include "stdafx.h"


HANDLE sem;


void iniciarSemaphore() {

    if ( (sem=CreateSemaphore( NULL, 1, 1, NULL))==NULL ) {
        
        FatalErrorSystem( TEXT("Erro ao iniciar o sem�foro") );
    }
}


DWORD WINAPI Inc07ComExmutSemaphore(LPVOID args)
{
  
  for(int i=0; i<MaxX; ++i)
  {
    WaitForSingleObject( sem, INFINITE );


      ++x;

    ReleaseSemaphore( sem, 1, NULL);
  }

  return 0;
}