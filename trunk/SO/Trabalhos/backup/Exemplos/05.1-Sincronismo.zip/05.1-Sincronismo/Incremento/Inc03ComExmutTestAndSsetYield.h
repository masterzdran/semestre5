#ifndef Inc03ComExmutTestAndSsetYield_h
#define Inc03ComExmutTestAndSsetYield_h

#include <windows.h>

DWORD WINAPI Inc03ComExmutTestAndSsetYield(LPVOID args);

#endif // Inc03ComExmutTestAndSsetYield_h