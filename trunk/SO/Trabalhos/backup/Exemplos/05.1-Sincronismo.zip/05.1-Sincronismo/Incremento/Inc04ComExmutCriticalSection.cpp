#include "stdafx.h"


CRITICAL_SECTION section;


void iniciarCriticalSection() {
    InitializeCriticalSection( &section );
}


DWORD WINAPI Inc04ComExmutCriticalSection(LPVOID args)
{
  
  for(int i=0; i<MaxX; ++i)
  {
    EnterCriticalSection( &section );

     ++x;

    LeaveCriticalSection( &section );
  }

  return 0;
}