#ifndef Inc04ComExmutCriticalSection_h
#define Inc04ComExmutCriticalSection_h

#include <windows.h>

void iniciarCriticalSection();

DWORD WINAPI Inc04ComExmutCriticalSection(LPVOID args);

#endif // Inc04ComExmutCriticalSection_h