// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

// TODO: reference additional headers your program requires here

#include <windows.h>
#include <locale.h>
#include <conio.h>
#include <ctype.h>

#include "..\..\Include\BeginThreadex.h"
#include "..\..\Include\SesError.h"

#include "Globals.h"

#include "ExclusaoMutua.h"

#include "Inc01SemExmutV1.h"
#include "Inc02ComExmutTestAndSset.h"
#include "Inc03ComExmutTestAndSsetYield.h"
#include "Inc04ComExmutCriticalSection.h"
#include "Inc05ComExmutCriticalSectionAndSpinCount.h"
#include "Inc06ComExmutMutex.h"
#include "Inc07ComExmutSemaphore.h"
#include "Inc08ComInterlockedIncrement.h"
