#ifndef Inc08ComInterlockedIncrement_h
#define Inc08ComInterlockedIncrement_h

#include <windows.h>

DWORD WINAPI Inc08ComInterlockedIncrement(LPVOID args);

#endif // Inc08ComInterlockedIncrement_h