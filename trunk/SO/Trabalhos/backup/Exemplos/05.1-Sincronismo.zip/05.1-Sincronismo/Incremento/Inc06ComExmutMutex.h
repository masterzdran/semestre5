#ifndef Inc06ComExmutMutex_h
#define Inc06ComExmutMutex_h

#include <windows.h>

void iniciarMutex();

DWORD WINAPI Inc06ComExmutMutex(LPVOID args);

#endif // Inc06ComExmutMutex_h