#include <windows.h>
#include <stdio.h>

#include "..\..\include\SesError.h"



BOOL printFile(const char *fileName) 
{
    HANDLE hFile = CreateFile(
        fileName,                            // file name
        GENERIC_READ,                        // access mode
        0,                                   // share mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
        NULL,                                // Security
        OPEN_EXISTING,                       // how to create
        FILE_ATTRIBUTE_NORMAL,               // file attributes
        NULL                                 // handle to template file
    );
    if (hFile == INVALID_HANDLE_VALUE) {
        ReportErrorSystem("Erro na abertura do ficheiro <%s>:",fileName);
        return FALSE;
    }

    HANDLE fileMapHandle = CreateFileMapping(
        hFile,                              // handle to file
        NULL,                               // security
        PAGE_READONLY,                      // protection
        0,                                  // high-order
        0,                                  // low-order
        NULL                                // object name
    );
    if (fileMapHandle == NULL) {
        ReportErrorSystem("Erro na abertura do FileMap");
        CloseHandle(hFile);
        return FALSE;
    }

    char *lpMapAddress = (char *)MapViewOfFile(
        fileMapHandle,                      // Handle to mapping object
        FILE_MAP_READ,                      // Read/write permission 
        0,                                  // dwFileOffsetHigh
        0,                                  // dwFileOffsetLow
        0                                   // dwNumberOfBytesToMap
    );
    if (lpMapAddress == NULL) { 
        ReportErrorSystem("Erro no MapViewOfFile.");
        CloseHandle(hFile);
        CloseHandle(fileMapHandle);
        return FALSE;
    } 

    DWORD fileSize = GetFileSize(hFile, NULL);
    if ( fileSize == INVALID_FILE_SIZE) {
        ReportErrorSystem("Erro no GetFileSize."); 
        UnmapViewOfFile(lpMapAddress);
        CloseHandle(hFile);
        CloseHandle(fileMapHandle);            
        return FALSE;
    }

    for (DWORD i = 0; i < fileSize; ++i) 
        putchar(lpMapAddress[i]);

    // Para ficheiros muito grandes n�o funciona pois o buffer de stdout n�o o suporta
    // Fazer por blocos 
    //HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    //if ( hStdOut == INVALID_HANDLE_VALUE )
    //    FatalErrorSystem("Erro no GetStdHandle."); 

    //DWORD nBytesWritten;
    //BOOL result = WriteFile(hStdOut, lpMapAddress, fileSize, &nBytesWritten, NULL);
    //if ( result == 0 )
    //    FatalErrorSystem("Erro no WriteFile."); 

    // libertar recursos
    if ( !UnmapViewOfFile(lpMapAddress) )
        ReportErrorSystem("Erro no UnmapViewOfFile.");
    if ( ! CloseHandle(fileMapHandle) )
        ReportErrorSystem("Erro no CloseHandle(fileMapHandle).");
    if ( ! CloseHandle(hFile) )
        ReportErrorSystem("Erro no CloseHandle(hFile).");
    
    return TRUE;
} // end printFile



BOOL printFileSEH1(const char *fileName) 
{
    // Iniciar todas as vari�veis indicando a situa��o de erro
    HANDLE hFile         = INVALID_HANDLE_VALUE;
    HANDLE fileMapHandle = NULL;
    char  *lpMapAddress  = NULL;

    __try {
        hFile = CreateFile(
            fileName,                            // file name
            GENERIC_READ,                        // access mode
            0,                                   // share mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            NULL,                                // Security
            OPEN_EXISTING,                       // how to create
            FILE_ATTRIBUTE_NORMAL,               // file attributes
            NULL                                 // handle to template file
        );
        if (hFile == INVALID_HANDLE_VALUE) {
            ReportErrorSystem("Erro na abertura do ficheiro <%s>:",fileName);
            return FALSE;
        }

        fileMapHandle = CreateFileMapping(
            hFile,                              // handle to file
            NULL,                               // security
            PAGE_READONLY,                      // protection
            0,                                  // high-order DWORD of size
            0,                                  // low-order DWORD of size
            NULL                                // object name
        );
        if (fileMapHandle == NULL) {
            ReportErrorSystem("Erro na abertura do FileMap");
            return FALSE;
        }

        lpMapAddress = (char *)MapViewOfFile(
            fileMapHandle,                      // Handle to mapping object
            FILE_MAP_READ,                      // Read/write permission 
            0,                                  // dwFileOffsetHigh
            0,                                  // dwFileOffsetLow
            0                                   // dwNumberOfBytesToMap
        );
        if (lpMapAddress == NULL) { 
            ReportErrorSystem("Erro no MapViewOfFile.");
            return FALSE;
        } 

        DWORD fileSize = GetFileSize(hFile, NULL);
        if ( fileSize == INVALID_FILE_SIZE) {
            ReportErrorSystem("Erro no GetFileSize."); 
            return FALSE;
        }

        for (DWORD i = 0; i < fileSize; ++i) 
            putchar(lpMapAddress[i]);

        return TRUE;
    }
    __finally {
        // libertar recursos
        if ( lpMapAddress != NULL )
            if ( !UnmapViewOfFile(lpMapAddress) )
                ReportErrorSystem("Erro no UnmapViewOfFile.");
        if ( fileMapHandle != NULL )
            if ( ! CloseHandle(fileMapHandle) )
                ReportErrorSystem("Erro no CloseHandle(fileMapHandle).");
        if ( hFile != INVALID_HANDLE_VALUE )
            if ( ! CloseHandle(hFile) )
              ReportErrorSystem("Erro no CloseHandle(hFile).");
    } // end __finally
} // end printFileSEH1


BOOL printFileSEH2(const char *fileName) 
{
    // Iniciar todas as vari�veis indicando a situa��o de erro
    HANDLE hFile         = INVALID_HANDLE_VALUE;
    HANDLE fileMapHandle = NULL;
    char  *lpMapAddress  = NULL;

    BOOL   retValue      = FALSE;

    __try {
        hFile = CreateFile(
            fileName,                            // file name
            GENERIC_READ,                        // access mode
            0,                                   // share mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            NULL,                                // Security
            OPEN_EXISTING,                       // how to create
            FILE_ATTRIBUTE_NORMAL,               // file attributes
            NULL                                 // handle to template file
        );
        if (hFile == INVALID_HANDLE_VALUE) {
            ReportErrorSystem("Erro na abertura do ficheiro <%s>:",fileName);
            __leave;
        }

        fileMapHandle = CreateFileMapping(
            hFile,                              // handle to file
            NULL,                               // security
            PAGE_READONLY,                      // protection
            0,                                  // high-order
            0,                                  // low-order
            NULL                                // object name
        );
        if (fileMapHandle == NULL) {
            ReportErrorSystem("Erro na abertura do FileMap");
            __leave;
        }

        lpMapAddress = (char *)MapViewOfFile(
            fileMapHandle,                      // Handle to mapping object
            FILE_MAP_READ,                      // Read/write permission 
            0,                                  // dwFileOffsetHigh
            0,                                  // dwFileOffsetLow
            0                                   // dwNumberOfBytesToMap
        );

        if (lpMapAddress == NULL) { 
            ReportErrorSystem("Erro no MapViewOfFile.");
            __leave;
        } 

        DWORD fileSize = GetFileSize(hFile, NULL);
        if ( fileSize == INVALID_FILE_SIZE) {
            ReportErrorSystem("Erro no GetFileSize."); 
            __leave;
        }

        for (DWORD i = 0; i < fileSize; ++i) 
            putchar(lpMapAddress[i]);

         retValue = TRUE;
    }
    __finally {
        // libertar recursos
        if ( lpMapAddress != NULL )
            if ( !UnmapViewOfFile(lpMapAddress) )
                ReportErrorSystem("Erro no UnmapViewOfFile.");
        if ( fileMapHandle != NULL )
            if ( ! CloseHandle(fileMapHandle) )
                ReportErrorSystem("Erro no CloseHandle(fileMapHandle).");
        if ( hFile != INVALID_HANDLE_VALUE )
            if ( ! CloseHandle(hFile) )
              ReportErrorSystem("Erro no CloseHandle(hFile).");
    } // end __finally
    return retValue;
} // end printFileSEH2


void main() 
{
    char *file = "FileTeste.txt";

    //printFile(file);
    //printFileSEH1(file);
    printFileSEH2(file);
    
    getchar();
}
