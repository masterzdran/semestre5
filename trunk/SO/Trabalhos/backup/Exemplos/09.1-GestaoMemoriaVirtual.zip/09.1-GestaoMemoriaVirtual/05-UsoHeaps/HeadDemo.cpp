
//Exemplo de aplica��o de um Heap. A classe HeapObject poder� ser usada como classe base de uma outra
//cujas cujos operadores NEW e DELETE estejam sobrecarregados para utilizarem um heap privado.


#include<stdio.h>
#include<windows.h>
#include<memory>

class HeapObject
{
private:
  static HANDLE HeapHnd;

protected:

  char Data[1024];

public:
	        HeapObject();
  virtual	~HeapObject();
  void* operator new(size_t const Sz);
  void operator delete(void* const p);

  void DoSomething();
};



HANDLE HeapObject::HeapHnd = INVALID_HANDLE_VALUE;	//No heap at start

HeapObject::HeapObject()
{
}

HeapObject::~HeapObject()
{
}

void* HeapObject::operator new(size_t const Sz)
{
 if (HeapHnd == INVALID_HANDLE_VALUE)
 {	
	 HeapHnd =  HeapCreate(0,1024,0);
	 if( HeapHnd==NULL) 
	 { HeapHnd = INVALID_HANDLE_VALUE; return NULL;}
 }
 return HeapAlloc(HeapHnd,HEAP_ZERO_MEMORY,Sz);
}


void  HeapObject::operator delete(void* const p)
{
  HeapFree(	HeapHnd, 0, p);
}

void HeapObject::DoSomething()
{
	Data[0]=Data[1023]='5';
}




int main()
{ 
  HeapObject A;
  
  HeapObject *pH,*pH2;

  pH = new HeapObject();

  A.DoSomething();
  pH->DoSomething();

  delete pH;
	
  pH2 = new HeapObject();
  
  pH2->DoSomething();
  delete pH2;
	
return 0;
}