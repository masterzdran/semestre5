
#include <windows.h>

#include <stdio.h>



void ShowSystemInfo()
{
  SYSTEM_INFO SysInfo;

  GetSystemInfo(&SysInfo);	//Get System Info


  printf("Page Size = %ld\n",SysInfo.dwPageSize); 
  printf("Allocation Granularity = %ld\n", SysInfo.dwAllocationGranularity);

  printf("Minimum Application Address = 0x%p\n",SysInfo.lpMinimumApplicationAddress); 

  printf("Maximum Application Address = 0x%p\n",SysInfo.lpMaximumApplicationAddress); 

  printf("Active Processor Mask = %lx\n",SysInfo.dwActiveProcessorMask); 

  printf("Number Of Processors = %lx\n",SysInfo.dwNumberOfProcessors); 

  printf("Arquitectura ");
  switch( SysInfo.wProcessorArchitecture ) {
      case PROCESSOR_ARCHITECTURE_UNKNOWN:  printf("Desconhecida\n"); break;
      case PROCESSOR_ARCHITECTURE_INTEL:    printf("Intel\n"); break;
      case PROCESSOR_ARCHITECTURE_IA64:     printf("IA64\n"); break;
      case PROCESSOR_ARCHITECTURE_AMD64:    printf("AMD64\n"); break;
  }

}


void main()
{
    ShowSystemInfo();
    getchar();
}