
//Este programa mostra a situa��o global da gest�o de mem�ria do Sistema Operativo


#include <windows.h>

#include <stdio.h>

// Use to change the divisor from Kb to Mb.

#define DIV 1024
// #define DIV 1

char *divisor = "K";
// char *divisor = "";

// Handle the width of the field in which to print numbers this way to
// make changes easier. The asterisk in the print format specifier
// "%*ld" takes an int from the argument list, and uses it to pad and
// right-justify the number being formatted.

#define WIDTH 7

void main(int argc, char *argv[])
{
  MEMORYSTATUS stat;

  GlobalMemoryStatus (&stat);

  printf ("The MemoryStatus structure is %ld bytes long.\n",
          stat.dwLength);
  printf ("It should be %d.\n", sizeof (stat));
  printf ("%ld percent of memory is in use.\n",
          stat.dwMemoryLoad);
  printf ("There are %*ld total %sbytes of physical memory.\n",
          WIDTH, stat.dwTotalPhys/DIV, divisor);
  printf ("There are %*ld free %sbytes of physical memory.\n",
          WIDTH, stat.dwAvailPhys/DIV, divisor);
  printf ("There are %*ld total %sbytes of paging file.\n",
          WIDTH, stat.dwTotalPageFile/DIV, divisor);
  printf ("There are %*ld free %sbytes of paging file.\n",
          WIDTH, stat.dwAvailPageFile/DIV, divisor);
  printf ("There are %*ld total %sbytes of user mode portion of the virtual address.\n",
          WIDTH, stat.dwTotalVirtual/DIV, divisor);
  printf ("There are %*ld free %sbytes of user mode portion of the virtual address.\n",
          WIDTH, stat.dwAvailVirtual/DIV, divisor);

  printf("\n\nPress ENTER to finish.");

  getchar();
}
