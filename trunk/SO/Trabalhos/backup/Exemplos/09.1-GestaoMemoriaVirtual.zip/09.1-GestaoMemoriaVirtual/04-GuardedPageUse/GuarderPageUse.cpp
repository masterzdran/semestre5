#include <windows.h>
#include <stdio.h>
#include <stdlib.h>


/////////////////////////////////////////////////////////////////////////////////////////
// Vari�veis globais
////////////////////////////////////////////////////////////////////////////////////////

LPVOID lpvAddr;               // address of the test memory
DWORD dwPageSize;             // amount of memory to allocate.
SYSTEM_INFO sSysInfo;         // useful information about the system

/////////////////////////////////////////////////////////////////////////////////////////
// Filtro da excep��o
/////////////////////////////////////////////////////////////////////////////////////////

INT Filtro(DWORD dwCode, LPEXCEPTION_POINTERS info)
{
  LPVOID lpvResult;
  PEXCEPTION_RECORD pErec = info->ExceptionRecord;
  unsigned long* Einfo = pErec->ExceptionInformation;

  // If the exception is not a garded page fault, continue search.

  if (dwCode != EXCEPTION_GUARD_PAGE)
    {
      if (dwCode != EXCEPTION_ACCESS_VIOLATION)
	    printf("Exception code = %x; Continue search for handler.\n", dwCode);
	  else 
	    printf("Exception Access Violation = %x; Continue search for handler.\n", dwCode);

      return EXCEPTION_CONTINUE_SEARCH;
    }

  printf("Exception is a Garded page fault (%x): ProgAddress=%x DataAddress=%x Access = %s \n", dwCode,
	      (UINT_PTR)pErec->ExceptionAddress, Einfo[1], Einfo[0]==0 ? "Read":"Write" );

  //Colocar a p�gina em acesso normal

  lpvResult =  VirtualAlloc(lpvAddr,
	                        dwPageSize,
                            MEM_COMMIT,
                            PAGE_READWRITE );

   printf ("Page Gard Notification was %s.\n", lpvResult ? "successful" : "unsuccessful" );

  return EXCEPTION_CONTINUE_EXECUTION;
}


////////////////////////////////////////////////////////////////////////

int main()
{

  GetSystemInfo(&sSysInfo);     // populate the system information structure

  printf ("This computer has a page size of %d.\n", sSysInfo.dwPageSize);

  dwPageSize = sSysInfo.dwPageSize;

  // Instanciar um bloco de mem�ria novo com o atributo de page gard com
  // a dmens�o de uma p�gina fisica

  lpvAddr = VirtualAlloc(NULL, dwPageSize,
                         MEM_RESERVE | MEM_COMMIT,
                         PAGE_READONLY | PAGE_GUARD);

  if(lpvAddr == NULL) {
    printf("VirtualAlloc failed. Error: %ld\n",
           GetLastError());
    return 1;

  } else {
    fprintf(stderr, "Committed %lu bytes at address %lp\n",
            dwPageSize, lpvAddr);
  }


  //Acedder � p�gina pela 1� vez

  __try {

		int * p = (int*)lpvAddr;

		printf("First access to memory %x \n", (UINT_PTR)p);

		*p = 6;

		printf("Second access to memory %x \n", (UINT_PTR)p);

		*p = 7;

		printf("Third access to memory %x \n", (UINT_PTR)p);

		*p = 8;

  } __except (Filtro( GetExceptionCode(),GetExceptionInformation() ) )
  {
   // Neste caso n�o h� nada a fazer; o filtro toma conta do assunto
  }


  //Free memory allocated
  BOOL bSuccess;
  bSuccess = VirtualFree(
                         lpvAddr,            // base address of block
                         0,					 // Libertar toda a memoria deste bloco
                         MEM_RELEASE);       // Cancelar a reserva das paginas.                             

  printf ("Release was %s.\n", bSuccess ? "successful" : "unsuccessful" );


  return 0;
}

