
// A short program to demonstrate dynamic memory allocation using 
// a structured exception handler. 
//
//
//   NOTA:	1- Para uma desci��o mais detalhada do funcionamento deste programa
//             consulte o texto em "Reserving and Committing Memory.doc" na directoria do projecto.
//		       O exemplo foi extra�do do MSDN OCTOBER 2001.
//          2- O exemplo n�o � thread free.
//
//          MMB
//


#include <windows.h>
#include <stdio.h>              // for printf

//#define PAGELIMIT 80            // ask for this many pages
//#define PAGELIMIT 500000
#define PAGELIMIT 508768

LPTSTR lpNxtPage;               // address of the next page to ask for
DWORD dwPages = 0;              // count of pages gotten so far
DWORD dwPageSize;               // the page size on this computer



INT PageFaultExceptionFilter(DWORD dwCode, LPEXCEPTION_POINTERS info)
{
  LPVOID lpvResult;
  PEXCEPTION_RECORD pErec; 

  pErec = info->ExceptionRecord;
  unsigned long* Einfo = pErec->ExceptionInformation;

  // If the exception is not a page fault, exit.

  if (dwCode != EXCEPTION_ACCESS_VIOLATION)
    {
      printf("Exception code = %d\n", dwCode);
      return EXCEPTION_EXECUTE_HANDLER;
    }

  printf("Exception is a page fault: ProgAddress=%x DataAddress=%x Access = %s \n",
	     (UINT_PTR)pErec->ExceptionAddress, Einfo[1], Einfo[0]==0 ? "Read":"Write" );


  // If the reserved pages are used up, exit.

  if (dwPages >= PAGELIMIT)
    {
      printf("Exception: out of pages\n");
      return EXCEPTION_EXECUTE_HANDLER;
    }

  // Otherwise, commit another page.

  lpvResult = VirtualAlloc(
                           (LPVOID) lpNxtPage, // next page to commit
                           dwPageSize,         // page size, in bytes
                           MEM_COMMIT,         // allocate a committed page
                           PAGE_READWRITE);    // read/write access
  if (lpvResult == NULL )
    {
      printf("VirtualAlloc failed\n");
      return EXCEPTION_EXECUTE_HANDLER;
    } 
    else {
       printf ("Allocating another page.\n");
    }

  // Increment the page count, and advance lpNxtPage to the next page.

  dwPages++;
  lpNxtPage += dwPageSize;

  // Continue execution where the page fault occurred.

  return EXCEPTION_CONTINUE_EXECUTION;
}

VOID ErrorExit(LPTSTR oops)
{
  printf ("Error! %s with error code of %ld\n",
          oops, GetLastError ());
  exit (0);
}


VOID main(VOID)
{
  LPVOID lpvBase;               // base address of the test memory
  LPTSTR lpPtr;                 // generic character pointer
  BOOL bSuccess;                // flag
  DWORD i;                      // generic counter
  SYSTEM_INFO sSysInfo;         // useful information about the system


  GetSystemInfo(&sSysInfo);     // populate the system information structure

  printf ("This computer has a page size of %d.\n", sSysInfo.dwPageSize);

  dwPageSize = sSysInfo.dwPageSize;

  // Reserve pages in the process's virtual address space.

  SIZE_T dim = PAGELIMIT*dwPageSize;
  lpvBase = VirtualAlloc(
                         NULL,                 // system selects address
                         dim,                  // size of allocation
                         MEM_RESERVE,          // allocate reserved pages
                         PAGE_NOACCESS  );     // protection = no access
  if (lpvBase == NULL )
    ErrorExit("VirtualAlloc reserve failed");

  
  lpPtr = lpNxtPage = (LPTSTR) lpvBase;

  // Use structured exception handling when accessing the pages.
  // If a page fault occurs, the exception filter is executed to
  // commit another page from the reserved block of pages.

  for (i=0; i < PAGELIMIT*dwPageSize; i++)
    {
      __try
        {
          // Write to memory.

          lpPtr[i*dwPageSize] = 'a';
        }

      // If there's a page fault, commit another page and try again.

      __except ( PageFaultExceptionFilter( GetExceptionCode(),GetExceptionInformation() ) )
        {

          // This is executed only if the filter function is unsuccessful
          // in committing the next page.
            break;
        }

    }

    printf ("\n\nPress enter to terminate...\n");
    getchar();

  // Release the block of pages when you are finished using them.

  bSuccess = VirtualFree(
                         lpvBase,                     // base address of block
                         PAGELIMIT*dwPageSize,        // Dimens�o do bloco
                         MEM_DECOMMIT );              // decommit the pages                            

  printf ("Decommit was %s.\n", bSuccess ? "successful" : "unsuccessful" );

  bSuccess = VirtualFree(
                         lpvBase,            // base address of block
                         0,					 // Libertar o array todo
                         MEM_RELEASE);       // Cancelar a reserva das paginas.                             

  printf ("Release was %s.\n", bSuccess ? "successful" : "unsuccessful" );

}

/* NOTA: 1- Optou-se por fazer primeiro o DECOMIT para se constatar que a zona de mem�ria virtual
            continua reservada e portanto dispon�vel para futuros commits.

         2- Ao se usar VirtualFree para fazer MEM_RELEASE se a zona de mem�ria estiver commited
		    � primeiro feito o uncommit e depois o release da reserva de endere�os.

         3- Se colocar em coment�rio a 1� chamada ao VirtualFree, obt�m o mesmo resultado, i.e. a
		    2� chamada pode fazer uncommit e release ao mesmo tempo. Ver VirtualFree no MSDN.

*/
