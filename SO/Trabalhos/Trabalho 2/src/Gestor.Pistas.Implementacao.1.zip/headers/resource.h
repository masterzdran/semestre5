//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by D:\ElvisP\ISEL\SO\Trabalho2\Trab2_SO\Trab2_SO\resources\Trab2.rc
//
#define IDC_MYICON                      2
#define IDD_TRAB2_DIALOG                102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_TRAB2                       107
#define IDI_SMALL                       108
#define IDC_TRAB2                       109
#define IDR_MAINFRAME                   128
#define IDD_RUNWAY                      131
#define IDC_EDIT1                       1000
#define IDC_CHECK1                      1001
#define IDC_CHECK2                      1002
#define IDC_EDIT2                       1003
#define IDC_LIST1                       1004
#define IDC_BUTTON1                     1005
#define IDC_LIST3                       1006
#define IDC_BUTTON8                     1006
#define OPEN_RUNWAY2                    1006
#define IDC_EDIT3                       1007
#define IDC_LIST4                       1007
#define IDC_EDIT4                       1008
#define IDC_BUTTON2                     1009
#define IDC_BUTTON3                     1010
#define IDC_BUTTON4                     1011
#define IDC_EDIT5                       1011
#define NUMBER_TAKEOFF                  1011
#define IDC_BUTTON5                     1012
#define IDC_BUTTON6                     1013
#define IDC_BUTTON7                     1014
#define IDTerminarAvioes                1015
#define IDC_AT0                         1016
#define IDC_AT1                         1017
#define IDC_AT2                         1018
#define IDC_AT3                         1019
#define IDC_AT4                         1020
#define IDC_AT5                         1021
#define IDC_AT6                         1022
#define IDC_AT7                         1023
#define IDC_AT8                         1024
#define IDC_AT9                         1025
#define IDC_AT10                        1026
#define IDC_AT11                        1027
#define IDC_AT12                        1028
#define IDC_AT13                        1029
#define IDC_AT14                        1030
#define IDC_AT15                        1031
#define IDC_AT16                        1032
#define IDC_AT17                        1033
#define IDC_AT18                        1034
#define IDC_AT19                        1035
#define IDC_AT20                        1036
#define IDC_AT21                        1037
#define IDC_CREATE_LANDING              1038
#define IDC_CREATE_TAKEOFF              1039
#define NUMBER_LANDING                  1040
#define HURRICANE_WARNING               1041
#define IDC_AT22                        1042
#define IDC_AT23                        1043
#define IDC_AT24                        1044
#define IDC_AT25                        1045
#define IDC_DS0                         1046
#define IDC_DS1                         1047
#define IDC_DS2                         1048
#define IDC_DS3                         1049
#define IDC_DS4                         1050
#define IDC_DS5                         1051
#define IDC_DS6                         1052
#define IDC_DS7                         1053
#define IDC_DS8                         1054
#define IDC_DS9                         1055
#define IDC_DS10                        1056
#define IDC_DS11                        1057
#define IDC_DS12                        1058
#define IDC_DS13                        1059
#define IDC_DS14                        1060
#define IDC_DS15                        1061
#define IDC_DS16                        1062
#define IDC_DS17                        1063
#define IDC_DS18                        1064
#define IDC_DS19                        1065
#define IDC_DS20                        1066
#define IDC_DS21                        1067
#define IDC_DS22                        1068
#define IDC_DS23                        1069
#define IDC_DS24                        1070
#define IDC_DS25                        1071
#define OPEN_RUNWAY1                    1072
#define CLOSE_RUNWAY1                   1073
#define CLOSE_RUNWAY2                   1074
#define STATE_RUNWAY1                   1075
#define STATE_RUNWAY2                   1076
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1077
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
