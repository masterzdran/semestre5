#ifndef TRAB2_H
#define TRAB2_H
#pragma once

#include "headers\resource.h"
#endif