//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define ID_ICON                         102
#define IDR_MENU2                       105
#define IDD_MOUSEMOVE                   106
#define IDD_MOUSEMOVE1                  107
#define IDD_DIALOG1                     108
#define IDD_DEBUG                       108
#define IDD_LBUTTONDOWN                 109
#define IDC_EDITX                       1000
#define IDC_EDITY                       1001
#define IDC_CTRL                        1003
#define IDC_STATICX                     1004
#define IDC_STATICY                     1005
#define IDC_LMOUSEBUTTON                1006
#define IDC_COMBO1                      1006
#define IDC_MMOUSEBUTTON                1007
#define IDC_EDIT2                       1007
#define IDC_RMOUSEBUTTON                1008
#define IDC_EDIT1                       1008
#define IDC_SHIFT                       1009
#define IDC_FIRSTX                      1010
#define IDC_SECONDX                     1011
#define ID_EXIT                         40001
#define ID_TESTE1                       40002
#define ID_RECTA                        40003
#define ID_ELIPSE                       40004
#define ID_CLEAR                        40005
#define ID_USAR                         40006
#define IDC_CLEAR                       40014
#define ID_FILE_EXIT                    40015
#define ID_DRAW_ESPESSURA_1             40018
#define ID_DRAW_ESPESSURA_2             40019
#define ID_DRAW_ESPESSURA_3             40020
#define ID_DRAW_ESPESSURA_4             40021
#define IDC_MOUSEMOVE                   40022
#define IDM_DEBUG                       40023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40024
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
