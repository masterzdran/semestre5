
#include <windows.h>
#include <windowsx.h>
#include "resource.h"

#include <list>

//  VARIAVEIS GLOBAIS
#define SIZEBUF 80
char Buffer[SIZEBUF];
static int Cont=0;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

HWND        hWnd;




class ObjectoFigura
{
public:
    virtual void paint(HDC hdc) = 0;
};

class Recta: public ObjectoFigura
{
private:
    int x1;
    int y1;
    int x2;
    int y2;

public:
    Recta(int _x1, int _y1, int _x2, int _y2) { x1=_x1; y1=_y1;x2=_x2; y2=_y2; }
    void paint(HDC hdc) {
        ::MoveToEx(hdc, x2, y2, NULL);
        ::LineTo(hdc, x1, y1);
    }
};

class Elipse: public ObjectoFigura
{
private:
    int x1;
    int y1;
    int x2;
    int y2;

public:
    Elipse(int _x1, int _y1, int _x2, int _y2) { x1=_x1; y1=_y1;x2=_x2; y2=_y2; }
    void paint(HDC hdc) {
        Ellipse(hdc, x1, y1, x2, y2);
    }
};


HINSTANCE hinstance;

// Entry Point da Aplica��o
int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
					  LPSTR     lpCmdLine, int       nCmdShow )
{
    MSG         msg;
    WNDCLASSEX  wc;

    hinstance=hInstance;

    // Preenche a estrutura que descreve a classe da Window principal
    wc.style         = CS_HREDRAW | CS_VREDRAW;  // Permite que a Janela seja redimension�vel na Horizontal e Vertical
    wc.lpfnWndProc   = WndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(ID_ICON));
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU2);
    wc.lpszClassName = TEXT("Exemplo 1");
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.hIconSm       = LoadIcon(hInstance, MAKEINTRESOURCE(ID_ICON));


    // Regista a Classe da Window
    if ( !RegisterClassEx( &wc ) )
       return FALSE;


    // Cria a Janela Principal da aplica��o
    hWnd = CreateWindow(TEXT("Exemplo 1"), // Nome da Classe
                        TEXT("Aplica��o Exemplo 1"),   // Titulo da Barra do Menu Principal.
                        WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL, // Estilo da Janela
                        CW_USEDEFAULT, 0,    // Coordenadas Canto Sup Esq e Direito por defeito
                        CW_USEDEFAULT, 0,    // Largura e Altura por defeito
                        NULL,                // Overlapped windows n�o tem parent.
                        NULL,                // Usar o Menu da Classe
					    hInstance,           // Inst�ncia passada na fun��o WinMain().
                        NULL  );             // N�o � passada a estrutura para inicia��o da Janela

    if ( hWnd == NULL )
        return FALSE;

    // Mostrar a Janela
    ShowWindow( hWnd, nCmdShow );


    // Loop de Tratmento de Mensagens: Processa mensagens at� a aplica��o terminar
    while( GetMessage( &msg, NULL, 0, 0) )
    {
       TranslateMessage(&msg);
       DispatchMessage(&msg);
    }
    return( msg.wParam );
} // end WinMain




HWND hDlgMouseMove = NULL;
//HWND hDlgLButtonDown = NULL;
HWND hDlgDebug = NULL;

BOOL CALLBACK MouseMoveDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

    switch( message ) {
        case WM_COMMAND :
		    if (LOWORD(wParam) == IDOK) {
                DestroyWindow(hDlg);
                hDlgMouseMove = NULL;
			    return TRUE;
		    }
            break;

        case WM_APP:
            char buffer[32];
            sprintf(buffer, "%d", LOWORD(lParam));
            SetDlgItemText(hDlg, IDC_EDITX, buffer);
            SetDlgItemText(hDlg, IDC_STATICX, buffer);

            sprintf(buffer, "%d", HIWORD(lParam));
            SetDlgItemText(hDlg, IDC_EDITY, buffer);
            SetDlgItemText(hDlg, IDC_STATICY, buffer);

            CheckDlgButton(hDlg, IDC_CTRL, (wParam & MK_CONTROL)?BST_CHECKED:BST_UNCHECKED); 
            CheckDlgButton(hDlg, IDC_LMOUSEBUTTON, (wParam & MK_LBUTTON)?BST_CHECKED:BST_UNCHECKED); 
            CheckDlgButton(hDlg, IDC_MMOUSEBUTTON, (wParam & MK_MBUTTON)?BST_CHECKED:BST_UNCHECKED); 
            CheckDlgButton(hDlg, IDC_RMOUSEBUTTON, (wParam & MK_RBUTTON)?BST_CHECKED:BST_UNCHECKED); 
            CheckDlgButton(hDlg, IDC_SHIFT, (wParam & MK_SHIFT)?BST_CHECKED:BST_UNCHECKED); 
            //CheckDlgButton(hDlg, IDC_FIRSTX, (wParam & MK_XBUTTON1)?BST_CHECKED:BST_UNCHECKED); 
            //CheckDlgButton(hDlg, IDC_SECONDX, (wParam & MK_XBUTTON2)?BST_CHECKED:BST_UNCHECKED); 

            return TRUE;
    }
    return FALSE;
}

BOOL CALLBACK DebugDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{

    switch( message ) {
        case WM_COMMAND :
		    if (LOWORD(wParam) == IDOK) {
                DestroyWindow(hDlg);
                hDlgDebug = NULL;
			    return TRUE;
		    }
            break;

        case WM_APP:
            char buffer[64];
            RECT *rc = (RECT *)lParam;

            sprintf(buffer, "(%d, %d)", rc->left, rc->top);
            SetDlgItemText(hDlg, IDC_EDIT1, buffer);
            sprintf(buffer, "(%d, %d)", rc->right, rc->bottom);
            SetDlgItemText(hDlg, IDC_EDIT2, buffer);

            return TRUE;
    }
    return FALSE;
}



// Handler de Tratamento de Mensagens recebidas pela Window Principal
LRESULT CALLBACK WndProc( HWND   hWnd,      // Handle da window
                          UINT   uMsg,      // Tipo da mensagem
                          WPARAM wParam,    // Primeiro Parametro da Mensagem
                          LPARAM lParam )   // Segundo Parametro da Mensagem
{

    HDC hdc;
    PAINTSTRUCT ps;

    static std::list<ObjectoFigura*> desenho;

    static int pontox1=0;
    static int pontoy1=0;
    static int pontox2=0;
    static int pontoy2=0;

    static BOOL recta=FALSE;

    static BOOL elipse=FALSE;

    static BOOL emDesenho=FALSE;



    switch (uMsg) {


        case WM_COMMAND :
          switch ( LOWORD( wParam ) ) {
              case ID_TESTE1 : 
		        Cont++;
		        InvalidateRect(hWnd,NULL,TRUE);
                break;

	          case ID_EXIT :
		            DestroyWindow(hWnd);
		           break;

	          case ID_RECTA:
                  recta=TRUE;
                  elipse=FALSE;
		          break;

	          case ID_ELIPSE:
                  recta=FALSE;
                  elipse=TRUE;
		          break;

              case IDC_CLEAR:
                  desenho.erase(desenho.begin(),desenho.end());
	              InvalidateRect(hWnd,NULL,TRUE);
                  break;

              case IDC_MOUSEMOVE:
                  if (!IsWindow(hDlgMouseMove)) {
                      if ((hDlgMouseMove = CreateDialog(hinstance, MAKEINTRESOURCE(IDD_MOUSEMOVE), NULL, MouseMoveDlgProc)) == NULL)
                            MessageBox(hWnd,"Mouse Move Dialog Box ERROR","Debug",MB_OK);
                      /*
                      if ((hDlgLButtonDown = CreateDialog(hinstance, MAKEINTRESOURCE(IDD_LBUTTONDOWN), NULL, MouseMoveDlgProc)) == NULL)
                            MessageBox(hWnd,"Mouse Move Dialog Box ERROR","Debug",MB_OK);
                      */
                  }
                  break;

               case IDM_DEBUG:
                   if (!IsWindow(hDlgDebug))
                      if ((hDlgDebug = CreateDialog(hinstance, MAKEINTRESOURCE(IDD_DEBUG), NULL, DebugDlgProc)) == NULL)
                            MessageBox(hWnd,"Debug Dialog Box ERROR","Debug",MB_OK);
                   break;

          } // switch
          break;	
          	  
          case WM_PAINT : {
	          hdc=BeginPaint(hWnd,&ps);
		         SetTextColor(hdc,RGB(0,0,0));
		         wsprintf((LPTSTR)Buffer,"Contador = %d ",Cont);
		         TextOut(hdc,20,20,(LPCTSTR)Buffer,lstrlen((LPCTSTR)Buffer));

                 for (std::list<ObjectoFigura*>::iterator it = desenho.begin(); it != desenho.end(); ++it) {
                     (*it)->paint(hdc);
                 }
	          EndPaint(hWnd,&ps);
           break;
         }


        case WM_LBUTTONDOWN:
            if (recta || elipse ) {
                pontox1 = pontox2 = GET_X_LPARAM(lParam); //LOWORD(lParam);
                pontoy1 = pontoy2 = GET_Y_LPARAM(lParam); //HIWORD(lParam);
	            emDesenho = TRUE;
            }
            /*
            if (IsWindow(hDlgLButtonDown))
                SendMessage(hDlgLButtonDown, WM_APP, wParam, lParam);
            */

	        break;

        case WM_LBUTTONUP:
            if ( emDesenho ) {
                pontox2 = LOWORD(lParam);
                pontoy2 = HIWORD(lParam);
	            emDesenho = FALSE;
                if ( recta ) {
                      desenho.push_back(new Recta(pontox1, pontoy1, pontox2, pontoy2));
		              InvalidateRect(hWnd,NULL,TRUE);
  	            }
                else if ( elipse ) {
                    desenho.push_back(new Elipse(pontox1, pontoy1, pontox2, pontoy2));
		            InvalidateRect(hWnd,NULL,TRUE);
		        }
            }
	        break;

        case WM_MOUSEMOVE:

	        if ( emDesenho ){
	            hdc = GetDC (hWnd) ;
                SetROP2(hdc, R2_NOTXORPEN); 

                //RECT rcClient;
                //GetClientRect(hWnd, &rcClient);
                //POINT ptClientUL;
                //POINT ptClientLR;

                //ptClientUL.x = rcClient.left;
                //ptClientUL.y = rcClient.top;
                //ptClientLR.x = rcClient.right;
                //ptClientLR.y = rcClient.bottom;
                //ClientToScreen(hWnd, &ptClientUL);
                //ClientToScreen(hWnd, &ptClientLR);
                //SetRect(&rcClient, ptClientUL.x, ptClientUL.y, ptClientLR.x, ptClientLR.y);

                //ClipCursor(&rcClient);

                if ( recta ) {
                    MoveToEx(hdc, pontox2, pontoy2, NULL);
                    LineTo(hdc, pontox1, pontoy1);
		            pontox2=GET_X_LPARAM(lParam); //LOWORD(lParam); 
                    pontoy2=GET_Y_LPARAM(lParam); //HIWORD(lParam);
                    MoveToEx(hdc, pontox2, pontoy2, NULL);
                    LineTo(hdc, pontox1, pontoy1);
                 }
                else {
                    Ellipse(hdc, pontox1, pontoy1, pontox2, pontoy2);
		            pontox2=GET_X_LPARAM(lParam); //LOWORD(lParam); 
                    pontoy2=GET_Y_LPARAM(lParam); //HIWORD(lParam);
                    Ellipse(hdc, pontox1, pontoy1, pontox2, pontoy2);
                }
           
	            ReleaseDC (hWnd, hdc);
	        }

	        if (IsWindow(hDlgMouseMove))
                SendMessage(hDlgMouseMove, WM_APP, wParam, lParam);

	        break;

        case WM_SIZE: 
            RECT rcClient;

            GetClientRect(hWnd, &rcClient);
	        if (IsWindow(hDlgDebug))
                SendMessage(hDlgDebug, WM_APP, (WPARAM)0, (LPARAM)&rcClient);
                 
            POINT ptClientUL;
            POINT ptClientLR;

            ptClientUL.x = rcClient.left;
            ptClientUL.y = rcClient.top;
            ptClientLR.x = rcClient.right;
            ptClientLR.y = rcClient.bottom;
            ClientToScreen(hWnd, &ptClientUL);
            ClientToScreen(hWnd, &ptClientLR);
            SetRect(&rcClient, ptClientUL.x, ptClientUL.y, ptClientLR.x, ptClientLR.y);

	        if (IsWindow(hDlgDebug))
                SendMessage(hDlgDebug, WM_APP, (WPARAM)0, (LPARAM)&rcClient);

            break;

        case WM_HSCROLL: {
            SCROLLINFO si;
            si.cbSize = sizeof(si);
            si.fMask = SIF_POS;
            si.nPos = 100;
            SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);   
            break; 
        }

          //case WM_CLOSE :
              //MessageBox(hWnd,"Foi recebida a mensagem WM_CLOSE","DEBUG",MB_OK);
          //break;
        case WM_DESTROY :
           //MessageBox(hWnd,"Foi recebida a mensagem WM_DESTROY","DEBUG",MB_OK);
           PostQuitMessage(0);
           return 0L;
        break;

        default : return(DefWindowProc(hWnd, uMsg, wParam, lParam));
    } // end switch
    return 0L;
}


