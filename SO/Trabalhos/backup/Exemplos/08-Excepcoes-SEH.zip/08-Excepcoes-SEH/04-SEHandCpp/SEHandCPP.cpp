// Indicar nas op��es do compilador o modelo de tratamento de excep��es ass�ncrono /EHa:
// 1. Click the C/C++ folder. 
// 2. Click the Code Generation property page. 
// 3. Set Enable C++ Exceptions to No. 
// 4. Click the Command Line property page. 
// 5. Type the compiler option in the Additional Options box. 

#include <stdio.h>
#include <windows.h>
#include <eh.h>

///////////////////////////////////////////

class SystemException{


   EXCEPTION_RECORD m_er;      // CPU independent exception information
   CONTEXT          m_context; // CPU dependent exception information

public:

   //Chamar esta fun��o por cada thread antes de usar try/catch;
   //faz o registo da fun��o de convers�o de Excep��es do S.O. (SEH) para um objecto C++;
 
   static void MapSystemException() 
   { 
       _set_se_translator(TranslateSEH); 
   }

   //Coer��o para obter o c�digo da excep��o
   operator DWORD() { return(m_er.ExceptionCode); }

   ~SystemException()
   {
	   //Nada para fazer;
	   //printf("System destructor %x\n",this); 
   }


   //Construtor do objecto de execp��o s� activado por TranslateSEH!
   SystemException(PEXCEPTION_POINTERS pep) 
   {
      m_er      = *pep->ExceptionRecord;
      m_context = *pep->ContextRecord;
	  //printf("System constructor %x\n",this);
   }

  //Construtor de Copia
   SystemException(SystemException& e) 
   { 
	   m_er = e.m_er; m_context = e.m_context; 
	   //printf("System copy constructor %x\n",this);

   }

  //� chamada automaticamente pelo run-time do C++ quando ocorre uma execp��o;
  //Origina a cria��o do objecto C++

   static void _cdecl TranslateSEH(UINT dwEC, PEXCEPTION_POINTERS pep); 
};
  

//Fun��o registada para converter excep��es SEH em objectos da classe SystemException
void _cdecl SystemException::TranslateSEH(UINT dwEC, PEXCEPTION_POINTERS pep) 
   {
	  throw SystemException(pep);
   }



// Fun��o que gera a excep��o de div/0
int Div0()
{

	int x=3,y=0;
	return x/y;
}


//Fun��o que usa um pointer ilegal

char Pt()
{
  char *p=NULL;

  return *p;
}



//////////////////////////////////////////
int main()
{ 
  SystemException::MapSystemException(); //Activar a convers�o


  try
  {
     printf("Vou chamar Div0 \n"); 
     Div0();
  }
  catch(SystemException seh)
  {
	  printf("%x  \n",DWORD(seh));
      DWORD d=DWORD(seh);
      DWORD e=EXCEPTION_INT_DIVIDE_BY_ZERO;
      switch (DWORD(seh)) {
          case EXCEPTION_ACCESS_VIOLATION:
              printf("EXCEPTION_ACCESS_VIOLATION"); break;

          case EXCEPTION_INT_DIVIDE_BY_ZERO:
              printf("EXCEPTION_INT_DIVIDE_BY_ZERO\n"); break;
      }
  }


  try
  {
     printf("Vou chamar Pt \n"); 
     Pt();
  }
  catch(SystemException seh)
  {
	  printf("%x  \n",DWORD(seh));
      DWORD d=DWORD(seh);
      DWORD e=EXCEPTION_INT_DIVIDE_BY_ZERO;
      switch (DWORD(seh)) {
          case EXCEPTION_ACCESS_VIOLATION:
              printf("EXCEPTION_ACCESS_VIOLATION"); break;

          case EXCEPTION_INT_DIVIDE_BY_ZERO:
              printf("EXCEPTION_INT_DIVIDE_BY_ZERO\n"); break;
      }
  }

  return 0;
}

