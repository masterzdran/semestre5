#include <windows.h>

#include <iostream>

using namespace std;


  int op1 = 2;
  int op2 = 0;

INT FiltroSEH(DWORD dwCode, char *name) {
    char opcao;

    cout << name << endl;

    do {
        cout << "1.EXCEPTION_CONTINUE_SEARCH" << endl;
        cout << "2.EXCEPTION_CONTINUE_EXECUTION" << endl;
        cout << "3.EXCEPTION_EXECUTE_HANDLER" << endl;

        cin >> opcao;
    } while ((opcao < '1') || (opcao > '3'));

    switch (opcao) {
        case '1': return EXCEPTION_CONTINUE_SEARCH;
        case '2': { op2 = 1; return EXCEPTION_CONTINUE_EXECUTION; }
        //case '3': return EXCEPTION_EXECUTE_HANDLER;
        default: return EXCEPTION_EXECUTE_HANDLER;
    }
}

void f()
{
    __try {
       __try {
           //char *p = 0;
           //*p=0;
          //op1 = op1 / op2;
          cout << "Ja esta e igual a " << op1 << endl;
        }
        __finally {
           cout << "Handler de finally da funcao F()" << endl;
		   //op1 = op1 / op2;
        }
    }
    __except(FiltroSEH(GetExceptionCode(), "Na funcao f()" ) )
    {
        cout << "Handler de Excepcao da fun��o f() em execucao... " << endl;
		op1 = op1 / op2;
    }

}


int main() 
{
    // The system does not display the general-protection-fault message box. 
    // This flag should only be set by debugging applications that handle 
    // general protection (GP) faults themselves with an exception handler.
    // SetErrorMode(SEM_NOGPFAULTERRORBOX);

	__try {
        __try {
            f();
            cout << "Executar codigo apos a chamada a funcao f()" << endl;
        }
        __except( FiltroSEH(GetExceptionCode(), "No Main" ) )
        {
            cout << "Handler de Excepcao do main..." << endl;
        }

	}
	__finally{
		cout << "Handler de finally do main" << endl;

	}

    cout << "Fim da funcao main." << endl;
    return 0;
}

