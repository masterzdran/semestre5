#include <iostream>

using namespace std;


void MyFunc( void );

class CTest
{
public:
    CTest(){    cout << "Constructing CTest." << endl;};
    CTest(CTest&){    cout << "Constructing CTest by copying." << endl;};
    ~CTest(){    cout << "Destructing CTest." << endl;};
    const char *ShowReason() const { return "Exception in CTest class."; }

};

class CDtorDemo
{
public:
    CDtorDemo();
    ~CDtorDemo();
	void Work();
};

CDtorDemo::CDtorDemo()
{
    cout << "Constructing CDtorDemo." << endl;
}

CDtorDemo::~CDtorDemo()
{    
    cout << "Destructing CDtorDemo." << endl;
}

void CDtorDemo::Work()
{    
    cout << "Work Method called!" << endl;
}

void MyFunc()
{
    CDtorDemo D;
    cout<< "In MyFunc(). Throwing CTest exception." << endl;
    throw CTest();
	D.Work();
    cout<< "End of MyFunc." << endl;
}

int main()
{
	char c[10];

    cout << "In main." << endl;
    try
    {
        cout << "In try block, calling MyFunc()." << endl;
        MyFunc();
    }
    catch( CTest E )
    {
        cout << "In catch handler." << endl;
        cout << "Caught CTest exception type: ";
        cout << E.ShowReason() << endl;
    }
    catch( char *str )
    {
        cout << "Caught some other exception: " << str << endl;
    }
    cout << "Back in main. Execution resumes here. Press any key and ENTER" << endl;

	cin >> c;
    return 0;

}

