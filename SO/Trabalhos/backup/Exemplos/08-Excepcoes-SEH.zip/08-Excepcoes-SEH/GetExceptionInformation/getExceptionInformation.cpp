#include <windows.h>
#include <stdio.h>


LONG mySEHFilter (LPEXCEPTION_POINTERS pExceptionPointers) 
{
    PEXCEPTION_RECORD exceptionRecord = pExceptionPointers->ExceptionRecord;

    printf("Codigo SEH = 0x%X ocorreu no endereco = 0x%p\n", 
        exceptionRecord->ExceptionCode, exceptionRecord->ExceptionAddress);

    switch(exceptionRecord->ExceptionCode) 
    {
        case EXCEPTION_ACCESS_VIOLATION:
            printf("Tentativa de %s no endereco 0x%p\n",
                exceptionRecord->ExceptionInformation[0] ? "escrita": "leitura",
                exceptionRecord->ExceptionInformation[1]);
            break;
    }
    printf("\n");

    return EXCEPTION_EXECUTE_HANDLER;
}



void main ()
{
    __try 
    {
        //RaiseException(0xE0000055,0,0,NULL);
        char *pt = NULL;
        *pt=0; // UPS!

    }
    __except( mySEHFilter( GetExceptionInformation()) )
        // mySEHFilter(GetExceptionInformation()) )
        // UnhandledExceptionFilter( GetExceptionInformation()) ) 
    {
        printf("Executando 1. Handler excepcao da funcao main\n");
    }

    __try 
    {
        char *pt = (char*)(0xFFF10000);
        char ch = *pt; // UPS!
        //char *pt = (char*)0x00010000;
        //*pt = 8; 

    }
    __except( mySEHFilter(GetExceptionInformation()) ) 
    {
        printf("Executando 2. Handler excepcao da funcao main\n");
    }

    __try 
    {
        int d = 0;
        int a = 6/d;
    }
    __except( mySEHFilter(GetExceptionInformation()) ) 
    {
        printf("Executando 3. Handler excepcao da funcao main\n");
    }

    printf("Carregue em enter para terminar\n");
    getchar();
}

