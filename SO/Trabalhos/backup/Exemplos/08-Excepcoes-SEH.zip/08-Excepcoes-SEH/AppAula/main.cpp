#include <windows.h>
#include <stdio.h>


int main () 
{
	int *pt = NULL;

	*pt=56;

	printf("vou terminar\n");

}