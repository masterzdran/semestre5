
#include<stdio.h>
#include<windows.h>

extern "C" void f();  //M�dulo C que dispara uma execp��o

int main()
{  
	try {
		f();

	} catch(...)
	{	   
		printf("Catch de qualquer execep��o\n");
	}

	printf("Press ENTER");
	getchar();

	return 0;
}
