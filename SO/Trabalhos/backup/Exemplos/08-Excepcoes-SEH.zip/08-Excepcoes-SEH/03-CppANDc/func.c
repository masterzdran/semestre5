
#include<stdio.h>
#include<windows.h>

void f()
{
  char *p=NULL;

/*
  RaiseException(
					DWORD dwExceptionCode,       // exception code
					DWORD dwExceptionFlags,      // continuable exception flag
					DWORD nNumberOfArguments,    // number of arguments
					CONST ULONG_PTR *lpArguments // array of arguments
                );
*/

//	RaiseException(0xE0000000,0,0,NULL);
  *p='a';
}


/*
The program raises an exception object via RaiseException. That function's first 
parameter is an exception code, typed as a 32-bit unsigned integer (DWORD); 
Microsoft has reserved exception codes in the range [0xE0000000, 0xEFFFFFFF] to 
represent user-defined errors. All other RaiseException parameters accept 0 
for normal usage.


*/