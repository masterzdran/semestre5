/*
    Turning Off the Exception Message Box (Richter ch 25)
*/


#include <windows.h>
#include <stdio.h>


//LONG mySEHFilter (LPEXCEPTION_POINTERS pExceptionPointers) 
//{
//    PEXCEPTION_RECORD exceptionRecord = pExceptionPointers->ExceptionRecord;
//
//    printf("Codigo SEH = 0x%X ocorreu no endereco = 0x%p\n", 
//        exceptionRecord->ExceptionCode, exceptionRecord->ExceptionAddress);
//
//    switch(exceptionRecord->ExceptionCode) 
//    {
//        case EXCEPTION_ACCESS_VIOLATION:
//            printf("Tentativa de %s no endereco 0x%p\n",
//                exceptionRecord->ExceptionInformation[0] ? "escrita": "leitura",
//                exceptionRecord->ExceptionInformation[1]);
//            break;
//    }
//    printf("\n");
//
//    return EXCEPTION_EXECUTE_HANDLER;
//    //return EXCEPTION_CONTINUE_SEARCH;
//}

LONG mySEHFilter (LPEXCEPTION_POINTERS pExceptionPointers) 
{
    PEXCEPTION_RECORD exceptionRecord = pExceptionPointers->ExceptionRecord;

    char buf[1024]; // ??
    int nChwr;

    nChwr = sprintf(buf, "Codigo SEH = 0x%X ocorreu no endereco = 0x%p\n", 
                    exceptionRecord->ExceptionCode, exceptionRecord->ExceptionAddress);

    switch(exceptionRecord->ExceptionCode) 
    {
        case EXCEPTION_ACCESS_VIOLATION:
            nChwr += sprintf(buf+nChwr, "Tentativa de %s no endereco 0x%p\n",
                        exceptionRecord->ExceptionInformation[0] ? "escrita": "leitura",
                        exceptionRecord->ExceptionInformation[1]);
            break;
    }
    sprintf(buf+nChwr, "\n\n\n\n\n\n");

    MessageBox(NULL, buf, "Exception", MB_OK | MB_ICONEXCLAMATION);

    return EXCEPTION_EXECUTE_HANDLER;
}


void main ()
{
    // 1.
    // The system does not display the general-protection-fault message box. 
    // This flag should only be set by debugging applications that handle 
    // general protection (GP) faults themselves with an exception handler.
    //SetErrorMode(SEM_NOGPFAULTERRORBOX);

    // 2.
    // Podemos evitar que o filtro de excep��es n�o tratadas por omiss�o seja evocado substitu�ndo
    // por um filtro realizado pelo programador de aplica��es
    // se executarmos com o debugger o nosso filtro n�o apanha as SEH
    SetUnhandledExceptionFilter( (LPTOP_LEVEL_EXCEPTION_FILTER)mySEHFilter );

 
    char *pt = NULL;
    *pt=0; // UPS!
}