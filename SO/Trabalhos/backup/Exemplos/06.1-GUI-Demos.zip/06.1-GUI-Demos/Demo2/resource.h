//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define IDD_OPCOES                      101
#define ID_ICON                         102
#define IDC_BLACK                       1000
#define IDC_BLUE                        1001
#define IDC_GREEN                       1002
#define IDC_CYAN                        1003
#define IDC_RED                         1004
#define IDC_MAGENTA                     1005
#define IDC_YELLOW                      1006
#define IDC_WHITE                       1007
#define IDC_CORES                       1008
#define IDC_CANCEL                      1009
#define IDC_PREVIEW                     1010
#define IDC_OK                          1011
#define ID_EXIT                         40001
#define ID_TESTE1                       40002
#define ID_OPCOES                       40002
#define ID_RECTA                        40003
#define ID_ELIPSE                       40004
#define ID_CLEAR                        40005
#define ID_USAR                         40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
