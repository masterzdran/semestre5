#include <windows.h>

#include "MyFuncs.h"
#include "resource.h"

#include "..\..\Include\SesError.h"

HWND MyCreateWindow(TCHAR * szWindowName, WNDPROC WndProc, HINSTANCE hInstance, int xSize, int ySize) {
  WNDCLASSEX wc;
  HWND hwnd; 
  int xPos=100, yPos=100;

  const TCHAR * g_szClassName = TEXT("myWindowClass");

  //Creating the Window Class and registering it
  wc.cbSize        = sizeof(WNDCLASSEX);
  wc.style         = 0;
  wc.lpfnWndProc   = WndProc;
  wc.cbClsExtra    = 0;
  wc.hInstance     = hInstance;
  wc.cbWndExtra    = 0;
  wc.hIcon         = LoadIcon(NULL, MAKEINTRESOURCE(ID_ICON));
  wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
  wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU1);
  wc.lpszClassName = g_szClassName;
  wc.hIconSm       = LoadIcon(NULL, MAKEINTRESOURCE(ID_ICON));

  if(!RegisterClassEx(&wc)) {
    FatalErrorSystem( TEXT("Erro ao registar a classe da janela") );
  }

  // Creating the Window
  hwnd = CreateWindow(
    g_szClassName, 
    szWindowName,
    WS_OVERLAPPEDWINDOW, 
    xPos, 
    yPos, 
    xSize, 
    ySize, 
    NULL, 
    NULL, 
    hInstance, 
    NULL);

  if (hwnd==NULL)  {
    FatalErrorSystem( TEXT("Erro ao criar a janela") );
  }
  
  return hwnd;
}
