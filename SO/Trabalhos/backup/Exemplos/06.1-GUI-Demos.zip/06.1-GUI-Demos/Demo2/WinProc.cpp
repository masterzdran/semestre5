#include <windows.h>
#include <windowsx.h>

#include "MyFuncs.h"
#include "resource.h"

static int counter=0;
static POINT pt[MaxPoints];

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

  switch (uMsg) {
    HANDLE_MSG(hWnd, WM_COMMAND, Cls_OnCommand);
		HANDLE_MSG(hWnd, WM_LBUTTONDOWN, Cls_OnLButtonDown);
    HANDLE_MSG(hWnd, WM_LBUTTONUP, Cls_OnLButtonUp);
    HANDLE_MSG(hWnd, WM_MOUSEMOVE, Cls_OnMouseMove);
    HANDLE_MSG(hWnd, WM_PAINT, Cls_OnPaint);
    HANDLE_MSG(hWnd, WM_CREATE, Cls_OnCreate);
    HANDLE_MSG(hWnd, WM_CLOSE, Cls_OnClose);
    HANDLE_MSG(hWnd, WM_DESTROY, Cls_OnDestroy);
    
    default:
         return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }

    return 0L;
}

void Cls_OnCommand (HWND hWnd, int id, HWND hwndCtl, UINT codeNotify) {
  switch ( id ) {
    case ID_OPCOES:
      MessageBox(hWnd, TEXT("Op��o a Implementar"), TEXT("INFO"), MB_OK);
      break;

    case ID_EXIT :
      DestroyWindow(hWnd);
		break;
	}
}

void Cls_OnPaint(HWND hWnd) {
  HDC hdc;
  PAINTSTRUCT ps;

  hdc=BeginPaint(hWnd,&ps);
    for(int i=0; i<counter-1; i++) {
      for (int j=i+1; j<counter; j++) {
        HPEN hpen = CreatePen(PS_SOLID, 0, RGB(i%255,j%255,(i*j)%255) );
	      SelectObject(hdc, hpen);
        MoveToEx(hdc, pt[i].x, pt[i].y, NULL);
        LineTo(hdc, pt[j].x, pt[j].y) ;
        DeleteObject(hpen);
      }
    }
	EndPaint(hWnd,&ps);
}

BOOL Cls_OnCreate(HWND hWnd, LPCREATESTRUCT lpCreateStruct) {
  MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_CREATE"), TEXT("DEBUG"), MB_OK);
  return TRUE;
}

void Cls_OnClose(HWND hWnd) {
  MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_CLOSE"), TEXT("DEBUG"), MB_OK);
  DestroyWindow(hWnd);
}

void Cls_OnDestroy(HWND hWnd) {
  MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_DESTROY"), TEXT("DEBUG"), MB_OK);
  PostQuitMessage(0);
}

void Cls_OnLButtonDown(HWND hWnd, BOOL fDoubleClick, int x, int y, UINT keyFlags) {
  counter = 0;
  InvalidateRect (hWnd, NULL, TRUE);
}

void Cls_OnLButtonUp(HWND hWnd, int x, int y, UINT keyFlags) {
  InvalidateRect (hWnd, NULL, TRUE);
}

void Cls_OnMouseMove(HWND hWnd, int x, int y, UINT keyFlags) {
	HDC hdc;

	if ( keyFlags & MK_LBUTTON && counter < 1000) {  // MK_LBUTON - Bot�o esquerdo do mouse down
    pt[counter  ].x = x; 
    pt[counter++].y = y;
    hdc = GetDC (hWnd) ;
    SetPixel (hdc, x,y,0); 
    ReleaseDC (hWnd, hdc) ;
  }  
}
