#ifndef _MyFuncs_h_
#define _MyFuncs_h_

#include <windows.h>

const int BufferSize = 80;
const int MaxPoints = 1000;

HWND MyCreateWindow(TCHAR * szWindowName, WNDPROC WndProc, HINSTANCE hInstance, int xSize, int ySize);

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

BOOL Cls_OnCreate(HWND hwnd, LPCREATESTRUCT lpCreateStruct);

void Cls_OnClose(HWND hWnd);

void Cls_OnDestroy(HWND hWnd);

void Cls_OnCommand(HWND hWnd, int id, HWND hwndCtl, UINT codeNotify);

void Cls_OnPaint(HWND hWnd);

void Cls_OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags);

void Cls_OnLButtonUp(HWND hWnd, int x, int y, UINT keyFlags);

void Cls_OnMouseMove(HWND hwnd, int x, int y, UINT keyFlags);

#endif  // _MyFuncs_h_