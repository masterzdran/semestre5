//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define IDR_MENU2                       102
#define ID_ICON_LARGE                   103
#define ID_ICON_SMALL                   104
#define IDI_ICON_SMALL                  105
#define IDI_ICON_AULA1                       106
#define IDI_ICON2                       107
#define IDR_MENU3                       108
#define ID_EXIT                         40001
#define ID_TESTE1                       40002
#define ID_RECTA                        40003
#define ID_ELIPSE                       40004
#define ID_CLEAR                        40005
#define ID_USAR                         40006
#define ID_MENU1_ITEM1DOMENU1           40007
#define ID_MENU2_ITEM1DOMENU2           40008
#define ID_MENU2_ITEM2DOMENU2           40009
#define ID_OLA_OLE                      40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
