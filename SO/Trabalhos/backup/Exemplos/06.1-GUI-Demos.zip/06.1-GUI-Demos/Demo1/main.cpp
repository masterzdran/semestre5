#include "MyFuncs.h"

#include <windows.h>

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) { 
  MSG msg;
  
  HWND hwnd = MyCreateWindow( 
    TEXT("Exemplo de demonstra��o 1"), 
    WndProc, 
    hInstance, 
    500, 
    500);

  ShowWindow(hwnd, nCmdShow);

  UpdateWindow(hwnd);

  while( GetMessage(&msg, NULL, 0, 0) > 0) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }

  return (int)msg.wParam;
}
