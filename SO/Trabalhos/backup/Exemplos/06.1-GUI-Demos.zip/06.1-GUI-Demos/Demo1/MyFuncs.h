#ifndef _MyFuncs_h_
#define _MyFuncs_h_

#include <windows.h>

const int SIZEBUF=80;

HWND MyCreateWindow(TCHAR * szWindowName, WNDPROC WndProc, HINSTANCE hInstance, int xSize, int ySize);

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

#endif  // _MyFuncs_h_