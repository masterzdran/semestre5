#include <windows.h>

#include "MyFuncs.h"
#include "resource.h"

static int Cont=0;

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
  HDC hdc;
  PAINTSTRUCT ps;
  TCHAR Buffer[SIZEBUF]; 

  RECT c;
  c.top = 20;
  c.left = 20;
  c.right = 190;
  c.bottom = 190;

  switch (uMsg) {
    
    case WM_COMMAND:
      switch ( LOWORD( wParam ) ) {
        case ID_TESTE1:
          Cont++;
          InvalidateRect(hWnd, &c, TRUE);
          break;

	      case ID_EXIT :
		        DestroyWindow(hWnd);
			   break;
      } // switch ( LOWORD( wParam ) )
      break;

    case WM_PAINT :
      hdc=BeginPaint(hWnd, &ps);

        SetTextColor(hdc, RGB(255,0,0));
      
        wsprintf( (LPTSTR)Buffer, TEXT("Contador = %d "), Cont);

        TextOut(hdc, 20, 20, (LPCTSTR)Buffer, lstrlen((LPCTSTR)Buffer) );

        TextOut(hdc, 200, 200, (LPCTSTR)Buffer, lstrlen((LPCTSTR)Buffer) );

      EndPaint(hWnd, &ps);
      break;

    case WM_CREATE:
      MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_CREATE"), TEXT("DEBUG"), MB_OK);
      break;

    case WM_CLOSE:
      MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_CLOSE"), TEXT("DEBUG"), MB_OK);
      DestroyWindow(hWnd);
      break;

    case WM_DESTROY :
      MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_DESTROY"), TEXT("DEBUG"), MB_OK);
      PostQuitMessage(0);
      break;

    default:
      return DefWindowProc(hWnd, uMsg, wParam, lParam);
  } // switch (uMsg)

  return 0;
}
