#include <windows.h>
#include <windowsx.h>

#include "resource.h"

#include "..\..\Include\SesError.h"

const int BufferSize = 80;

enum Figuras {NENHUMA, RECTA, ELIPSE, RECTANGULO };

// Vari�veis Globais
  // Contador
  int Cont=0;

  // Pontos para desenhar as formas
  POINTS inicio;
  POINTS fim;

  // Figura actual
  Figuras figuraActual = NENHUMA;

  // Check selecionado sim/n�o
  BOOL bCheck=FALSE;

  // Radio selecionado sim/n�o
  BOOL bRadio=TRUE;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK Dialog(HWND, UINT, WPARAM, LPARAM);

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
  WNDCLASSEX wc;
	HWND       hWnd;
	MSG        msg;

  // Preenche a estrutura que descreve a classe da Window principal
  wc.style         = CS_HREDRAW | CS_VREDRAW;  // Permite que a Janela seja redimension�vel na Horizontal e Vertical
  wc.lpfnWndProc   = WndProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = 0;
  wc.hInstance     = hInstance;
  wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON_BIG));   
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
  wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU1);
  wc.lpszClassName = TEXT("Demo 3");
  wc.cbSize        = sizeof(WNDCLASSEX);
  wc.hIconSm       = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON_SMALL));

  // Regista a Classe da Window
  if ( !RegisterClassEx( &wc ) ) {
    FatalErrorSystem( TEXT("Erro ao registar a classe da janela") );
  }

  // Cria a Janela Principal da aplica��o
  hWnd = CreateWindow(TEXT("Demo 3"),                 // Nome da Classe
                  TEXT("Exemplo de demonstra��o 3"),  // Titulo da Barra do Menu Principal.
                  WS_OVERLAPPEDWINDOW,                // Estilo da Janela
                  CW_USEDEFAULT, 0,                   // Coordenadas Canto Sup Esq e Direito por defeito
                  CW_USEDEFAULT, 0,                   // Largura e Altura por omiss�o
                  NULL,                               // Overlapped windows n�o tem parent.
                  NULL,                               // Usar o Menu da Classe
	                hInstance,                          // Inst�ncia passada na fun��o WinMain().
                  NULL  );                            // N�o � passada a estrutura para inicia��o da Janela

  if ( hWnd==NULL ) {
    FatalErrorSystem( TEXT("Erro ao criar a janela") );
  }

  // Mostrar a Janela
  ShowWindow( hWnd, nCmdShow );

  // Loop de Tratmento de Mensagens: Processa mensagens at� a aplica��o terminar
  while( GetMessage( &msg, NULL, 0, 0) ) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }

  return( msg.wParam );
} // end WinMain


// Handler de Tratamento de Mensagens recebidas pela Window Principal
LRESULT CALLBACK WndProc( HWND hWnd, UINT  uMsg, WPARAM wParam, LPARAM lParam ) {
  HDC hdc;
  PAINTSTRUCT ps;
  TCHAR Buffer[BufferSize];
  HWND dialog;

  switch (uMsg) {
    case WM_COMMAND :
      switch ( LOWORD( wParam ) ) {
        case ID_TESTE1 :
          Cont++;
          InvalidateRect(hWnd, NULL, TRUE);
          break;

        case ID_FILE_EXIT :
          DestroyWindow(hWnd);
          break;

        case ID_DIALOGO_CREATEDIALOG:
          // A macro "CreateDialog" cria uma janela de di�logo modeless usando um template.
          // Em ultima instancia � usada a fun��o "CreateDialogParam"
          // � necess�rio mostrar a janela
          if ( !(dialog=CreateDialog( 
                GetWindowInstance(hWnd), 
                MAKEINTRESOURCE(IDD_DIALOG), 
                hWnd, 
                (DLGPROC)Dialog))) {
            ReportErrorSystem( TEXT("Erro ao criar a Dialog Box") );
          }
          else {
            ShowWindow(dialog, SW_SHOWDEFAULT);
          }
          break;

        case ID_DIALOGO_DIALOGBOX:
          // A macro "DialogBox" cria uma janela de di�logo modal usando um template.
          // O controlo s� � devolvido quando a fun��o de callback associada � janela 
          // fizer uma chamada explicita � fun��o EndDialog.
          // Em ultima instancia � usada a fun��o "DialogBoxParam"
          if ( !DialogBox( 
                GetWindowInstance(hWnd), 
                MAKEINTRESOURCE(IDD_DIALOG), 
                hWnd, 
                (DLGPROC)Dialog)) {
            ReportErrorSystem( TEXT("Erro ao criar a Dialog Box") );
          }
          break;

        case ID_FIGURA_RECTA:
          figuraActual = RECTA;
          InvalidateRect(hWnd, NULL, TRUE);
          break;

        case ID_FIGURA_ELIPSE:
          figuraActual = ELIPSE;
          InvalidateRect(hWnd, NULL, TRUE);
          break;

        case ID_FIGURA_RECTANGULO:
          figuraActual = RECTANGULO;
          InvalidateRect(hWnd, NULL, TRUE);
          break;

        case ID_FIGURA_LIMPAR:
          figuraActual = NENHUMA;
          InvalidateRect(hWnd, NULL, TRUE);
          break;
        } // switch ( LOWORD( wParam ) )
      break;

    case WM_LBUTTONDOWN:
      inicio = MAKEPOINTS(lParam);
      break;

    case WM_LBUTTONUP:
      fim = MAKEPOINTS(lParam);
      InvalidateRect(hWnd, NULL, TRUE);
      break;

    case WM_MOUSEMOVE:
      if ( wParam & MK_LBUTTON) {
        fim = MAKEPOINTS(lParam);
        InvalidateRect(hWnd, NULL, FALSE);
      }
      break;

    case WM_PAINT :
      hdc=BeginPaint(hWnd,&ps);

      SetTextColor(hdc,RGB(0,0,0));
      wsprintf( (LPTSTR)Buffer, TEXT("Contador = %d "), Cont);
      TextOut(hdc, 20, 20, (LPCTSTR)Buffer, lstrlen((LPCTSTR)Buffer) );

      switch ( figuraActual ) {
        case RECTA:
          MoveToEx(hdc, inicio.x, inicio.y, NULL);
          LineTo(hdc, fim.x, fim.y);
          break;
        case ELIPSE:
          Ellipse(hdc, inicio.x, inicio.y, fim.x, fim.y);
          break;
        case RECTANGULO:
          Rectangle(hdc, inicio.x, inicio.y, fim.x, fim.y);
          break;
        case NENHUMA:
          break;
      }

      EndPaint(hWnd, &ps);
      break;

    case WM_CLOSE :
      MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_CLOSE"), TEXT("DEBUG"), MB_OK);
      DestroyWindow(hWnd);
      break;

    case WM_DESTROY :
      MessageBox(hWnd, TEXT("Foi recebida a mensagem WM_DESTROY"), TEXT("DEBUG"), MB_OK);
      PostQuitMessage(0);
      return 0L;
      break;

    default :
      return (DefWindowProc(hWnd, uMsg, wParam, lParam));
  } // switch (uMsg)

  return 0L;
}

void InitDialog(HWND hDlg,WPARAM wParam,LPARAM lParam) {
  // Meses do ano
  TCHAR mesesAno[12][16]={
    TEXT("Janeiro"),  TEXT("Fevereiro"),  TEXT("Mar�o"),
    TEXT("Abril"),    TEXT("Maio"),       TEXT("Junho"),
    TEXT("Julho"),    TEXT("Agosto"),     TEXT("Setembro"),
    TEXT("Outubro"),  TEXT("Novembro"),   TEXT("Dezembro")
  };

  // Dias da semana
  TCHAR diasSemana[7][16] = {
    TEXT("Segunda"), TEXT("Ter�a"), TEXT("Quarta"),
    TEXT("Quinta"),  TEXT("Sexta"), TEXT("Sabado"), TEXT("Domingo")
  };

  TCHAR dia[8];
  TCHAR ano[8];

  SetDlgItemText(hDlg, IDC_EDIT1, TEXT("Edite Aqui Texto") );
  CheckDlgButton(hDlg, IDC_CHECK1, BST_UNCHECKED);
  CheckDlgButton(hDlg, IDC_RADIO1, BST_CHECKED);
  
  for (int indiceDia=1; indiceDia<= 31; indiceDia++) {
    wsprintf( dia, TEXT("%2d"), indiceDia);
    SendMessage(GetDlgItem(hDlg, IDC_CBDIA), CB_ADDSTRING, 0, (LONG) (LPSTR)dia);
	}
  SendMessage(GetDlgItem(hDlg, IDC_CBDIA), CB_SETCURSEL, 0, 0);

	for (int indiceMes=0; indiceMes<12; indiceMes++)
    SendMessage( GetDlgItem(hDlg, IDC_CBMES), CB_ADDSTRING, 0, (LONG) (LPSTR)mesesAno[indiceMes]);
  SendMessage(GetDlgItem(hDlg, IDC_CBMES), CB_SETCURSEL, 0, 0);

	for (int indiceAno=0; indiceAno<6; indiceAno++) {
    wsprintf( ano, TEXT("%4d"), 2000+indiceAno);
    SendMessage(GetDlgItem(hDlg,IDC_CBANO), CB_ADDSTRING, 0, (LONG) (LPSTR)ano);
  }
  SendMessage(GetDlgItem(hDlg, IDC_CBANO), CB_SETCURSEL, 0, 0);

  for (int indiceSemana=0; indiceSemana<7; indiceSemana++)
    SendMessage (GetDlgItem (hDlg,IDC_LBDIASEM), LB_ADDSTRING, 0, (LONG) (LPSTR)diasSemana[indiceSemana]);
  SendMessage(GetDlgItem(hDlg, IDC_LBDIASEM),  LB_SETCURSEL , 0, 0);
}


// Tipicamente a fun��o de tratamento de eventos de uma Dialog Box deve retornar o valor TRUE
// se a mensagem foi processada, e o valor FALSE se a mensagem n�o foi processada.
// Se o valor devolvido pela fun��o de tratamento de eventos for FALSE o gestor das janelas
// de di�logo executa as opera��es por omiss�o que devem ser executadas na resposta da mensagem.

// Se o processamento de uma mensagem necessitar de devolver um valor espec�fico, esse valor
// deve ser devolvido usando a fun��o "SetWindowLong(hwndDlg, DWL_MSGRESULT, lResult)".
// Esta afecta��o deve ser a ultima ac��o a ser efectuada antes de ser devolvido o valor TRUE.

// Existem excep��es que podem ser vistas com detalhe no MSDN
LRESULT CALLBACK Dialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
  // Data actual
  TCHAR diaActual[16], mesActual[16], anoActual[16];

  TCHAR Buffer[BufferSize];
  int indice;

	switch (message) {
    case WM_INITDIALOG :
      MessageBox(hDlg, TEXT("WM_INITDIALOG"), TEXT("DEBUG"), MB_OK);
      InitDialog(hDlg, wParam, lParam);
      return TRUE;

    case WM_COMMAND :
      switch ( LOWORD(wParam) ) {
        case IDC_EXIT:
          EndDialog(hDlg, TRUE);
          return TRUE;

        case IDC_INSERTDATA:
          GetDlgItemText(hDlg, IDC_CBDIA, diaActual, 12);
          GetDlgItemText(hDlg, IDC_CBMES, mesActual, 12);
          GetDlgItemText(hDlg, IDC_CBANO, anoActual, 12);

          wsprintf( Buffer, TEXT("%s-%s-%s"), diaActual, mesActual, anoActual);
          
          SetDlgItemText(hDlg, IDC_EDIT1, (LPCTSTR)Buffer);
          return TRUE;

        case IDC_LBDIASEM:
          if ( HIWORD(wParam) == LBN_DBLCLK) {
            indice = SendMessage(GetDlgItem(hDlg,IDC_LBDIASEM), LB_GETCURSEL, 0, 0);
            
            SendMessage(GetDlgItem(hDlg,IDC_LBDIASEM), LB_GETTEXT, indice, (LPARAM)Buffer);
            
            SetDlgItemText(hDlg,IDC_EDIT1,(LPCTSTR)Buffer);
          }
          return TRUE;

        case IDC_RADIO1:
          if ( HIWORD(wParam) == BN_DBLCLK) {
            CheckDlgButton(hDlg, IDC_RADIO1, bRadio ? BST_UNCHECKED : BST_CHECKED);
            
            bRadio = IsDlgButtonChecked(hDlg,IDC_RADIO1) == BST_CHECKED;
          }
          return TRUE;

        case IDC_CHECK1:
          CheckDlgButton(hDlg,IDC_CHECK1, bCheck ? BST_UNCHECKED : BST_CHECKED);
          
          bCheck=IsDlgButtonChecked(hDlg,IDC_CHECK1) == BST_CHECKED;
          return TRUE;
      } // switch ( LOWORD(wParam) )
      break;
    
  } // switch (message)

  return FALSE;
}
