//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define IDD_DIALOG                      102
#define IDI_ICON_BIG                    103
#define IDI_ICON_SMALL                  104
#define IDC_EXIT                        1000
#define IDC_EDIT1                       1001
#define IDC_CHECK1                      1002
#define IDC_RADIO1                      1003
#define IDC_CBDIA                       1004
#define IDC_LBDIASEM                    1005
#define IDC_CBANO                       1006
#define IDC_CBMES                       1007
#define IDC_INSERTDATA                  1018
#define IDC_SLIDER1                     1020
#define ID_EXIT                         40001
#define ID_TESTE1                       40002
#define ID_DIALOG                       40003
#define ID_FILE_EXIT                    40004
#define ID_FIGURA_RECTA                 40005
#define ID_FIGURA_ELIPSE                40008
#define ID_FIGURA_RECTANGULO            40009
#define ID_FIGURA_LIMPAR                40010
#define ID_DIALOGO_CREATEDIALOG         40011
#define ID_DIALOGO_DIALOGBOX            40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
