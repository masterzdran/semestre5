//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GUITestProj.rc
//
#define IDC_MYICON                      2
#define IDD_GUITESTPROJ_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_GUITESTPROJ                 107
#define IDI_SMALL                       108
#define IDC_GUITESTPROJ                 109
#define IDI_SMALL1                      109
#define IDI_SES2                        110
#define IDR_MAINFRAME                   128
#define IDD_MinhaDIALOG                 129
#define IDD_DIALOG1                     131
#define IDD_DIALOG2                     132
#define IDC_EDIT1                       1001
#define IDC_BUTTON1                     1002
#define IDC_EDIT2                       1003
#define IDC_CHECK1                      1003
#define IDC_BUTTON2                     1004
#define IDC_COMBO1                      1004
#define IDC_LISTA_FREGUESIAS            1004
#define ID_FILE_ABRIRDIALOG             32771
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
