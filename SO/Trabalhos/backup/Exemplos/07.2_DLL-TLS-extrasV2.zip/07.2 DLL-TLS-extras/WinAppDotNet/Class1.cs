using System;
using System.Runtime.InteropServices;

namespace AppDotNet
{
    public class CDll
    {
        [DllImport("RandomMT.dll", EntryPoint = "Rand62")] 
        public static extern int Rand62();
    }


	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
            Console.WriteLine("Acesso a uma DLL dsenvolvida em C");
            
            for (int i = 0; i < 24; ++i)
                Console.WriteLine("[{0}] {1}", i, CDll.Rand62());

            Console.ReadLine();
		}
	}
}
