
Exemplo .net de acesso a c�digo unmanaged a partir de C#
O exemplo executa a fun��o Rand62 definida na Dll Random.dll 

(necess�rio ter este Dll na mesma directoria do execut�vel)