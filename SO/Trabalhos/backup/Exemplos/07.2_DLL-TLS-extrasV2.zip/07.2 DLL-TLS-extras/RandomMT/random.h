#ifndef __randomdll__
#define __randomdll__

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

#include <windows.h>

#define EXPORT __declspec (dllexport)
#define IMPORT __declspec (dllimport)

#ifdef randomdll_build

EXPORT int WINAPI Rand62();

#else // Defini��es para uso de carregamento automatico

IMPORT int WINAPI Rand62();

#endif // randomdll_build

//Defini��es para carregamento expl�cito com a fun��o LoadLibray:
typedef  int (WINAPI *TpRand62)();

#ifdef __cplusplus
} //extern "C" {
#endif // __cplusplus

#endif
