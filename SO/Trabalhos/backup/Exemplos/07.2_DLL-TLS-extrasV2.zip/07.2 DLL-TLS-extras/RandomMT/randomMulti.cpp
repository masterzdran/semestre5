#define randomdll_build

#include "random.h"

#include <stdio.h>


/*******************************************************************************************
/* Fun��es Auxiliares para manipula��o do TLS
/*******************************************************************************************/

DWORD indxRnd=-1;   // �ndice da entrada TLS



//Fun��o de inicia��o do m�dulo
DWORD ModuleTlsInit()
{
    return TlsAlloc();
}


//Fun��o de Fecho do m�dulo
BOOL ModuleTlsEnd()
{
	if(indxRnd != -1)
		if( !TlsFree(indxRnd) ) return FALSE;
    return TRUE;
}


//Inicia��o de uma entrada TLS para um thread
int *ThreadTlsInit()
{
	int *p  = new int[1];	 // Espa�o no heap para a informa��o local ao thread
	*p = 1;                  // Valor inicial da vari�vel
    if (! TlsSetValue(indxRnd, p)) {
        delete [] p;
        return NULL;
    }
	return p;
}

//Termino de uma entrada TLS
BOOL ThreadTlsClose()
{
	int* p = (int*)TlsGetValue(indxRnd); //Obter a entrada TLS
	if ( p ) { 
		delete p; 
		p = NULL;
		if ( !TlsSetValue(indxRnd, p) ) return FALSE; 
	}
    return TRUE;
}



//Solu��o que tem problemas de multrithread
int WINAPI monoRand62()
{
   static int sReg = 1; 

   sReg = (sReg >> 1) | (((sReg & 0x2)^((sReg & 1)<< 1))?0x20:0);
   return sReg;
}


//Solu��o correcta que recorre ao TLS
int WINAPI Rand62()
{
	int* psReg = (int*)TlsGetValue(indxRnd);  // Obter a entrada TLS

	// Se p==NULL ent�o ainda n�o foi iniciada 
    if( psReg==NULL) {
        psReg = ThreadTlsInit();
        if ( psReg == NULL )  // Erro na inicia��o do TLS
            return -1;
    }

	//usar a entrada Tls
	*psReg = (*psReg >> 1) | (((*psReg & 0x2)^((*psReg & 1)<< 1))?0x20:0);
	return *psReg;
}


/////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////// Fun��o DllMain ///////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved )
{
    BOOL Result = TRUE;
    switch (fdwReason) {
        case DLL_PROCESS_ATTACH:
            // A DDL est� a ser mapeada no espa�o de endere�amento do processo
            printf("A DDL est� a ser mapeada no espa�o de endere�amento do processo\n");
            printf("0x%p\n", hinstDLL);
            // Criar a entrada TLS
            //if ((indxRnd = ModuleTlsInit()) == -1) {
            if ((indxRnd = TlsAlloc()) == -1) { 
                Result = FALSE; break;
            }
            //Atribuir espa�o na entrada do thread corrente
            Result = ThreadTlsInit() != NULL;
            break;

        case DLL_THREAD_ATTACH:
            // Est� a ser criada uma thread
            printf("Est� a ser criada uma thread\n");
            //Atribuir espa�o na entrada TLS do thread corrente
            ThreadTlsInit();
            break;

        case DLL_THREAD_DETACH:
            // Existe uma thread a terminar (sem ser atrav�s do TerminateThread
            printf("Existe uma thread a terminar (sem ser atrav�s do TerminateThread)\n");
            //Libertar espa�o ocupado pelo thread na entrada TLS
            ThreadTlsClose();
            break;

        case DLL_PROCESS_DETACH:
            // A DLL est� a ser desmapeada do espa�o de endere�amento do processo
            printf("A DLL est� a ser desmapeada do espa�o de endere�amento do processo\n");
            //ModuleTlsEnd();
            //Libertar espa�o ocupado pelo thread na entrada TLS
            ThreadTlsClose();
            //Fechar a entrada de TLS no processo
            if( !TlsFree(indxRnd) ) Result = FALSE;
            break;

        default:
            printf("Entrada DllMain n�o suportada no switch (%ld)\n", fdwReason); 
            Result = FALSE;
    }
    return Result; // Utilizado apenas para DLL_PROCESS_ATTACH

}