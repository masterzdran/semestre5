//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CalcDllGUI2.rc
//
#define IDD_CALCULADORA                 101
#define IDC_VISOR                       1000
#define IDC_BUTTON_7                    1001
#define IDC_BUTTON_8                    1002
#define IDC_BUTTON_9                    1003
#define IDC_BUTTON_DIV                  1004
#define IDC_BUTTON_4                    1005
#define IDC_BUTTON_5                    1006
#define IDC_BUTTON_6                    1007
#define IDC_BUTTON_MULT                 1008
#define IDC_BUTTON_1                    1009
#define IDC_BUTTON_2                    1010
#define IDC_BUTTON_3                    1011
#define IDC_BUTTON_MINUS                1012
#define IDC_BUTTON_0                    1013
#define IDC_BUTTON_SIGNAL               1014
#define IDC_BUTTON_PONTO                1015
#define IDC_BUTTON_ADD                  1016
#define ID_OFF                          1017
#define ID_IGUAL                        1018
#define ID_CECLR                        1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
