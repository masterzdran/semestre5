
//#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <locale.h>

#include "..\SesCalcWithSkins\SesCalcWithSkins.h"


int _tmain(int argc, _TCHAR* argv[])
{
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));


    _tprintf(_T("\n--- Vou criar uma calculadora da DLL SesCalcWithSkins.dll ---\n\n"));
    

    CreateCalc();

    CreateCalcX(_T("SesCalcSkin2"));

    CreateCalcX(_T("SesCalcSkin3"));
}