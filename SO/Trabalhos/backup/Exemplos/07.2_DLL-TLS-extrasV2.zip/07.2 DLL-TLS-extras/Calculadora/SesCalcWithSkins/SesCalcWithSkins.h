#ifndef _SesCalcWithSkins_
#define _SesCalcWithSkins_

#include <windows.h>


#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


#define EXPORT __declspec (dllexport)
#define IMPORT __declspec (dllimport)


#ifdef SESCALCWITHSKINS_EXPORTS
#define DLLAPI EXPORT
#else
#define DLLAPI IMPORT
#endif  // SESCALCWITHSKINS_EXPORTS


#ifdef UNICODE
#define CreateCalcX  CreateCalcXW
#else
#define CreateCalcX  CreateCalcXA
#endif // !UNICODE


DLLAPI void WINAPI CreateCalc();
DLLAPI void WINAPI CreateCalcXA(char *);
DLLAPI void WINAPI CreateCalcXW(wchar_t *);


//Defini��es para carregamento expl�cito com a fun��o LoadLibray:
typedef  int (WINAPI *TpCreateCalc)();

#ifdef UNICODE
typedef  int (WINAPI *TpCreateCalcx)(wchar_t *);
#else
typedef  int (WINAPI *TpCreateCalcx)(char *);
#endif // !UNICODE


#ifdef __cplusplus
} //extern "C" {
#endif // __cplusplus

#endif // _SesCalcWithSkins_