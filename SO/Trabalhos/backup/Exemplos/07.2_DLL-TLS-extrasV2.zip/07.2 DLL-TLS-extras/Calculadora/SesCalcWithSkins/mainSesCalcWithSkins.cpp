#define SES_CALC_WITH_SKINS_BUILD

#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <locale.h>
#include <tchar.h>

#include "SesCalcWithSkins.h"
#include "..\SesCalcSkin1\resource.h"



#define MAX_VISOR 15

enum Operador  { dividir, multiplicar, somar, subtrair, primeiro, igual };

double Acc; //Acumulador dos c�lculos

Operador Op;

TCHAR Visor[MAX_VISOR+1];
int  ixVisor;



void KeyIn(HWND hDlg, char Key)
{  
    if (Op == igual) {
        ixVisor=0; Op=primeiro;
	} else {
	  ixVisor=GetDlgItemText( hDlg,IDC_VISOR,Visor,MAX_VISOR+1);
	  if((ixVisor == 1) && (Visor[0] == '0')) 
          ixVisor=0;
	}
	if (ixVisor < MAX_VISOR ) {
		Visor[ixVisor]=Key;
		Visor[++ixVisor]=_T('\0');
		SetDlgItemText(hDlg,IDC_VISOR, Visor);
	}
}

void Sinal(HWND hDlg)
{
	ixVisor=GetDlgItemText(hDlg, IDC_VISOR, Visor, MAX_VISOR+1);
	if(	ixVisor != 0) {
		if (Visor[0] == _T('-')) {
		    for(int i = 0 ; i <= ixVisor ; i++) 
                Visor[i]=Visor[i+1];	
		} else {
		    for(int i=ixVisor+1; i>0; i--) 
                Visor[i]=Visor[i-1];
		    Visor[0] = _T('-');
		}
	  SetDlgItemText(hDlg,IDC_VISOR, Visor);
	}
}

void CeClr(HWND hDlg)
{
	ixVisor=GetDlgItemText(hDlg,IDC_VISOR,Visor,MAX_VISOR+1);
	
    if(	ixVisor!=0) {
  	  Visor[ixVisor=0] = _T('\0');
	  SetDlgItemText(hDlg,IDC_VISOR, Visor);
	} else {
		Acc = 0; Op=primeiro;
	}
}

void SetOp(HWND hDlg, Operador nop)
{ 
    double operando=0;

	ixVisor=GetDlgItemText( hDlg,IDC_VISOR,Visor,MAX_VISOR+1);

    if(ixVisor==0) return;

	_stscanf_s( Visor, _T("%lf"), &operando );

	switch(Op) {
	case primeiro:
	case igual:
		  Acc = operando;
		  Op = nop;
		break;
	case multiplicar:
		  Acc *=operando;
		  Op= nop;
		break;
	case dividir:
		  Acc /=operando;
		  Op= nop;
		break;
	case somar:
		  Acc +=operando;
		  Op= nop;
		break;
	case subtrair:
		  Acc -=operando;
		  Op= nop;
		break;
	default:
		break;
	}
    if(Op==igual) {
        _stprintf_s(Visor,sizeof(Visor),_T("%lg"),Acc);
	    SetDlgItemText(hDlg,IDC_VISOR, Visor);
	} else {
		SetDlgItemText(hDlg,IDC_VISOR, _T(""));
	}
}

BOOL CALLBACK Dialog(HWND hDlg, UINT message,WPARAM wParam,LPARAM lParam)
{

    switch (message) {
	case WM_INITDIALOG:
			  SetDlgItemText(hDlg,IDC_VISOR, _T("0"));
			  ixVisor=0; Op=primeiro;
            return TRUE ;
    case WM_COMMAND:
            switch (LOWORD (wParam)) {
			   case IDC_BUTTON_0:
					KeyIn(hDlg, _T('0'));
					return TRUE;

			   case IDC_BUTTON_1:
					KeyIn(hDlg, _T('1'));
					return TRUE;

			   case IDC_BUTTON_2:
					KeyIn(hDlg,_T('2'));
					return TRUE;

			   case IDC_BUTTON_3:
					KeyIn(hDlg, _T('3'));
					return TRUE;

			   case IDC_BUTTON_4:
					KeyIn(hDlg, _T('4'));
					return TRUE;

			   case IDC_BUTTON_5:
					KeyIn(hDlg, _T('5'));
					return TRUE;

			   case IDC_BUTTON_6:
					KeyIn(hDlg, _T('6'));
					return TRUE;

			   case IDC_BUTTON_7:
					KeyIn(hDlg, _T('7'));
					return TRUE;

			   case IDC_BUTTON_8:
					KeyIn(hDlg, _T('8'));
					return TRUE;

			   case IDC_BUTTON_9:
					KeyIn(hDlg, _T('9'));
					return TRUE;

			   case IDC_BUTTON_DIV:
				    SetOp(hDlg,dividir);
					return TRUE;

			   case IDC_BUTTON_MULT:
				      SetOp(hDlg,multiplicar);
					return TRUE;

			   case IDC_BUTTON_MINUS:
				    SetOp(hDlg,subtrair);
					return TRUE;

			   case IDC_BUTTON_ADD:
				    SetOp(hDlg,somar);
					return TRUE;

			   case ID_CECLR:
				    CeClr(hDlg);
					return TRUE;

			   case ID_IGUAL:
					SetOp(hDlg, igual);
					return TRUE;

			   case IDC_BUTTON_PONTO:
					KeyIn(hDlg, _T('.'));
					return TRUE;

			   case IDC_BUTTON_SIGNAL:
					Sinal(hDlg);
					return TRUE;

               case ID_OFF:
                    EndDialog (hDlg, FALSE);
                    return TRUE;
            } // end switch wParam
			break;
    case WM_CLOSE:
	     EndDialog (hDlg, FALSE);
         return TRUE;
    } // end switch message
    return FALSE;
}



// guarda o hinstance da DLL
HINSTANCE myHInstance = NULL;
HINSTANCE hinstanceGUI = NULL;


// --------------------------------------------------------------------------------------------
//                                  Fun��o DllMain
//
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved )
{
    BOOL Result = TRUE;
    
    _tsetlocale(LC_ALL, _T("portuguese_portugal"));

    switch (fdwReason) {
        case DLL_PROCESS_ATTACH:
            myHInstance = hinstDLL;
            // A DDL est� a ser mapeada no espa�o de endere�amento do processo
            _tprintf(_T("SesCalcWithSkins.dll: A DDL est� a ser mapeada no espa�o de endere�amento do processo\n"));
            _tprintf(_T("SesCalcWithSkins.dll: 0x%p\n"), hinstDLL);
            break;

        case DLL_THREAD_ATTACH:
            // Est� a ser criada uma thread
            _tprintf(_T("SesCalcWithSkins.dll: Est� a ser criada uma thread\n"));
            break;

        case DLL_THREAD_DETACH:
            // Existe uma thread a terminar (sem ser atrav�s do TerminateThread
            _tprintf(_T("SesCalcWithSkins.dll: Existe uma thread a terminar (sem ser atrav�s do TerminateThread"));
            break;

        case DLL_PROCESS_DETACH:
            // A DLL est� a ser desmapeada do espa�o de endere�amento do processo
            _tprintf(_T("SesCalcWithSkins.dll: A DLL esta a ser desmapeada do espa�o de enderecamento do processo"));

            if ( hinstanceGUI != NULL) {
                if ( FreeLibrary(hinstanceGUI) == 0)
                    _tprintf(_T("Erro Freelibrary (%d)\n"), GetLastError());
            }
            break;

        default:
            _tprintf(_T("SesCalcWithSkins.dll: Entrada DllMain n�o suportada no switch (%ld)"), fdwReason); 
            Result = FALSE;
    }
    return Result;
}

// --------------------------------------------------------------------------------------------
// Fun��es exportada pela aplica��o
//
void WINAPI CreateCalc()
{
#ifdef UNICODE
    CreateCalcXW(_T("SesCalcSkin1"));
#else
    CreateCalcXA("SesCalcSkin1");
#endif
} // end CreateCalc


void WINAPI CreateCalcXA(char *nameDllResource)
{
    if (hinstanceGUI != NULL) {
        if ( FreeLibrary(hinstanceGUI) == 0)
        _tprintf(_T("Erro Freelibrary (%d)\n"), GetLastError());
    }

    hinstanceGUI = LoadLibraryA(nameDllResource);
    if (hinstanceGUI == NULL) {
        printf("Erro ao carregar a DLL %s (%d)\n", nameDllResource, GetLastError());
        _getch();
        return;
    }
    printf("Biblioteca %s carregada (0X%p)\n", nameDllResource, hinstanceGUI);

    if ( DialogBox(hinstanceGUI, MAKEINTRESOURCE(IDD_CALCULADORA), NULL, (DLGPROC)Dialog) < 0) {
        printf("Erro ao criar DialogBox (%d)\n", GetLastError());
        _getch();
    }
}

void WINAPI CreateCalcXW(wchar_t *nameDllResource)
{
    if (hinstanceGUI != NULL) {
        if ( FreeLibrary(hinstanceGUI) == 0)
        _tprintf(_T("Erro Freelibrary (%d)\n"), GetLastError());
    }

    hinstanceGUI = LoadLibraryW(nameDllResource);
    if (hinstanceGUI == NULL) {
        _tprintf(_T("Erro ao carregar a DLL %s (%d)\n"), nameDllResource, GetLastError());
        _gettch();
        return;
    }
    _tprintf(_T("Biblioteca %s carregada (0X%p)\n"), nameDllResource, hinstanceGUI);

    if ( DialogBox(hinstanceGUI, MAKEINTRESOURCE(IDD_CALCULADORA), NULL, (DLGPROC)Dialog) < 0) {
        _tprintf(_T("Erro ao criar DialogBox (%d)\n"), GetLastError());
        _gettch();
    }
}

