//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UmaAplicacao.rc
//
#define IDD_POLIGOTA                    101
#define IDC_PORTUGUES                   1000
#define IDC_INGLES                      1001
#define IDC_FRANCES                     1002
#define IDC_ESPANHOL                    1003
#define IDC_STATIC_NOME                 1004
#define IDC_STATIC_MORADA               1005
#define IDC_STATIC_TELEFONE             1006
#define IDC_NOME                        1007
#define IDC_MORADA                      1008
#define IDC_TELEFONE                    1009
#define IDC_STATIC_IDIOMA               1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
