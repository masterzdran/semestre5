#include <windows.h>

#include "..\..\..\include\SesError.h"

#include "resource.h"
#include "..\DLLMSGPT\resource.h"



HINSTANCE hlibMsg = NULL;


UINT TStrings[] = { IDS_NOME, IDS_MORADA, IDS_TELEFONE, IDS_IDIOMA, 
                    IDS_PORTUGUES, IDS_INGLES, IDS_FRANCES, IDS_ESPANHOL, IDS_OK, IDS_CANCEL };
UINT TCtrId[]   = { IDC_STATIC_NOME, IDC_STATIC_MORADA, IDC_STATIC_TELEFONE, IDC_STATIC_IDIOMA, 
                    IDC_PORTUGUES, IDC_INGLES, IDC_FRANCES, IDC_ESPANHOL, IDOK, IDCANCEL };


void traduzir(HWND hDlg) {
    TCHAR aux[80];

    for (int i = 0; i < 10; i++) {
        LoadString(hlibMsg, TStrings[i], aux, 80);

        SetDlgItemText(hDlg, TCtrId[i], aux);
    }
    
    LoadString(hlibMsg, IDS_TITULO, aux, 80);
    SetWindowText(hDlg, aux);

}


void carregarDLLMsg(HWND hDlg, char *dllName) {
    
    if (hlibMsg != NULL) {
        if ( FreeLibrary(hlibMsg) == 0) 
            FatalErrorSystem("Erro a libertar DLL\n");
    }

    hlibMsg = LoadLibrary(dllName);
    if (hlibMsg == NULL) FatalErrorSystem("Erro load \"%s\"\n", dllName);

    traduzir(hDlg);    
}


BOOL CALLBACK Dialog(HWND hDlg, UINT message,WPARAM wParam,LPARAM lParam)
{
    switch (message) {
	    case WM_INITDIALOG:
            CheckDlgButton(hDlg, IDC_PORTUGUES, TRUE);
            carregarDLLMsg(hDlg, "DLLMSGPT.dll");                       
            return TRUE;

        case WM_COMMAND:
                switch (LOWORD (wParam)) {
			       case IDC_PORTUGUES:
                       carregarDLLMsg(hDlg, "DLLMSGPT.dll");                       
                       return TRUE;
			       
                   case IDC_INGLES:
                       carregarDLLMsg(hDlg, "DLLMSGUK.dll");                       
                       return TRUE;

			       case IDC_FRANCES:
                       carregarDLLMsg(hDlg, "DLLMSGFR.dll");                       
                       return TRUE;

			       case IDC_ESPANHOL:					      
                       carregarDLLMsg(hDlg, "DLLMSGSP.dll");                       
                       return TRUE;

                   case IDCANCEL:
                  	   EndDialog (hDlg, FALSE);
                       return TRUE;
                }
                break;
  
        case WM_CLOSE:

	         EndDialog (hDlg, FALSE);
             return TRUE;
     } // end switch message
     return FALSE;
}

// Entry Point da Aplica��o
int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
					  LPSTR     lpCmdLine, int       nCmdShow )
{
  
  DialogBox(hInstance, MAKEINTRESOURCE(IDD_POLIGOTA), NULL, (DLGPROC)Dialog);   


return 0;
} // end WinMain
