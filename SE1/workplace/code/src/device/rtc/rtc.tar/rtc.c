#include <time.h>
#include "types.h"
#include "io.h"
#include "lpc2106.h"

int rtc_write(struct tm * tp) {
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_CCR, LPC2XXX_RTC_CCR_CTCRST);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_SEC, tp->tm_sec);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_MIN, tp->tm_min);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_HOUR, tp->tm_hour);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_DOM, tp->tm_mday);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_DOW, tp->tm_wday);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_DOY, tp->tm_yday);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_MONTH, tp->tm_mon + 1);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_YEAR, 1900 + tp->tm_year);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_CCR, LPC2XXX_RTC_CCR_CLKEN);
}

int rtc_read(struct tm * tp) {
	U32 aux0, aux0a, aux1, aux1a, aux2, aux2a;
	aux0 = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_CTIME0);
	aux1 = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_CTIME1);
	aux2 = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_CTIME2);
	do {
		aux0a = aux0; aux1a = aux1; aux2a = aux2;
		aux0 = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_CTIME0);
		aux1 = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_CTIME1);
		aux2 = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_CTIME2);
	} while (aux0 != aux0a || aux1 != aux1a || aux2 != aux2a);
	tp->tm_wday = (aux0 >> 24) & 7;
	tp->tm_hour = (aux0 >> 16) & 0x1f;
	tp->tm_min = (aux0 >> 8) & 0x3f;
	tp->tm_sec = (aux0 & 0x3f);
	tp->tm_year = ((aux1 >> 16) & 0xfff) - 1900;
	tp->tm_mon = ((aux1 >> 8) & 0xf) - 1;
	tp->tm_mday = aux1 & 0x1f;
	tp->tm_yday = aux2 & 0xfff;
	tp->tm_isdst = 0;
}

int rtc_changed() {
	U32 aux = io_read_u32(LPC210X_RTC + LPC2XXX_RTC_ILR);
	if (aux == 0)
		return 0;
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_ILR, aux);
	return 1;
}

int rtc_init() {
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_CCR, LPC2XXX_RTC_CCR_CTCRST);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_PREINT, (PCLK /32768) - 1);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_PREFRAC,
		(PCLK - (PCLK / 32768) * 32768));
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_CIIR, 1);
	io_write_u32(LPC210X_RTC + LPC2XXX_RTC_ILR, LPC2XXX_RTC_ILR_CIF);
}
