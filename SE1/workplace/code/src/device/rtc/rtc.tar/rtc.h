#ifndef RTC_H
#define RTC_H

int rtc_write(struct tm * tp);
int rtc_read(struct tm * tp);
int rtc_changed();
int rtc_init();

#endif
