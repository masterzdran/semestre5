
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include "system.h"
#include "input.h"
#include "config.h"
#include "capture.h"
#include "analisys.h"
#include <lcd.h>
#include <lpc2106.h>
#include <timer.h>
#include <rtc.h>


int main() {
	
	UINT period = 1; /* periodo de 1 min por padr�o */
	RTCTime start, finish;
	UINT flash_end = FLASH_DATA_START;
	BOOL configOk = FALSE; 

	Mode mode = systemInit(&flash_end);
	
	while(1) {
		
		mode = getMode(mode);
		
		switch(mode) {
			case CONFIG:
                startConfig(&start , &finish , &period , &configOk);
                break;
	        case CAPTURE:
                if(configOk)
					startCapture(&start, &finish, period, &flash_end);
                else {
					LCD_print(0, 0, MSG_MODE_ERROR);
					LCD_print(0, 1, MSG_MODE_ERROR_CONFIG);
					TIMER_delay(LPC2106_BASE_TC0, 5000);
	            }
				break;
			case ANALISYS:
				startAnalisys(&flash_end);
				break;
		}      
    }
	return 0;
}
