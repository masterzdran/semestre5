
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __CONFIG__H__
#define __CONFIG__H__

/* 
 * ***********************************************
 * CONFIG MESSAGES
 * ***********************************************
 * */

#define MSG_CONFIG 				"Configuracao:"
#define	OPTION_CONFIG_CLOCK 	"<   Relogio    >"
#define	OPTION_CONFIG_PERIOD 	"<   Periodo    >"
#define	OPTION_CONFIG_DELTA		"< Inicio / fim >"
#define	OPTION_CONFIG_BACK		"<  Retroceder  >"

#define MSG_CONFIG_CLOCK		"D/H actual:"
#define MSG_CONFIG_PERIOD		"Periodo captura:"
#define MSG_CONFIG_START	 	"D/H inicio:"
#define MSG_CONFIG_FINISH 		"D/H fim:"

void startConfig(RTCTime *start, RTCTime *finish, UINT *period, BOOL *configOk);


#endif
