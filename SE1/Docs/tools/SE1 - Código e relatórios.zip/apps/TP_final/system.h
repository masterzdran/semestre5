
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef _SYSTEM_H_
#define _SYSTEM_H_

#include <iap.h>

/* 
 * ***********************************************
 * UTILITY DEFINITIONS
 * ***********************************************
 * */

typedef unsigned int UINT;
typedef int BOOL;

#define TRUE 	1
#define FALSE 	0
#define NULL 	0


/* 
 * ***********************************************
 * KEYPAD PINS DEFINITION
 * ***********************************************
 * */

#define PIN_KEYPAD_COL0 9
#define PIN_KEYPAD_LIN0 13

/* 
 * ***********************************************
 * LCD PINS DEFINITION
 * ***********************************************
 * */

#define PIN_RS 29
#define PIN_RW 30
#define PIN_EN 4
#define PIN_DB7 8

/* 
 * ***********************************************
 * LED PINS DEFINITION
 * ***********************************************
 * */

#define LED_PIN 31

/* 
 * ***********************************************
 * DS1621 PINS DEFINITION
 * ***********************************************
 * */

#define SCL_PIN 2
#define SDA_PIN 3

/* 
 * ***********************************************
 * SYSTEM CLOCK CONFIGURATION 
 * ***********************************************
 * */

#define LPC2106_FOSC 14745600 		  // xtal frequency
#define LPC2106_CCLK LPC2106_FOSC	  // pll not used, CCLK = FOSC
//#define LPC2106_CCLK 60000000		  // pll: M=4, P=2 -> CCLK=60MHz
#define LPC2106_PCLK LPC2106_CCLK/4	  // APBDIV starts with 00 -> PCLK=CCLK/4
#define TC0_PERIOD_SEC 0.001	      // timer temporal base


/* 
 * ***********************************************
 * MODE DEFINITON
 * ***********************************************
 * */
enum _Mode { CONFIG, CAPTURE, ANALISYS };
typedef enum _Mode Mode;

#define MSG_MODE				"Seleccione modo:"
#define OPTION_MODE_CONFIG	 	"< Configuracao >"
#define OPTION_MODE_CAPTURE 	"<   Captura    >"
#define OPTION_MODE_ANALISYS 	"<   Analise    >"
#define MSG_MODE_ERROR          "  <<< ERRO >>>  "
#define MSG_MODE_ERROR_CONFIG   "Config. invalida"

Mode getMode(Mode mode);

/* 
 * ***********************************************
 * KEYPAD CONFIGURATION
 * ***********************************************
 * */

#define KEY_OK 12
#define KEY_CANCEL 10
#define KEY_LEFT 14
#define KEY_RIGHT 15
#define KEY_RESET 11


/* 
 * ***********************************************
 * LCD CONFIGURATION
 * ***********************************************
 * */

#define MAX_X 16
#define MAX_Y 1


/* 
 * ***********************************************
 * SYSTEM INITIALIZATION
 * ***********************************************
 * */
Mode systemInit(UINT *flash_end);


/* 
 * ***********************************************
 * FLASH CONFIGURATION
 * ***********************************************
 * */

#define FLASH_DATA_SECTOR_START 3
#define FLASH_DATA_SECTOR_END 14
#define FLASH_DATA_START (SECTOR_SIZE*FLASH_DATA_SECTOR_START)
#define FLASH_DATA_END   (SECTOR_SIZE*FLASH_DATA_SECTOR_END)
#define FLASH_BLOCK_SIZE 512

/* 
 * ***********************************************
 * DS1621 CONFIGURATION
 * ***********************************************
 * */

#define DS1621_ADDR 0x4F      /* 100 1_A2_A1_A0 */


/* 
 * ***********************************************
 * CAPTURE STRUCTURE
 * ***********************************************
 * */

typedef struct _Capture_temp {
  char yy;             /* Year value - [0,99] */
  char MM;     	       /* Month value - [1,12] */
  char dd;    	       /* Day of the month value - [1,28|29|30|31] */
  char hh;             /* Hour value - [0,23] */
  char mm;		         /* Minute value - [0,59] */
  short temperature;   /* Temp. value [ -10�C , +50�C ] */
  short capture_num;
  int dummy;
} Capture_temp;

#define	CAPTURE_STRUCT_SIZE sizeof(Capture_temp)
#define	CAPTURE_MEM_SIZE (FLASH_BLOCK_SIZE/CAPTURE_STRUCT_SIZE)


#endif
