
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Luís Brás			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include "input.h"
#include <rtc.h>
#include "system.h"
#include "config.h"


/*
 O modo de configuração permite ao utilizador programar no sistema o intervalo de tempo a que devem
ser realizadas as medições de temperatura (TM), que pode variar entre 1 e 1440 minutos (24h x 60min),
bem como os instantes inicial (II) e final (IF) para o período de tempo em que irá decorrer o processo de
monitorização de temperatura. Os instantes II e IF identificam uma data e hora específicas, nos formatos
aa/mm/dd e hh:mm, respectivamente
*/



static BOOL setClock() {
	RTCTime rtc;
	BOOL inputOk;
	inputOk = getDateTime(&rtc, MSG_CONFIG_CLOCK, 0, TRUE, 1);
	
	if(inputOk) {
		rtc_SetTime(rtc.hh, rtc.mm, rtc.ss);
		rtc_SetDate(rtc.dd, rtc.MM, rtc.yyyy);
		return TRUE;
	}	
	return FALSE;
}


static BOOL setPeriod(UINT *period) {
	UINT _period;
	BOOL inputOk; // false when user cancels input
	
	do {
		inputOk = getUInt(&_period, MSG_CONFIG_PERIOD, 0, TRUE, 1);
	}
	while(inputOk && _period < 1 && _period > 1440);
	
	// if input was cancelled, don't change period
	if(inputOk) {
		*period = _period;	
		return TRUE;
	}
    return (FALSE);
}


static BOOL setDelta(RTCTime *start , RTCTime *finish) {
	RTCTime _start, _finish;
	BOOL inputOk;
	
	do {
		// Get start Date / Time
		inputOk = getDateTime(&_start, MSG_CONFIG_START, 0, TRUE, 1);
		
		if(!inputOk)
			return FALSE;
		
		// Get finish Date / Time
		inputOk = getDateTime(&_finish, MSG_CONFIG_FINISH, 0, TRUE, 1);
		
		if(!inputOk)
			return FALSE;			
	}
	while(dateTimeComparator(&_start, &_finish) >= 0); // _start > _finish
	
	*start = _start;
	*finish = _finish;
	return TRUE;
}


void startConfig(RTCTime *start, RTCTime *finish, UINT *period, BOOL *configOk) {
	static BOOL clockOk = FALSE, deltaOk = FALSE;
	
	enum Selection { CLOCK, PERIOD, DELTA, BACK };
	
	static enum Selection selection = CLOCK;

	static const char *options[] = {
		OPTION_CONFIG_CLOCK,
		OPTION_CONFIG_PERIOD,
		OPTION_CONFIG_DELTA,
		OPTION_CONFIG_BACK
	};

	while((selection = getOption(MSG_CONFIG, options, 4, selection)) != BACK) {

		switch(selection) {		
			case CLOCK:
				clockOk |= setClock();				
				break;
				
			case PERIOD:
				setPeriod(period);
				break;
				
			case DELTA:
				deltaOk |= setDelta(start ,finish);
				break;
		}
		*configOk = clockOk && deltaOk;
	}
	
}
	
