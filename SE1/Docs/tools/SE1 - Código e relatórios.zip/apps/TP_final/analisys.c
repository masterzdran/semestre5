
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include "input.h"
#include "system.h"
#include "gen_lib.h"
#include "rtc.h"
#include "timer.h"
#include "lcd.h"
#include "analisys.h"
#include "teclado.h"
#include "lpc2106.h"

/*
O modo de an�lise permite ao utilizador consultar e gerir o registo de temperaturas do sistema. Neste
modo de funcionamento � pois poss�vel visualizar todos os par�metros afectos �s v�rias medi��es de
temperatura registadas no sistema para cada processo de monitoriza��o de temperatura. Adicionalmente,
� ainda permitido eliminar do sistema os registos de temperatura afectos a um processo de monitoriza��o. 
*/

static UINT numCaptures;

    
void deleteAll(UINT *flash_end) {
	int key;	
	
	/* find sector number of flash_data_end*/
	int flash_sector_end = (*flash_end - LPC2106_FLASH_BASE_ADDR)/SECTOR_SIZE;
	
	LCD_clear();
	LCD_print(0,0,MSG_ANALISYS_DELETE_CONFIRM_1); 
	LCD_print(0,1,MSG_ANALISYS_DELETE_CONFIRM_2); 
	
	do key = teclado_scanKey();
	while(key != KEY_OK && key != KEY_CANCEL);
	
	if (key != KEY_CANCEL) {
		LCD_print(0, 0, MSG_ANALISYS_DELETE_BUSY); 
		if (IAP_EraseSec(FLASH_DATA_SECTOR_START, flash_sector_end, LPC2106_CCLK) != 0)
			LCD_print(0, 0, MSG_ANALISYS_DELETE_FAIL);
		else {
		  LCD_print(0, 0, MSG_ANALISYS_DELETE);
		  *flash_end = FLASH_DATA_START;
		}			
		TIMER_delay(LPC2106_BASE_TC0, 2000);
	}
}
        
UINT findByDate() {
        
	RTCTime dateTime;
	getDateTime(&dateTime, MSG_ANALISYS_FIND_BY_DATE, 0, TRUE, 1);
	Capture_temp *p = (Capture_temp *) FLASH_DATA_START;
	/* it is assumed that all the elements in FLASH are in chronological descending order
	i.e. first one (at address FLASH_DATA_START) is the oldest */   
	
	UINT value;
	for(value = 0; value < numCaptures; ++value, ++p) {
		if(p->yy < dateTime.yyyy - 2000)
			continue;
		if(p->yy > dateTime.yyyy - 2000)
			break;
		// p->yy == dateTime.yyyy - 2000
		 
		if(p->MM < dateTime.MM)
			continue;
		if(p->MM > dateTime.MM)
			break;
		// p->MM == dateTime.MM
		
		if(p->dd < dateTime.dd)
			continue;
		if(p->dd > dateTime.dd)
			break;
		// p->dd == dateTime.dd
		
		if(p->hh < dateTime.hh)
			continue;
		if(p->hh > dateTime.hh)
			break;
		 // p->hh == dateTime.hh
		 
		if(p->mm < dateTime.mm)
			continue;
		if(p->mm > dateTime.mm)
			break;
		
		return value;            
	}		
					
	return (value == 0) ? 0 : value - 1;	
}
    
    
UINT findByNum() {
	
	char toDisplay[MAX_X+1];
	itoa(numCaptures, toDisplay, 10,1,0); /* convert numCaptures to string */
	/* concatenate numCaptures with analisys message into toDisplay*/
    strcat(toDisplay, MSG_ANALISYS_FIND_BY_NUM); 
	
	UINT value; 	
	BOOL inputOk; // false when user cancels input 
	do {
		inputOk = getUInt(&value, toDisplay, 0, TRUE, 1);
	}
	while(!inputOk);
	
	return (value - 1);
}
        
void CaptureToString (Capture_temp *t, char *string) {
    char *p = string;
    /* Construction of 1st half of string to be displayed on LCD: Date*/
    itoa(t->yy, p, 10,2,0); 
    p += 2;
    *p++ = '/';
    itoa(t->MM, p, 10,2,0); 
    p += 2;
    *p++ = '/';
    itoa(t->dd, p, 10,2,0); 
    p += 2;
    *p++ = ' ';
    itoa(t->hh, p, 10,2,0); 
    p += 2;
    *p++ = ':';
    itoa(t->mm, p, 10,2,0); 
    p += 2;
    *p++ = '\0';
    /* 1st half of string contains (15 positions): "yy/MM/dd hh:mm'\0'" */
        
    /* Construction of 2nd half of string to be displayed on LCD: Temperature and N� records */
    /* temperature format
            bit 15: sign ('1' means negative, '0' means positive)
            bits 14-8: integer part 
            bit 7: half degree ('1' means .5, '0' means .0)
            bits 6-0: don't care
    */
    
    itoa((t->temperature>>8 ), p, 10,2,1);
    p += 3; /* Temperature in the range [+125 -55]�C */
    *p++ = '.';
    *p++ = ((t->temperature & 0x80)==0x80 ?'5':'0'); /* half degree */
    *p++ = 0xEB;
    *p++ = 'C';
    *p++ = ' ';
    *p++ = ' ';
    *p++ = ' ';
    *p++ = ' ';
    *p++ = ' ';
    itoa(t->capture_num, p, 10,4,0);
    /* 2nd half of string contains (max 16 positions): "snnn.n�C   nnnn'\0'" */
    }
    
void showCapture(UINT value) {
	int key;
	
	LCD_clear();
	Capture_temp *capt;
	char data[31];
	
	do {
		
		capt = (Capture_temp *) (FLASH_DATA_START + value * sizeof(Capture_temp));
		CaptureToString (capt, data); 
		LCD_print(0, 0, data);
		LCD_print(0,1, &data[15]);
		
		switch(key=teclado_getKey()) {
			case KEY_LEFT:
			value = (value == 0) ? numCaptures-1 : value - 1;
			break;
		case KEY_RIGHT:
			value = (value == numCaptures-1) ? 0 : value + 1;
			break;
		}
	}
	while (key!= KEY_OK);
}

    

void startAnalisys(UINT *flash_data_end) {
    UINT value=1;
    
    numCaptures = (*flash_data_end - FLASH_DATA_START) / sizeof (Capture_temp);
    
    enum Selection { VISUALIZE, FIND_BY_DATE, FIND_BY_NUM, DELETE, BACK };
    static enum Selection selection = VISUALIZE;

    static const char *options[] = {
        OPTION_ANALISYS_VISUALIZE,
        OPTION_ANALISYS_FIND_BY_DATE,
        OPTION_ANALISYS_FIND_BY_NUM,
        OPTION_ANALISYS_DELETE,
        OPTION_ANALISYS_BACK
    };
    
    if (numCaptures==0)
    {
     LCD_clear();
     LCD_print(0,0,MSG_ANALISYS_NO_DATA);
     TIMER_delay(LPC2106_BASE_TC0, 5000);
     return;
    } 

    while((selection = getOption(MSG_ANALISYS, options,5, selection)) != BACK) {

        switch(selection) {     
            case VISUALIZE:
                value = 0;
                showCapture(value);
                break;
                
            case FIND_BY_DATE:
                value = findByDate();
                if (value> numCaptures-1 ) {
                  LCD_clear();
                  LCD_print(0,0,MSG_ANALISYS_NO_DATA);
                  TIMER_delay(LPC2106_BASE_TC0, 5000);
                }
                else
                showCapture(value);
                break;
                
            case FIND_BY_NUM:
                value = findByNum();
                if (value > numCaptures -1 ) {
                  LCD_clear();
                  LCD_print(0,0,MSG_ANALISYS_NO_DATA);
                  TIMER_delay(LPC2106_BASE_TC0, 5000);
                }
                else
                  showCapture(value);
				break;
                
            case DELETE:
                deleteAll(flash_data_end);
                return;
        }
    }
}


    
