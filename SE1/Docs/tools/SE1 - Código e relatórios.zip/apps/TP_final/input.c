
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include "input.h"
#include "system.h"
#include "rtc.h"
#include <lcd.h>
#include <teclado.h>


static inline void processNumericKey(UINT *value, int keyCode, BOOL echo) {
	*value = (*value * 10) + keyCode;	// Convert key code to integer
	if(echo)
		LCD_write_data4(keyCode + '0');// Echo to LCD
}

int getOption(const char *msg, const char *options[], const int optionsCount, int selected) {
	LCD_clear();
	
	int i = selected;
	
	LCD_print(0, 0, msg);
	LCD_print(0, 1, options[i]);
	
	int key;
	while((key = teclado_getKey()) != KEY_OK) {
		switch(key) {
			case KEY_LEFT:
				i = (i == 0) ? optionsCount - 1 : i - 1;
				break;
			case KEY_RIGHT:
				i = (i == optionsCount - 1) ? 0 : i + 1;
				break;
		}
		LCD_print(0, 1, options[i]);
	}
	
	return i;
}


BOOL getUInt(UINT *value, const char *msg, int lineMsg, BOOL echo, int lineEcho) {
	int key;		
	*value = 0;	
	
	LCD_clear();
	// Print context message
	if(msg != NULL)
		LCD_print(0, lineMsg, msg); 
	
	// Initialize prompt
	if(echo) {		
		LCD_print(0, lineEcho, PROMPT_UINT);// Prompt
		LCD_gotoxy(COL_PROMPT, lineEcho);
		LCD_show_cursor(TRUE);
	}
	
	// Read integer
	while((key = teclado_getKey()) != KEY_OK) {		
		
		// Abort UINT input
		if(key == KEY_CANCEL) {
			*value = 0;
			return FALSE;
		}
		
		// Clear input and try again
		if(key == KEY_RESET) {			
			*value = 0;
			
			// Reset prompt
			if(echo) {
				LCD_print(0, lineEcho, PROMPT_UINT);
				LCD_gotoxy(COL_PROMPT, lineEcho);
			}
		}		
		else if(key < 10) {
			
			// Numeric key, check for overflow
			if((*value * 10 + key) < *value)
				continue; // Overflow detected, skip 
			
			processNumericKey(value, key, echo);
		}
	}
	
	if(echo)
		LCD_show_cursor(FALSE);
	
	return TRUE;	
}


BOOL getDateTime(RTCTime *dateTime, const char *msg, int lineMsg, BOOL echo, int lineEcho) {
		
	LCD_clear();
	// Print context message
	if(msg != NULL)
		LCD_print(0, lineMsg, msg); 
		
	// Initialize prompt
	if(echo) {		
		LCD_print(0, lineEcho, PROMPT_DATE);// Date prompt
		LCD_gotoxy(0, lineEcho);
		LCD_show_cursor(TRUE);
	}

	
	enum State { DAY, MONTH, YEAR, HOUR, MIN };
	enum State state = YEAR;
	
	BOOL validDate = FALSE;
	
	//UINT digitCounter = 0;
	UINT value = 0;
	int key, x = 0;
	
	//                                              012    012    012    012    012
	// Read date and time. x % 3 --> [0, 1, 2] --> "aa/", "mm/", "dd ", "hh:", "mm "
	while((key = teclado_getKey()) != KEY_OK || x % 3 == 1 || !validDate) {
		
		// Abort date and time input
		if(key == KEY_CANCEL) {			
			dateTime->dd = 0;
			dateTime->MM = 0;
			dateTime->yyyy = 0;
			dateTime->hh = 0;
			dateTime->mm = 0;
			return FALSE;
		}
				
		// Clear input and try again
		if(key == KEY_RESET) {
			//digitCounter = 0
			value = x = 0;
		
			// Reset prompt
			if(echo) {
				LCD_print(0, lineEcho, PROMPT_DATE);				
				LCD_gotoxy(x, lineEcho);
			}
			state = YEAR;
			continue; // Get next key
		}
			
		// Numeric key	
		if(key < 10) {
			
			// Convert key to integer and echo to LCD
			processNumericKey(&value, key, echo);
			++x; //++digitCounter;
			
			// Clear 2nd digit after 1st digit is entered
			if(echo && x % 3 == 1) {
				LCD_write_data4(' ');		// clear 2nd digit
				LCD_gotoxy(x, lineEcho);	// move the cursor to the 2nd digit
			}
			
			// Change state when 2 digits were entered
			//if(digitCounter == 2) {
			if(x % 3 == 2) {
				
				switch(state) {
					
				case YEAR:	// Line state: ##/??/?? ??:??								
					
					dateTime->yyyy = value + 2000;
					x = COL_MONTH;
					if(echo)
						LCD_gotoxy(x, lineEcho);
					state = MONTH;
					break;
					
				case MONTH:	// Line state: ##/##/?? ??:??
					
					// Validate month
					if(value >= 1 && value <= 12) {
						dateTime->MM = value;
						x = COL_DAY;
						//LCD_print(COL_MONTH, lineEcho, "dd"); // Clear month
						//LCD_gotoxy(COL_DAY, lineEcho);
						if(echo)
							LCD_gotoxy(x, lineEcho);
						state = DAY;
					}
					else {
						x = COL_MONTH;
						if(echo) {
							LCD_print(x, lineEcho, "mm"); // Clear month
							LCD_gotoxy(x, lineEcho);
						}
					}						
					break;

				case DAY:	// Line state: ##/##/## ??:??
					
					// Validate day -- not really...
					if(value >= 1 && value <= 31) {
						dateTime->dd = value;
						x = COL_HOUR;
						//LCD_print(COL_HOUR, lineEcho, "hh"); // Clear month
						//LCD_gotoxy(COL_HOUR, lineEcho);
						if(echo)
							LCD_gotoxy(x, lineEcho);
						state = HOUR;
					}
					else {
						x = COL_DAY;
						if(echo) {
							LCD_print(x, lineEcho, "dd"); // Reset day
							LCD_gotoxy(x, lineEcho);
						}
					}
					break;
					
				case HOUR:	// Line state: ##/##/## ##:??
					
					// Validate hour
					if(value <= 23) {
						dateTime->hh = value;
						x = COL_MIN;
						if(echo)
							LCD_gotoxy(x, lineEcho);
						state = MIN;
					}
					else {
						x = COL_HOUR;
						if(echo) {
							LCD_print(x, lineEcho, "hh");
							LCD_gotoxy(x, lineEcho);							
						}
					}
					break;
					
				case MIN: // Line state: ##/##/## ##:##
					
					// Validate minutes
					if(value <= 59) {
						dateTime->mm = value;
						x = COL_YEAR;
						if(echo)
							LCD_gotoxy(x, lineEcho);
						state = YEAR;
						validDate = TRUE;
					}
					else {
						x = COL_MIN;
						if(echo) {
							LCD_print(x, lineEcho, "mm");
							LCD_gotoxy(x, lineEcho);
						}
					}
					break;
				}
				//digitCounter = 0;
				value = 0;
			}
		}
	}
	
	if(echo)
		LCD_show_cursor(FALSE);
		
	return TRUE;
}

