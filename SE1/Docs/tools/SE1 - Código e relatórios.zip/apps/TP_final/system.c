
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */
 
#include "input.h"
#include "system.h"
#include <lpc210x.h>
#include <lpc2106.h>
#include <teclado.h>
#include <gpio.h>
#include <led.h>
#include <gen_lib.h>
#include <timer.h>
#include <pll.h>
#include <iap.h>
#include <lcd.h>
#include <i2c.h>
#include <ds1621.h>


UINT flash_end_update() {
  Capture_temp *temp=(Capture_temp *)FLASH_DATA_START;
  Capture_temp comp_struct; 
  
  memset(&comp_struct,0xff,CAPTURE_STRUCT_SIZE);
  
  
  while(memcmp(&comp_struct,temp,CAPTURE_STRUCT_SIZE)!=0)
  temp++;
  
  return (UINT)temp;
}

Mode getMode(Mode currentMode) {
		
	static const char *options[] = {	
		OPTION_MODE_CONFIG,		// 0 --> CONFIG
		OPTION_MODE_CAPTURE,	// 1 --> CAPTURE
		OPTION_MODE_ANALISYS	// 2 --> ANALISYS
	};
	
	return (Mode) getOption(MSG_MODE, options, 3,currentMode);
}


Mode systemInit(UINT *flash_end) {
	
	LPC2106_BASE_PLL->PLLCON = 0;           // PLL desligado
	
    LPC2106_BASE_PLL->PLLFEED = 0xAA;       // Seq. para efectivar a
    LPC2106_BASE_PLL->PLLFEED = 0x55;       //  escrita no PLLCON
	
    /* Obriga o PCLK ser 1/4 de CCLK  */
	*LPC2106_BASE_APBDIV_REG = 0;

    /* Iniciar o TIMER0 */
	TIMER_init(LPC2106_BASE_TC0, LPC2106_PCLK * TC0_PERIOD_SEC); //Base tempo 1 ms
	
    /* Iniciar o TECLADO */	
	teclado_init(PIN_KEYPAD_COL0, PIN_KEYPAD_LIN0);

    /* Iniciar o LED */	
	LED_init(LED_PIN);	
	
	/* Iniciar o LCD */
	LCD_init(PIN_RS, PIN_RW, PIN_EN, PIN_DB7, LPC2106_BASE_TC0);
    
    /* Inicia RTC */
    rtc_init();
    
    /* Inicializar I2C (GPIO)  */
    LPC2106_BASE_PCB0->PINSEL0 &= 0xFFFFFF0F;
    i2c_init();
    
    /* Inicializar DS1621 */
    DS1621_config(1, DS1621_ADDR);       /* Configura o DS1621 para one shot */
    TIMER_delay(LPC2106_BASE_TC0, 10);   /* Delay 10ms */
	
	/* Actualiza o valor final da flash */
	*flash_end=flash_end_update();
	
	
	return CONFIG;
}
