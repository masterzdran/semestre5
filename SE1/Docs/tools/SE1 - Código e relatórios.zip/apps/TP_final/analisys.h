
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef _ANALSYS_H_
#define _ANALSYS_H_

/* 
 * ***********************************************
 * ANALISYS MESSAGES
 * ***********************************************
 * */

#define MSG_ANALISYS                    "Analise:"

#define	OPTION_ANALISYS_VISUALIZE       "<  Visualizar  >"
#define	OPTION_ANALISYS_DELETE          "<    Apagar    >"
#define	OPTION_ANALISYS_FIND_BY_DATE    "<Proc. por data>"
#define	OPTION_ANALISYS_FIND_BY_NUM     "<Proc. por num.>"
#define OPTION_ANALISYS_BACK            "<  Retroceder  >"       
        		  
#define MSG_ANALISYS_DELETE             "Reg.s eliminados"
#define MSG_ANALISYS_DELETE_CONFIRM_1   "TEM A CERTEZA?  "
#define MSG_ANALISYS_DELETE_CONFIRM_2   "C:OK       A:RET"
#define MSG_ANALISYS_DELETE_FAIL        "ERRO!! :("
#define MSG_ANALISYS_NO_DATA            "Sem registos! :("
#define MSG_ANALISYS_DELETE_BUSY        "Apagando...     "
#define MSG_ANALISYS_FIND_BY_DATE       "D/H inicio:"
#define MSG_ANALISYS_FIND_BY_NUM        " disponiveis"

#define ANALISYS_PROMPT_FIND_BY_NUM 	"Mostrar n: ?"

void startAnalisys(UINT *flash_data_end);

#endif
