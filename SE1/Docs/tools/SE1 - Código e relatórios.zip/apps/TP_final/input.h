
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef _INPUT_H_
#define _INPUT_H_

#include "system.h"
#include "rtc.h"

/* 
 * ***********************************************
 * PROMPT MESSAGES
 * ***********************************************
 * */

#define PROMPT 			"->              "
#define PROMPT_UINT		"->           [--" 	// 32 bits unsigned, 10 digits
#define PROMPT_DATE		"aa/mm/dd hh:mm  "

/* 
 * ***********************************************
 * PROMPT INPUT START COLUMN
 * ***********************************************
 * */

#define COL_PROMPT	3

#define COL_YEAR	0
#define COL_MONTH	3
#define COL_DAY		6
#define COL_HOUR	9
#define COL_MIN		12


int getOption(const char *msg, const char *options[], const int optionsCount, int selected);

BOOL getUInt(UINT *value, const char *msg, int lineMsg, BOOL echo, int lineEcho);

BOOL getDateTime(RTCTime *dateTime, const char *msg, int lineMsg, BOOL echo, int lineEcho);

#endif
