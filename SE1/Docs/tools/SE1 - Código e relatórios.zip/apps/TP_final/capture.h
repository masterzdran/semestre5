
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */
 
#ifndef __CAPTURE__H__
#define __CAPTURE__H__

#include "rtc.h"
#include "system.h"

void startCapture(const RTCTime *initDate ,const  RTCTime *finishDate, UINT period, UINT *flash_end );

/* 
 * ***********************************************
 * CAPTURE MESSAGES
 * ***********************************************
 * */

/*                            "                "*/
#define	CAPTURE_WAIT          "Espera inicio"
#define	CAPTURE_MSG           "Captura"
#define	CAPTURE_CURRENT_TEMP  "Temp act:"
#define	CAPTURE_EXIT          ""
#define CAPTURE_SAVE          "REC"
#define CAPTURE_MEM_FULL      "Memoria cheia!! "
#define CAPTURE_TIME_1        "Data inicial    "
#define CAPTURE_TIME_2        "ultrapassada !! "
#define BLANK                 "   "



        

#endif

