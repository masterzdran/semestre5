
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include "capture.h"
#include "system.h"
#include "input.h"
#include <teclado.h>
#include <rtc.h>
#include <timer.h>
#include <ds1621.h>
#include <lpc2106.h>
#include <lcd.h>
#include <gen_lib.h>
#include <iap.h>
#include <led.h>

/*
 Quando a funcionar no modo de captura, o sistema dever� aferir e guardar em mem�ria n�o vol�til os
v�rios valores de temperatura ambiente obtidos durante o per�odo de tempo em que decorre o processo de
monitoriza��o. Para cada valor de temperatura guardado em mem�ria, numa gama de valores
compreendidos entre os -10�C e os +50�C com precis�o de 0,5�C, o sistema dever� ainda armazenar a
data, no formato aa/mm/dd, e a hora, no formato hh:mm, a que essa medi��o de temperatura foi realizada.
*/

static void dot_print(int x, int y,char sec) {
	static char sec_ant;
	static int dot_i;
   
	char *dot_num[]={".","..","...","   "};
   
	if(sec != sec_ant) {
		dot_i = dot_i+1;
     
		if (dot_i > 3 || dot_i < 0)
			dot_i = 0;
     
		LCD_print(x, y, dot_num[dot_i]);
	}
   
	sec_ant = sec;
	return;
}

static void capture_init(const RTCTime *initDate ) {
	rtc_SetAlarm(initDate, DATE_TIME);   				/* Define o alarme para o inicio das capturas */
	TIMER_init(LPC2106_BASE_TC1, LPC2106_PCLK * 60); 	/* Base tempo do timer � 1 minuto */
	TIMER_stop(LPC2106_BASE_TC1);
}

void startCapture(const RTCTime *initDate , const RTCTime *finishDate, UINT period, UINT *flash_end ) {

	int key,delay;
	RTCTime current_time;
	short temperature;
	char temp_str[6];
	Capture_temp capture_memory[CAPTURE_MEM_SIZE];
	int current_block;
	int current_pos_block;
	int sample_num=0;
	BOOL first=TRUE;

	enum CAPTURE_STATE { WAIT_START, CAPTURING };
	enum CAPTURE_STATE state = WAIT_START;
  
  
	/* Verifica se a data de inicio j� foi ultrapassada */
	rtc_GetTimeStamp(&current_time);
	if ( dateTimeComparator(&current_time , initDate ) > 0) {
		LCD_clear();
		LCD_print(0, 0, CAPTURE_TIME_1);
		LCD_print(0, 1, CAPTURE_TIME_2);
		TIMER_delay(LPC2106_BASE_TC0, (3/TC0_PERIOD_SEC));          /* Delay 3s */
		return;
	}
  
	capture_init(initDate);

	do {
      
		switch(state) {
    
		case WAIT_START:
			LCD_clear();
			LCD_print(0, 0, CAPTURE_WAIT);

			while ((key = teclado_scanKey()) != KEY_CANCEL) {
				rtc_GetTimeStamp(&current_time);
				dot_print(sizeof(CAPTURE_WAIT) - 1, 0, current_time.ss);

				if ( rtc_ReadAlarm() == 0 || dateTimeComparator(&current_time, initDate) > 0 ) { 
					state = CAPTURING;
					TIMER_start(LPC2106_BASE_TC1);
					break;
				}
			}
		break;
      
		case CAPTURING:
			LCD_clear();
			LCD_print(0, 0, CAPTURE_MSG);
		  
			while (dateTimeComparator(&current_time,finishDate) < 0 && ( key = teclado_scanKey()) != KEY_CANCEL ) {
		  
				DS1621_start_conversion(DS1621_ADDR);
				TIMER_delay(LPC2106_BASE_TC0, (0.01 / TC0_PERIOD_SEC)); /* Delay 10ms */
				delay = 0;
				
				while ((DS1621_read_status(DS1621_ADDR)& 0x80) != 0x80 && delay++< 5000);
				
				TIMER_delay(LPC2106_BASE_TC0, (0.01/TC0_PERIOD_SEC)); /* Delay 10ms */
				temperature = DS1621_read_temperature (DS1621_ADDR);  /* le temperatura */
					
				rtc_GetTimeStamp(&current_time); /* Obtem estrutura RTCTime */

				dot_print(sizeof(CAPTURE_MSG)-1, 0, current_time.ss);  /* Imprime ... */
			
				DS1621_conv_str(temperature, temp_str); /* Converte valor lido em string */
				LCD_print(0, 1, CAPTURE_CURRENT_TEMP);  /* Escreve "Temperatura" */
				LCD_print_direct(temp_str);             /* Escreve temp */
				LCD_write_data4(0xEB);                  /* Escreve caracter * */
				LCD_write_data4('C');

				if ((short)TIMER_elapsed(LPC2106_BASE_TC1, 0) == (short)period || first ==TRUE )    /* Se atingiu o tempo entre amostras ou acabou de entrar em captura */
				{
					first = FALSE;
					TIMER_reset(LPC2106_BASE_TC1);
					
					current_block = ((*flash_end-FLASH_DATA_START) / FLASH_BLOCK_SIZE); /* calcula numero de blocos preenchidos */
					current_pos_block = ((*flash_end-FLASH_DATA_START) - (current_block*FLASH_BLOCK_SIZE)) / CAPTURE_STRUCT_SIZE; /* calcula indice no bloco actual */
				
					/* Copia o bloco da FLASH para a mem�ria */
					memcpy(capture_memory, (int *)(FLASH_DATA_START + (current_block * FLASH_BLOCK_SIZE)), FLASH_BLOCK_SIZE);
				
					/* Actualiza a informa��o da memoria com a ultima amostra */
					capture_memory[current_pos_block].yy = current_time.yyyy - 2000;
					capture_memory[current_pos_block].MM = current_time.MM;
					capture_memory[current_pos_block].dd = current_time.dd;
					capture_memory[current_pos_block].hh = current_time.hh;
					capture_memory[current_pos_block].mm = current_time.mm;
					capture_memory[current_pos_block].temperature = temperature;
					capture_memory[current_pos_block].capture_num = sample_num;
				  
					/* Actualiza variaveis */
					sample_num++;
					
					/* Verifica se memoria cheia */
					if ( ( *flash_end + CAPTURE_STRUCT_SIZE ) > FLASH_DATA_END ) {
						LCD_clear();
						LCD_print(0,0, CAPTURE_MEM_FULL);
						TIMER_delay(LPC2106_BASE_TC0, (3 / TC0_PERIOD_SEC));            /* Delay 3s */
						return;
					}
			
					/* Actualiza a informa��o da memoria FLASH com a ultima amostra */
					if (IAP_FlashWrite ((FLASH_DATA_START + (current_block * FLASH_BLOCK_SIZE)), &capture_memory, FLASH_BLOCK_SIZE, LPC2106_CCLK) == 0) {
				 
					   
					   *flash_end = *flash_end+CAPTURE_STRUCT_SIZE;         	     /* Actualiza ponteiro para endere�o final */
					   
					   LED_set(LED_PIN);                                             /* Activa LED */
					   
					   /* Escreve REC no LCD */
					   LCD_print((MAX_X-sizeof(CAPTURE_SAVE)-1),0, CAPTURE_SAVE);
					   TIMER_delay(LPC2106_BASE_TC0, (1/TC0_PERIOD_SEC));            /* Delay 1s */
					   LCD_print((MAX_X-sizeof(CAPTURE_SAVE)-1),0, BLANK);

					   LED_clear(LED_PIN);                                           /* Desactiva LED */
					}
				}
			}
			return;
		}
	} while (key!= KEY_CANCEL); 

	return;
}







