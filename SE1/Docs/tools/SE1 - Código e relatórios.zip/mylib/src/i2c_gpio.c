
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Luís Brás			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include <gpio.h>
#include <timer.h>
#include <lpc2106.h>
#include <i2c_gpio.h>

void i2c_init() {
	
	/* Configurar pinos como GPIO */
	LPC2106_BASE_PCB0->PINSEL0 &= 0xFFFFFF0F;
	
	/* Configurar pinos como saídas */
	GPIO_init(1, SDA_PIN, 1);
	GPIO_init(1, SCL_PIN, 1);
	
    /* Libertar as linhas */
    LPC2106_BASE_GPIO0->IOSET = (1 << SDA_PIN);   /* Coloca linha dados a 1 para receber bit */
    LPC2106_BASE_GPIO0->IOSET = (1 << SCL_PIN);   /* Coloca linha dados a 1 para receber bit */
}

static char i2c_gpio_read_bit() {
	char b;
	LPC2106_BASE_GPIO0->IOSET = (1 << SDA_PIN);   /* Coloca linha dados a 1 para receber bit */
	/* Clock pulse */
	TIMER_delay(LPC2106_BASE_TC0, 1);            /* Delay 1ms */
	LPC2106_BASE_GPIO0->IOSET = (1 << SCL_PIN);
	TIMER_delay(LPC2106_BASE_TC0, 1);            /* Delay 1ms */
	b = (LPC2106_BASE_GPIO0->IOPIN >> SDA_PIN) & 1;  /* Ler valor na linha de dados */
	LPC2106_BASE_GPIO0->IOCLR = (1 << SCL_PIN);      /* Clock retorna a 0 */
	return b;
}

static void i2c_gpio_write_bit(char b) {
	if(b & 1)                                       /* Verifica se o bit é "0" ou "1" */
	{
		LPC2106_BASE_GPIO0->IOSET = (1 << SDA_PIN);   /* Coloca linha de dados a "1" */
	} 
	else 
	{
		LPC2106_BASE_GPIO0->IOCLR = (1 << SDA_PIN);   /* Coloca linha de dados a "0" */
	}
	/* Clock pulse */
	TIMER_delay(LPC2106_BASE_TC0, 1);            /* Delay 1ms */
	LPC2106_BASE_GPIO0->IOSET = (1 << SCL_PIN);
	TIMER_delay(LPC2106_BASE_TC0, 1);            /* Delay 1ms */
	LPC2106_BASE_GPIO0->IOCLR = (1 << SCL_PIN);
}

static void i2c_gpio_write_start() {
	LPC2106_BASE_GPIO0->IOSET = (1 << SDA_PIN) | (1 << SCL_PIN);  /* SCL e SDA a "1" */
	TIMER_delay(LPC2106_BASE_TC0, 5);            /* Delay 5ms */
	LPC2106_BASE_GPIO0->IOCLR = (1 << SDA_PIN);   /* Transição de "1" a "0" do SDA */
	TIMER_delay(LPC2106_BASE_TC0, 5);            /* Delay 5ms */
	LPC2106_BASE_GPIO0->IOCLR = (1 << SCL_PIN);   /* Clock a "0" para envio de bit seguinte */
}

static void i2c_gpio_write_stop() {
	LPC2106_BASE_GPIO0->IOCLR = (1 << SDA_PIN) | (1 << SCL_PIN);  /* SCL e SDA a "0" */
	TIMER_delay(LPC2106_BASE_TC0, 5);            /* Delay 5ms */
	LPC2106_BASE_GPIO0->IOSET = (1 << SCL_PIN);   /* SCL a "1" */
	TIMER_delay(LPC2106_BASE_TC0, 5);            /* Delay 5ms */
	LPC2106_BASE_GPIO0->IOSET = (1 << SDA_PIN);   /* Transição de "0" a "1" do SDA */
}

inline static void i2c_gpio_write_nack() {
	i2c_gpio_write_bit (1);                       /* SDA a "1" */
}

inline static void i2c_gpio_write_ack() {
	i2c_gpio_write_bit (0);                       /* SDA a "0" */
}

static char i2c_gpio_read_ack() {
	return (i2c_gpio_read_bit());
}

static char i2c_gpio_read_byte() {
	char data;
	int i;
	for (i=0; i<8; ++i) {
		data = (data << 1) + i2c_gpio_read_bit();
		}
		return data;
	}
		
static void i2c_gpio_write_byte(char data) {
	int i;
	for (i=0; i<8; ++i) {
		i2c_gpio_write_bit((data & 0x80) == 0x80 ? 1 : 0 );
		data <<= 1;
		}
}

int i2c_read_bytes(int nbytes, char address, const void *data) {
  
  int flag = 1; // 1: OK - 0: NOK
  char *p = (char*) data;
  int i;
  
	i2c_gpio_write_start();
	i2c_gpio_write_byte((address<<=1)+1); /* R/W=1 => leitura*/
	if(i2c_gpio_read_ack()==0) {
		for (i=nbytes; i>0; i--) {
			*p = i2c_gpio_read_byte();
			*p++;
			if (i>1)                          /* Se for o ultimo byte... */  
				i2c_gpio_write_ack();
		}
		i2c_gpio_write_nack(); 	
	}
	else
		flag = 0;
	i2c_gpio_write_stop();
	return flag;
}

int i2c_write_bytes(int nbytes, char address, const void *data) {
	
	int flag = 1; // 1: OK - 0: NOK
	char *p = (char*) data;
	
	i2c_gpio_write_start();
	i2c_gpio_write_byte(address<<=1);  /* R/W=0 => escrita*/
	if(i2c_gpio_read_ack()==0) {
		int i;
		for (i=nbytes; i>0; i--) {
			i2c_gpio_write_byte(*p);
			*p++;
			if (i2c_gpio_read_ack()!=0) {
				flag = 0;
				break;
			}
		}
	}
	else
		flag =0;
	i2c_gpio_write_stop();
	return flag;
}
