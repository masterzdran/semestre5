
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include <gen_lib.h>
#include <gpio.h>
#include <lpc210x.h>
#include <timer.h>


void bit_set(unsigned *address, int bit) {
	*address |= (1 << bit);	
}

void bit_clear(unsigned *address, int bit) {
	*address &= ~(1 << bit);
}

void toggle(unsigned pin, unsigned state, unsigned n, unsigned period, LPC210XP_BASE_TC timer_id) {		

	GPIO_output(~state&1, pin, 1); // Inverse state	
	
	/* toggle pin <n> times with <period> ms interval */
	while(n--) {
		GPIO_output(state, pin, 1); // Pin at State
		TIMER_delay(timer_id, period);
		GPIO_output(~state&1, pin, 1); // Clear pin
		if(n==0)
			break;				// Skip delay
		TIMER_delay(timer_id, period);
	}
}

void memset ( void * ptr, char value, int num ) {
	char *p1=(char *)ptr;
	
	while (num--)
		*p1++=value;

}

int memcmp(const void *s1 , const void *s2, int size) {
	const char *p1=(const char *)s1;
	const char *p2=(const char *)s2;
	
	while (size--) {
		if (*p1++!=*p2++)
		  return 1;
	}
    return 0;
}

void memcpy(void *dst , const void *src, int size) {
	char *p1=(char *)dst;
	const char *p2=(const char *)src;
	
	while (size--)
		*p1++=*p2++;
}


void strreverse(char* begin, char* end) {
	char aux;
	while(end>begin)
		aux=*end, *end--=*begin, *begin++=aux;
}


void itoa(int value, char* str, int base, int width, int show_sign) {
	static char num[] = "0123456789abcdefghijklmnopqrstuvwxyz";
	char* wstr=str;
	int sign;

	// Validate base
	if (base<2 || base>35){ *wstr='\0'; return; }

	// Take care of sign
	if ((sign=value) < 0) value = -value;

	// Conversion. Number is reversed.
	do {
      *wstr++ = num[value%base];
      --width;
    }  
    while(value/=base);
    
    while(width-->0)
    *wstr++='0';
    
    if (show_sign)
    {
	  if(sign<0)
       *wstr++='-';
      else
       *wstr++='+';
    }
     
	*wstr='\0';

	// Reverse string
	strreverse(str,wstr-1);
}


char *strcat(char *dest, const char *src) {
    unsigned int i,j;
    for (i = 0; dest[i] != '\0'; i++);
    for (j = 0; src[j] != '\0'; j++)
        dest[i+j] = src[j];
    dest[i+j] = '\0';
    return dest;
}
