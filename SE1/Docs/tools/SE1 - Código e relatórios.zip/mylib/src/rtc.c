
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

/* Rotinas para o RTC */

#include "system.h"
#include "lpc210x.h"
#include "lpc2106.h"
#include "rtc.h"
#include <stdlib.h>

#define PCRTC 0x200 /* RTC power/clock control bit */

/* Registers in the RTC other than those that are part of the Prescaler 
 * are not affected by chip Reset !! */

/* In the Gregorian calendar three criteria determine which years will be leap years:
1. Every year that is evenly divisible by four is a leap year; 
2. of those years, if it can be evenly divided by 100, it is NOT a leap year, unless 
3. the year is evenly divisible by 400. Then it is a leap year. 
* RTC perfoms this verification automatically
*/


/* CTIME0 
 * 32 bit REG (bits not specified are reserved) */
 #define CTIME0_DOW		0x7000000	/* [26:24] 	Day of Week - range:[0 6] */
 #define CTIME0_HOUR	0x1f0000	/* [20:16]	Hours 		- range:[0 23] */
 #define CTIME0_MIN		0x3f00		/* [13:8] 	Minutes 	- range:[0 59] */
 #define CTIME0_SEC		0x3f		/* [5:0] 	Seconds 	- range:[0 59] */

/* CTIME1 
 * 32 bit REG (bits not specified are reserved) */
 #define CTIME1_YEAR	0xfff0000 	/* [27:16]	Year		- range:[0 4095] */
 #define CTIME1_MON		0xf00 		/* [11:8]	Month		- range:[1 12] */
 #define CTIME1_DOM		0x1f 		/* [4:0]	Day of Month- range:[1 28|29|30|31]  */

/* CTIME2 
 * 32 bit REG (bits not specified are reserved) */ 
 #define CTIME2_DOY		0xfff 		/* [11:0]	Day of Year - range:[1 365|366]  */

void rtc_init() {
	LPC2106_BASE_PCON->PCONP |= PCRTC;		/* Power on RTC peripheral */
    LPC2106_BASE_RTC->CCR = 0x2; 			/* Disable time counters and reset CTC */
	LPC2106_BASE_RTC->PREINT = myPREINT; 	/* Set PREINT */
    LPC2106_BASE_RTC->PREFRAC = myPREFRAC; 	/* Set PREFRAC */
	LPC2106_BASE_RTC->ILR = 0x3; 			/* Clear interrupts */
	LPC2106_BASE_RTC->ILR = 0x0; 			/* Disable interrupts */
	LPC2106_BASE_RTC->CIIR = 0x0; 			/* CIIR disabled */
	LPC2106_BASE_RTC->AMR = 0xFF; 			/* Alarm disabled */
	/* dummy initialization 00:00:00 1-Jan-1900*/
	rtc_SetTime(0, 0, 0);
	rtc_SetDate(1, 1, 1900);
	LPC2106_BASE_RTC->CCR = 0x1; 			/* Enable time counters and CTC */
}

void rtc_SetTime(char hours, char minutes, char seconds) {
	LPC2106_BASE_RTC->CCR = 0x2; /* Disable time counters and reset CTC */
	LPC2106_BASE_RTC->HOUR = hours;
	LPC2106_BASE_RTC->MIN = minutes;
	LPC2106_BASE_RTC->SEC = seconds;
	LPC2106_BASE_RTC->CCR = 0x1; /* Enable time counters and CTC */
}

void rtc_SetDate(char day, char month, short year) {
	LPC2106_BASE_RTC->YEAR = year;
	LPC2106_BASE_RTC->MONTH = month;
	LPC2106_BASE_RTC->DOM = day;
}

void rtc_SetDOW(short DayOfWeek) {
	LPC2106_BASE_RTC->DOW = DayOfWeek;
}

void rtc_GetTimeStamp(RTCTime *t) {
	int tmp = LPC2106_BASE_RTC->CTIME0;
	t->ss = (tmp & CTIME0_SEC);			/* seconds */
	t->mm	= (tmp & CTIME0_MIN)>>8;	/* minutes */
	t->hh	= (tmp & CTIME0_HOUR)>>16;	/* hours */
	t->dow	= (tmp & CTIME0_DOW)>>24;	/* day of the week */
	tmp =  LPC2106_BASE_RTC->CTIME1;
	t->dd	= (tmp & CTIME1_DOM);		/* day of the month */
	t->MM	= (tmp & CTIME1_MON)>>8;	/* month */
	t->yyyy	= (tmp & CTIME1_YEAR)>>16;	/* year */
	t->doy	= LPC2106_BASE_RTC->CTIME2 & CTIME2_DOY; /* day of the year*/
}

void rtc_SetAlarm (const RTCTime *t, char filter) {
		
	LPC2106_BASE_RTC->AMR = 0xFF; /* all alarms masked */
	LPC2106_BASE_RTC->ILR = 0x3; /* Clear interrupts */
	/* Set of alarms registers*/
	LPC2106_BASE_RTC->ALHOUR = t->hh;	/* Hour value - [0,23] */
	LPC2106_BASE_RTC->ALMIN = t->mm;	/* Minute value - [0,59] */
	LPC2106_BASE_RTC->ALSEC = t->ss;	/* Second value - [0,59] */
	LPC2106_BASE_RTC->ALDOW = t->dow;	/* Day of week value - [0,6] */
	LPC2106_BASE_RTC->ALYEAR = t->yyyy;	/* Year value - [0,4095] */
	LPC2106_BASE_RTC->ALDOY = t->doy;	/* Day of year value - [1,365|366] */
	LPC2106_BASE_RTC->ALMON = t->MM;	/* Month value - [1,12] */
	LPC2106_BASE_RTC->ALDOM = t->dd;	/* Day of the month value - [1,28|29|30|31] */	
	/* set alarm mask according filter value */
	LPC2106_BASE_RTC->AMR = ~filter; 
}
	
int rtc_ReadAlarm () {
	/* return 0 if alarm register generated an interrupt */
	if ((LPC2106_BASE_RTC->ILR & 0x2) == 0x2) {
		/* clear Interrupt Location Register */
		LPC2106_BASE_RTC->ILR = (LPC2106_BASE_RTC->ILR & 0x2);
		return 0;
	}
	else
		return -1;
}

void rtc_SetAlarmInterval (int minutes) {
	/* minutes: max 1440 */
	int n_days;
	int n_hours;
	int n_minutes;
	RTCTime t;
	
	LPC2106_BASE_RTC->AMR = 0xFF; /* all alarms masked */
	
	/* it is considered the maximum (n_days: 1; n_hours: 0; n_minutes: 0)
	 * if minutes > 1439 or minutes < 0 */
	if (minutes > 1439 || minutes < 0) {
		n_days = 1;
		n_hours = 0;
		n_minutes = 0;
	}
	else
	{
		n_days = 0;
		n_hours = (int) (minutes / 60);
		n_minutes = minutes - (n_hours*60);
	}
	
	rtc_GetTimeStamp(&t);
	LPC2106_BASE_RTC->ILR = 0x3; /* Clear interrupts */
	LPC2106_BASE_RTC->ALSEC = (int) t.ss;
	
	n_minutes += t.mm;
	if ((n_minutes) > 60) {
		n_minutes -= 60;
		n_hours += 1;
	}
	LPC2106_BASE_RTC->ALMIN = n_minutes;
	
	n_hours += t.hh;
	if ((n_hours) > 23) {
		n_hours -= 23;
		n_days += 1;
	}
	LPC2106_BASE_RTC->ALHOUR = n_hours;
	LPC2106_BASE_RTC->ALDOY = (t.doy + n_days);
	
	LPC2106_BASE_RTC->AMR = 0xD8; /* set seconds, minutes, hours and days alarm mask */
	
}

int dateTimeComparator(const RTCTime *dt1, const RTCTime *dt2) {
	if(dt1->yyyy > dt2->yyyy)
		return 1;
	if(dt1->yyyy < dt2->yyyy)
		return -1;	
	// dt1->yyyy == dt2->yyyy
	
	if(dt1->MM > dt2->MM)
		return 1;
	if(dt1->MM < dt2->MM)
		return -1;		
	// dt1->MM == dt2->MM
	
	if(dt1->dd > dt2->dd)
		return 1;
	if(dt1->dd < dt2->dd)
		return -1;	
	// dt1->MM == dt2->dd
	
	if(dt1->hh > dt2->hh)
		return 1;
	if(dt1->hh < dt2->hh)
		return -1;
	// dt1->hh == dt2->hh
	
	if(dt1->mm > dt2->mm)
		return 1;
	if(dt1->mm < dt2->mm)
		return -1;
	// dt1->mm == dt2->mm
	
	return 0;
}

