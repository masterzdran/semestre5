
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

/* Rotinas para teclado de 4x4 */
#include <gpio.h>
#include <teclado.h>

static const char Matriz_Teclado[16]={1,4,7,14,2,5,8,0,3,6,9,15,10,11,12,13};
// Vector de valores para o teclado utilizado

static int p_col0, p_lin0;

void delay_ms(int);

void teclado_init(int P_COL0, int P_LIN0) {
  p_col0 = P_COL0;
  p_lin0 = P_LIN0;
    GPIO_init(15, p_col0, 4);  //iniciar colunas como saidas
  GPIO_init(0, p_lin0, 4);   //iniciar linhas como entradas
}

int teclado_getKey_inst() {
  //Obter tecla premida neste instante
  //int i, j, _teclado_getKey_inst= 0;
  int i, j, _teclado_getKey_inst= -1;
  
  /* Rotina para teclado de 4x4 */
  /* Parametros de entrada
   * P_COL0 - Pino coluna 0
   * P_LIN0 - Pino linha 0
   * 
   * Paramentros de Saida
   * Valor da tecla premida, 0 para nenhuma tecla premida
   * O varrimento e por coluna */
  
  GPIO_output(7, p_col0, 3);
  for(i = 0; i < 4; ++i) { /* varrimento de coluna */
    GPIO_output(0, p_col0 + i, 1);
    for(j = 0; j < 4; ++j) { /* varrimento de linha */
      if(GPIO_input(p_lin0 + j, 1) == 0)
        _teclado_getKey_inst = Matriz_Teclado[(i * 4)+j];
        //obtem o valor da tecla premida atraves do vector de valores
    }
    GPIO_output(7, p_col0, 3);    
  }
  
  return _teclado_getKey_inst; //retorna o valor premido
}

int teclado_getKey() {
  //Obter tecla premida, retorna apos largar a tecla

  int key, delay=0;
  
  do {
    while((key = teclado_getKey_inst()) == -1); 
    delay_ms(10);                         //Para debounce   
  }
  while(key != teclado_getKey_inst());
  
  // Largar tecla ou timeout
  while(teclado_getKey_inst() != -1 && delay++ < 1000);
    
  return key;
}

int teclado_scanKey() {
  //Obter tecla premida, retorna apos largar a tecla, n�o bloqueante

  int key, delay = 0;
  
  if((key = teclado_getKey_inst()) == -1)
    return -1;
  
  // Tecla pressionada
  delay_ms(10);                           //Para debounce   
  if(key != teclado_getKey_inst())    //Bounce detected...
    return -1;
  
  while(teclado_getKey_inst() != -1 && delay++ < 1000);
  
    return key;
}

void get_key_teclado (int* keys, int num_char )
{
  int i;
  for (i=0;i<num_char;i++)
    keys[i] = teclado_getKey();
}
