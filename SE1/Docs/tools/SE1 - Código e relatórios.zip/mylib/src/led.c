
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

/* Rotinas para I/F com um led */
#include <led.h>
#include <gpio.h>

void LED_init(int P_LED) {
	// Inicializa o GPIO para o LED segundo o pino configurado P_LED	
	GPIO_init(1, P_LED, 1);
	LED_clear(P_LED);
}

void LED_set(int P_LED) {
	// Coloca a 0 o pino configurado P_LED
	GPIO_output(0, P_LED, 1);
}

void LED_clear(int P_LED) {
	// Coloca a 1 o pino configurado P_LED
	GPIO_output(1, P_LED, 1);
}
