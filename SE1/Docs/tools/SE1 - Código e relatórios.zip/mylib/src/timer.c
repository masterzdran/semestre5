
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Luís Brás			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

/* Rotinas para o timer */
#include <timer.h>
#include <gen_lib.h>

void TIMER_init(LPC210XP_BASE_TC timer_id , unsigned int period) {
//  timer_id->IR = 0xFFFFFFFF; // Clear interrupt reg */
  timer_id->TCR = 0x2;	     // Timer Counter and Prescale Counter disabled (bit 0) and reset (bit 1) */

  timer_id->CTCR = 0x0;      // Set Timer Mode

  timer_id->PR = period;     // specifies the maximum value for the PC; 
                             // TC increments on every PCLK when PR = 0, 
                             // every 2 PCLKs when PR = 1, etc.
  timer_id->TCR = 0x1;		   // Clear reset and enabled!
}

void TIMER_start(LPC210XP_BASE_TC timer_id) {
	bit_set(&timer_id->TCR,0);  //arranca o timer , TCR.0=1
}

void TIMER_stop(LPC210XP_BASE_TC timer_id) {
	bit_clear(&timer_id->TCR,0);  //para o timer , TCR.0=0
}

void TIMER_delay(LPC210XP_BASE_TC timer_id, unsigned int delay) {
	//efectua um delay com o periodo de tempo especificado
	
	int now;
	
	timer_id->PC=0;                  // Reset do Prescale Counter
	now=TIMER_elapsed(timer_id, 0);  //obtem o valor actual do timer
	
	while (TIMER_elapsed(timer_id, now)<delay);
	//Loop enquanto o valor de delay não for ultrapassado
}

unsigned TIMER_elapsed(LPC210XP_BASE_TC timer_id, unsigned int start_time) {	
	return timer_id->TC - start_time;
}

void TIMER_reset (LPC210XP_BASE_TC timer_id) {
    bit_set(&timer_id->TCR,1);    //timer reset
    bit_clear(&timer_id->TCR,1);
}
         


