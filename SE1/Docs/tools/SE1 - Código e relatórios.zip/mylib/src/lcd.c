
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include "gpio.h"
#include "lcd.h"
#include "timer.h"

static int RS, RW, EN, DB7;

static void LCD_write4(char data);
static void LCD_busy ();

void LCD_init(int RS_PIN, int RW_PIN, int EN_PIN, int DB7_PIN, LPC210XP_BASE_TC timer_id) {
	// Afectar vari�veis globais do m�dulo
	RS = RS_PIN; RW = RW_PIN; EN = EN_PIN; DB7 = DB7_PIN;
	
	/* Configurar pinos como sa�das */
	GPIO_init(1, RS, 1); 
	GPIO_init(1, RW, 1);
	GPIO_init(1, EN, 1);
	GPIO_init(0xF, DB7 - 3, 4);
	
	GPIO_output(0, RS, 1);
	GPIO_output(0, RW, 1);		
	
	/* Wait for 45 ms or more after VDD reaches 4.5 V */
	TIMER_delay(timer_id, 46);	
	GPIO_output(0x3, DB7-3, 4);
	GPIO_output(1, EN, 1); 		
	GPIO_output(0, EN, 1);
	
	/* Wait for 4,1 ms or more */
	TIMER_delay(timer_id, 5);
	GPIO_output(0x3, DB7-3, 4);
	GPIO_output(1, EN, 1);
	GPIO_output(0, EN, 1);
	
	/* Wait for 0,1 ms or more */
	TIMER_delay(timer_id, 1);
	GPIO_output(0x3, DB7-3, 4);
	GPIO_output(1, EN, 1);	
	GPIO_output(0, EN, 1);
	
	/* Set interface data length to 4 bits */
	GPIO_output(0x2, DB7-3, 4);
	GPIO_output(1, EN, 1);
	GPIO_output(0, EN, 1);
	
	/* Set 1/16 duty and 5x7 dot matrix */	
	LCD_write_cmd4(0x28); /* N = 1; F = 0 */
	
	/* Set display off, hide cursor, don't blink  */			
	LCD_write_cmd4(0x08); /* 1000 -> D = 0; C = 0; B = 0 */
	
	/* Clear display */
	LCD_clear();
	
	/* Entry mode set: Increment, don't shift */		
	LCD_write_cmd4(0x06); /* 0110 -> I/D = 1; S = 0 */
	
	/* Set display on, hide cursor, don't blink */	
	LCD_write_cmd4(0x0c); /* 1100 -> D = 1; C = 0; B = 0 */
	
}

void LCD_write_data4(char data) {
	GPIO_output(1, RS, 1);
	LCD_write4(data);
}
	
void LCD_write_cmd4(char data) {
	GPIO_output(0, RS, 1);
	LCD_write4(data);
}

inline void LCD_clear() {
	LCD_write_cmd4 (0x1);
}

inline void LCD_cursor_home() {
	LCD_write_cmd4 (0x2);
}
	
inline void LCD_gotoxy(int x, int y) {
		LCD_write_cmd4(0x80 + x + (y*0x40));
}
	
static void LCD_write4(char data) {
	GPIO_output(data>>4, DB7-3, 4); // Nibble de ordem superior primeiro
	GPIO_output(0, RW, 1);          // RW = 0 -> Intru��o de Dados
	GPIO_output(1, EN, 1);          // EN = 1 -> Para o LCD assumir o comando
	GPIO_output(0, EN, 1);          // EN = 0 - CCLK operates @ instr/ms, no worries about EN cycle time of 500ns*/
	GPIO_output(data, DB7-3, 4);    // Nibble de ordem superior inferior
	GPIO_output(1, EN, 1);          // EN = 1 -> Para o LCD assumir o comando
	GPIO_output(0, EN, 1);          // EN = 0 - CCLK operates @ instr/ms, no worries about EN cycle time of 500ns*/
	LCD_busy();	
}
	
static void LCD_busy () {
    int delay=0;
	
    GPIO_init(0, DB7, 1);           //Define DB7 como entrada
    GPIO_output(1, RW, 1);          //Activa o RW, intru��o de escrita
    GPIO_output(0, RS, 1);          //Desactiva RS, indica instru��o
	
	  delay=0;                        //Prevencao para falha do LCD
	  GPIO_output(1, EN, 1);          //Activa o Enable
    while (GPIO_input(DB7, 1)==1 && delay++< 5000)
	{
    GPIO_output(0, EN, 1);          //Desactiva o Enable
	  GPIO_output(1, EN, 1);          //Activa o Enable
	  GPIO_output(0, EN, 1);          //Desactiva o Enable
	  GPIO_output(1, EN, 1);          //Activa o Enable
	}

    GPIO_output(0, EN, 1);
    GPIO_output(0, RW, 1);
    GPIO_init(1, DB7, 1);
}

int LCD_print(int x, int y, const char *string) {
	const char *p = string;
	
	// Get string length
	unsigned len = 0;
	while(*p++ != '\0')
		++len;
	
	// Avoid line overflow
	if (x + len > LCD_MAX_CHARS)
		return LCD_LINE_OVERFLOW;
	
	// Print string at (x, y)
	LCD_gotoxy(x, y);	
	
	return LCD_print_direct(string);
}

int LCD_print_direct(const char *p) {

	for( ; *p != '\0' ; ++p)	
		LCD_write_data4(*p);	
	
	return LCD_SUCCESS;
}

void LCD_show_cursor(int show) {
	
	/* Keep display on, show cursor, blink  */			
	if (show)
		LCD_write_cmd4(0x0F); /* 1111 -> D = 1; C = 1; B = 1 */
	else
	/* Keep display on, hide cursor, don't blink */
		LCD_write_cmd4(0x0C); /* 1100 -> D = 1; C = 0; B = 0 */
	
	}
