
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

//Rotinas para o I/F com o GPIO

#include <lpc210x.h>
#include <lpc2106.h>

void GPIO_init(int mode, int first, int size) {
   // Configura��o do modo (0-entrada , 1-saida) de <size> pinos
   // iniciando no pino <first>
   
 	 int mascara;
 /*	 int i;
 	 for(i = 31; i >= 0; --i) {
	 	 mascara <<= 1;
 	 	 mascara += 1;
 	 	if(i <= first && size-- > 0)
 	 		mascara &= 0xFFFFFFFE;
			
 	 }  */
	
	 mascara=~(~(-1<<size)<<first);
	 // Cria uma mascara do tipo 0xFFFxxxFF, com 0 nos <size> bits
	 // iniciando em <first> e os restantes a 1 

   LPC2106_BASE_GPIO0->IODIR&= mascara;
   // Efectua-se um AND com o valor do registo IODIR de modo a preservar os
   // valores j� configurados 
  	 
   LPC2106_BASE_GPIO0->IODIR |= mode << first;
   // Efectua-se um OR com o registo IODIR para configurar os pinos definidos
}

void GPIO_output(int value, int first, int size) {

	//envia o valor <value> para os <size> pinos a partir do <first>

 	 int mascara;
 /*	 int i;
	 for(i = 31; i >= 0; --i) {
	 	mascara <<= 1; 	 	
 	 	if(i <= first + size - 1 && size-- > 0)
	 	 	mascara += 1; 	 	
 	 } */
	
   mascara=~(-1<<size)<<first;
   // Cria uma mascara do tipo 0x000xxx00, com 0 nos <size> bits
	 // iniciando em <first> e os restantes a 1 
	 
 	 LPC2106_BASE_GPIO0->IOSET = mascara & (value << first);
 	 // Afecta-se o registo SET colocando a 1 os bits pretendidos activar
 	 
 	 LPC2106_BASE_GPIO0->IOCLR = mascara & (~value << first);
 	 // Afecta-se o registo CLR colocando a 1 os bits pretendidos desactivar
 	 
}

int GPIO_input(int first, int size) {
	//Retorna o valor nos <size> pinos a partir do <first>
	
 	 int mascara;
 /*	 int i;
	 for(i = 31; i >= 0; --i) {
		mascara <<= 1; 	 	
 	 	if(i <= first + size - 1 && size-- > 0)
	 	 	mascara += 1; 	 	
 	 } */
	
	 mascara=~(-1<<size)<<first;
	 // Cria uma mascara do tipo 0x000xxx00, com 0 nos <size> bits
	 // iniciando em <first> e os restantes a 1 
	 
	 return (LPC2106_BASE_GPIO0->IOPIN & mascara)>> first;
	 // Utiliza-se a mascara criada para obter o estado dos bits definidos
	 // por <size> e <first>
}
