
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#include <lpc2106.h>
#include <i2c.h>

/******************** 
 Master Mode only !!! 
********************/

#define PIN_SCL 2
#define PIN_SDA 3
#define I2C_FREQ_DIV 800  /* I2C Frequency = PCLK / (SCLL + SCLH )
															= PCLK / I2C_FREQ_DIV 
                             MAX = 400 kHZ                          */

/**************************************************  
I2C registers
**************************************************/
/* I2CONSET register
 *   
 *   7   6    5    4    3    2    1   0
 * | - |I2EN|STA |STO | SI | AA | - | - |
 * 
 * AA - Assert Ack Flag:	when '1' an ACK is tx; NACK in case of '0'	
 * SI - Interrupt Flag:		set when the I2C state changes; must be reset by software. 
 * 							State "IDLE" does not set SI
 * STO - STOP flag:			setting causes the tx of a STOP condition in master mode, 
 * 							or recover from an error in slave mode. When the bus detects
							the STOP condition, STO is cleared automatically.
 * STA - START flag:		when '1' I/F enters master mode and tx a START condition 
 * 							or a repeated START if it is already in master mode
 * I2EN - I2C I/F Enable:	when '1', the I2C interface is enabled
 */
#define I2C_AA	2
#define I2C_SI	3
#define I2C_STO	4
#define I2C_STA	5
#define I2C_EN	6

/* I2CONCLR register (affects I2CONSET register)
 *  
 *   7    6    5    4    3    2   1   0
 * | - |I2ENC|STAC| - |SIC |AAC | - | - | 
 * 
 * AAC - Assert Ack Clear:	writing '1' clears the AA bit; '0' has no effect
 * SIC - Interrupt Clear:	writing '1' clears the SI bit; '0' has no effect
 * STAC - Start flag Clear:	writing '1' clears the STA bit; '0' has no effect
 * I2ENC - I2C I/F Disable:	writing '1' clears the I2EN bit; '0' has no effect
 */

/* I2STAT (read-only)
 *   7 to 3   2 to 0
 * | status |   0   |
 * 26 possible status codes, following described only for Master Mode
  * Abbreviations:
  * S Start Condition
  * SLA 7-bit slave address
  * R Read bit (high level at SDA)
  * W Write bit (low level at SDA)
  * A Acknowledge bit (low level at SDA)
  * NA Not acknowledge bit (high level at SDA)
  * Data 8-bit data byte
  * P Stop condition 
 */ 
/* Master TX/RX mode status codes */
#define S 0x08 			// START condition has been tx
#define S_S 0x10 		// repeated START condition has been tx
#define SLA_W_A 0x18 	// SLA+W transmitted; ACK received
#define SLA_W_NA 0x20 	// SLA+W transmitted; NACK received
#define TX_DATA_A 0x28 	// Data byte transmitted; ACK received
#define TX_DATA_NA 0x30 // Data byte transmitted; NACK received
#define ARB_LOST 0x38 	// Arbitration lost in SLA+R/W or Data bytes (TX) or in NACK (RX)
#define SLA_R_A 0x40 	// SLA+R transmitted; ACK received
#define SLA_R_NA 0x48 	// SLA+R transmitted; NACK received
#define RX_DATA_A 0x50 	// Data byte received; ACK transmitted
#define RX_DATA_NA 0x58 // Data byte received; NACK transmitted
#define IDLE 0xF8		// no information is available because the SI is not yet set
#define ERR 0x00		// Bus error
/* I2DAT 
 * Contains byte to be transmitted or just received; 8 bits
 * It is accessible only when SI bit is set 
*/
/* I2ADR 
 * Slave address; 8 bits.
 * Only used when an I2C interface is set to slave mode. 
 * In master mode, this register has no effect. 
 * The LSB of I2ADR is the general call bit. 
 * When this bit is set, the general call address (0x00) is recognized. 
*/
/* I2SCLH & I2SCLL
 * Frequency set regs; 16 bits each.
 */

/* R/W bit */
#define I2C_READ	1
#define I2C_WRITE	0

void i2c_init() {
	
	/* Power on I2C peripheral */
	LPC2106_BASE_PCON->PCONP |= 0x80;
	/* Select I"C function for SCL and SDA pins*/
	LPC2106_BASE_PCB0->PINSEL0 |= ((1<<(PIN_SDA*2) | 1<<(PIN_SCL*2)));
	/* Clear all bits in I2CONSET */
	LPC2106_BASE_I2C->I2CONCLR = 0X6C;
	/* Set frequency */
	LPC2106_BASE_I2C->I2SCLH = (I2C_FREQ_DIV * 2/3);
	LPC2106_BASE_I2C->I2SCLL = (I2C_FREQ_DIV * 1/3); // 66% duty cycle
	/* Enable I/F */
	LPC2106_BASE_I2C->I2CONSET = 1<<I2C_EN;
	
}


int i2c_write_bytes(int nbytes, char address, const void *data) {
	
	int flag = 1; // 1: OK - 0: NOK
	char *p = (char*) data;
	enum State { START, TX_ADDR, TX_DATA, ERROR, END };
  enum State state = START;
	int exit = 0;
	
	while(!exit) {
			switch(state) {
                        
        case START:
        	if(nbytes==0) {
        		exit = 1;
        		break;
        	}        		
          // enter master mode and tx a START condition
          LPC2106_BASE_I2C->I2CONSET = 1<<I2C_STA;
					// wait until next event on bus
					while((LPC2106_BASE_I2C->I2CONSET & (1<<I2C_SI)) != (1<<I2C_SI));
					if(LPC2106_BASE_I2C->I2STAT == S) // START transmitted
          	state = TX_ADDR;
          else 
          	state = ERROR;
          break;
          
        case TX_ADDR:
        	// set SLA and W
        	LPC2106_BASE_I2C->I2DAT = (address<<1 | I2C_WRITE);
        	// clear START and SI
        	LPC2106_BASE_I2C->I2CONCLR = (1<<I2C_STA | 1<<I2C_SI);
        	// wait until next event on bus
        	while((LPC2106_BASE_I2C->I2CONSET & (1<<I2C_SI)) != (1<<I2C_SI));
        	if(LPC2106_BASE_I2C->I2STAT == SLA_W_A) // SLA+W transmitted and ACK received
        		state = TX_DATA;
        	else
        		state = ERROR;
        	break;
        		
        case TX_DATA:
					// set byte
					LPC2106_BASE_I2C->I2DAT = *p;
					// clear SI
					LPC2106_BASE_I2C->I2CONCLR = 1<<I2C_SI;
					// wait until next event on bus
					while((LPC2106_BASE_I2C->I2CONSET & (1<<I2C_SI)) != (1<<I2C_SI));
					if (LPC2106_BASE_I2C->I2STAT == TX_DATA_A) { // byte transmitted and ACK received
						nbytes--;
						state = nbytes ? TX_DATA : END;
						p++;
					}
					else {
						state = ERROR;
					}
					break;
				
				case ERROR:
					flag = 0;
					
				case END:
					// I2C_AA is for Multi-Master buses
					// send STOP, leave bus free
					LPC2106_BASE_I2C->I2CONSET = (1<<I2C_STO | 1<<I2C_AA);
					// clear SI
					LPC2106_BASE_I2C->I2CONCLR = 1<< I2C_SI;
					exit = 1;
		}
	}
	return flag;
}


int i2c_read_bytes(int nbytes, char address, void *data ) {
	int flag = 1; // 1: OK - 0: NOK
	char *p = (char*) data;
	enum State { START, TX_ADDR, RX_DATA, ERROR, END };
  enum State state = START;
	int exit = 0;
	
	while(!exit) {
			switch(state) {
                        
        case START:
        	if(nbytes==0) {
        		exit = 1;
        		break;
        	}        		
          // enter master mode and tx a START condition
          LPC2106_BASE_I2C->I2CONSET = 1<<I2C_STA;
					// wait until next event on bus
					while((LPC2106_BASE_I2C->I2CONSET & (1<<I2C_SI)) != (1<<I2C_SI));
					if(LPC2106_BASE_I2C->I2STAT == S) // START transmitted
          	state = TX_ADDR;
          else 
          	state = ERROR;
          break;
          
        case TX_ADDR:
        	// set SLA and W
        	LPC2106_BASE_I2C->I2DAT = (address<<1 | I2C_READ);
        	// clear START and SI
        	LPC2106_BASE_I2C->I2CONCLR = (1<<I2C_STA | 1<<I2C_SI);
        	// wait until next event on bus
        	while((LPC2106_BASE_I2C->I2CONSET & (1<<I2C_SI)) != (1<<I2C_SI));
        	if(LPC2106_BASE_I2C->I2STAT == SLA_R_A) // SLA+R transmitted and ACK received
        		state = RX_DATA;
        	else
        		state = ERROR;
        	break;		
        		
        case RX_DATA:	
        	// ACK will be sent
        	LPC2106_BASE_I2C->I2CONSET = 1<<I2C_AA;
        	if(nbytes == 1)
        		// NACK will be sent
        		LPC2106_BASE_I2C->I2CONCLR = 1<<I2C_AA;
					LPC2106_BASE_I2C->I2CONCLR = 1<<I2C_SI;
					while((LPC2106_BASE_I2C->I2CONSET & (1<<I2C_SI)) != (1<<I2C_SI)); // wait until next event on bus
					// wait until byte is received and ACK/NACK sent
					if(LPC2106_BASE_I2C->I2STAT == RX_DATA_A || LPC2106_BASE_I2C->I2STAT == RX_DATA_NA) {
						nbytes--;
						state = nbytes ? RX_DATA : END;
						*p++ = LPC2106_BASE_I2C->I2DAT;
					}
					else {
						state = ERROR;
					}
					break;

				case ERROR:
					flag = 0;
					
				case END:
					// I2C_AA is for Multi-Master buses
					// send STOP, leave bus free
					LPC2106_BASE_I2C->I2CONSET = (1<<I2C_STO | 1<<I2C_AA);
					// clear SI
					LPC2106_BASE_I2C->I2CONCLR = 1<< I2C_SI;
					exit = 1;
		}
	}
	return flag;	
}
