
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Luís Brás			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

/**************************************************  
MAXIM DS1621 Digital Thermometer and Thermostat
**************************************************/

#include <ds1621.h>
#include <i2c.h>



/**************************************************  
DS1621 configuration/status
**************************************************/
/* Configuration/status register				  */
/*   7    6    5    4    3    2    1    0     */
/* |Done|THF |TLF |NVB | X  | X  |POL |1SHOT| */
#define DS1621_Config1SHOT 	0x01 // Coversion: "1" = single, "0" = continuos
#define DS1621_ConfigNVB	0x10 // Memory Busy flag: “1” = busy, “0” = not busy
#define DS1621_ConfigPOL	0x02 // Output polarity: “1” = active high, “0” = active low
#define DS1621_StatusTHF	0x40 // "1" when T>=TH, reset writing "0"
#define DS1621_StatusTLF	0x20 // "1" when T<=TL, reset writing "0"
#define DS1621_StatusDONE	0x80 // Conversion status: “1” = complete, “0” = in progress

/**************************************************  
DS1621 command set
**************************************************/
#define  AccessConfig	0xAC    // R/W configuration data
/* Temperature commands */   
#define  ReadTemp		0xAA    // Read last converted temperature
#define  ReadCounter	0xA8    // Read value of Count_Remain
#define  ReadSlope		0xA9    // Read value of Count_Per_C
#define  StartConvT		0xEE    // Start temperature conversion
#define  StopConvT		0x22    // Halts temperature convarsion
/* Thermostat commands */
#define  AccessTH		0xA1    // R/W high temperature value
#define  AccessTL		0xA2    // R/W low temperature value


void DS1621_config(char config_code, char address) {
			
	char data[] = { AccessConfig, config_code};
	i2c_write_bytes(2, address, (void*) data);

}

void DS1621_start_conversion(char address) {
	
	char temp = StartConvT;
	i2c_write_bytes(1, address, (void*) &temp);
	
}

int  DS1621_read_status(char address) {
	
	char data[1];
	char temp = AccessConfig;
	if (i2c_write_bytes(1, address, (void*) &temp) == 0)
		return -1;
	if (i2c_read_bytes(1, address, data) == 0)
		return -1;
	return data[0];
	
}

int DS1621_read_temperature(char address) {
	
	int temperature = 0;
	char data[2];
	char temp = ReadTemp;
	if (i2c_write_bytes(1, address, (void*) &temp) == 0)
		return -1;
	if (i2c_read_bytes(2, address, (void*) data) == 0)
		return -1;

	return temperature = (data[0]<<8) + data[1];
	
}

void DS1621_conv_str (int temperatura, char *string)
{
    char *p = string;
    char temp;
    int centenas=0;
    int dezenas=0;
    int unidades=0;
    
    temp = (char)( (temperatura>>8) & 0xff );  /* Conversão do valor de temperatura */
    
    if ((temp & 0x80) == 0x80) {               /* Leitura negativa ? */
        *p++='-';
        temp = temp * (-1);                    /* converte para positivo */
    }
    else {                                     /* Leitura positiva */
        *p++='+';
    }

    
    while (unidades <= temp) {
        if (dezenas == 10) {
          centenas++;
          dezenas=0;
        }
           
        if (unidades == 10) {
          dezenas++;
          unidades = 0;
          temp = temp - 10;
        }
        unidades++;
    }
    unidades--;
    
    if (centenas!=0)
    *p++=( '0' + centenas );    /* converte temperatura em ASCII as centenas */
    *p++=( '0' + dezenas );     /* converte temperatura em ASCII as dezenas */    
    *p++=( '0' + unidades );    /* converte temperatura em ASCII as dezenas */   

    *p++='.';                                      /* coloca ponto */
	*p++=( (temperatura & 0x80) == 0x80 ? '5' : '0' );      /* meio grau */
    *p='\0';
    
    return;
}
