
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

/* Rotinas para a PLL */
#include "lpc210x.h"
#include "lpc2106.h"

void pll_init(int P,int M)
   {
/*	int temp=((P-1)<<5 | (M-1)); */

    LPC2106_BASE_PLL->PLLCFG=((P-1)<<5 | (M-1));  /* Programa P e M */
    LPC2106_BASE_PLL->PLLCON=1;           /* PLL Ligado & CCLK=OSC  */
    LPC2106_BASE_PLL->PLLFEED=0xAA;       /* Seq. para efectivar a  */
    LPC2106_BASE_PLL->PLLFEED=0x55;	      /*  escrita no PLLCON     */

    //Espera sincronismo	
    while(!(LPC2106_BASE_PLL->PLLSTAT&(1<<10))); 

    LPC2106_BASE_PLL->PLLCON=3;         /* PLL Ligado & CCLK=PLL    */
    LPC2106_BASE_PLL->PLLFEED=0xAA;     /* Seq. para efectivar a    */
    LPC2106_BASE_PLL->PLLFEED=0x55;	    /*  escrita no PLLCON       */
   }
	
