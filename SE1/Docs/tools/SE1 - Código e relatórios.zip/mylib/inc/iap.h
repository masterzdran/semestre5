
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __IAP__H__
#define __IAP__H__

#include "lpc210x.h"

#define  IAP_UPDATE_CODE_ADDR 0x80001000		 
#define  SECTOR_SIZE (8*1024)
#define	 LPC2106_FLASH_BASE_ADDR 0

void (*iap_entry) (int iap_command[], int iap_result[]);

/************************************************************************* 
* Function Name: IAP_PrepareSec 
* Parameters: int StartSecNum -- Start Sector Number 
*			  int EndSecNum -- End Sector Number 
* Return: none
* 
* Description: This command must be executed before executing "Copy RAM 
* to Flash" or "Erase Sector(s)" command. To prepare a single sector 
* use the same "Start" and "End" sector numbers.
*************************************************************************/
void IAP_PrepareSec (int StartSecNum, int EndSecNum);


/************************************************************************* 
* Function Name: IAP_FlashWrite
* Parameters: int dst -- Destination Flash address, should be a 256 byte 
* 						 boundary.
*			  int src -- Source RAM address, should be a word boundary 
*			  int number -- 256 | 512 |1024 |4096
*			  int clk -- System Clock frequency (CCLK) in Hz
* Return: none
* 
* Description: This command is used to program the flash memory.
*************************************************************************/
int IAP_FlashWrite (int dst, int src,int size, int clk);


/*************************************************************************
* Function Name: IAP_EraseSec 
* Parameters: int StartSecNum -- Start Sector Number 
*			  int EndSecNum -- End Sector Number 
*			  int clk -- System Clock frequency (CCLK) in KHz
* Return: none 
* 
* Description: This command is used to erase a sector or multiple sectors 
* on the on-chip Flash memory. 
*************************************************************************/
int IAP_EraseSec (int StartSecNum, int EndSecNum, int clk);


/*************************************************************************
* Function Name: IAP_BlankCheckSec
* Parameters: int StartSecNum -- Start Sector Number 
*			  int EndSecNum -- End Sector Number 
* Return: none
*  
* iap_result[0]: Offset of the first non blank word location if the 
* 				 Status Code is SECTOR_NOT_BLANK.
* iap_result[1]: Contents of non blank word location.
* 
* Description: This command is used to blank check a sector or multiple 
* sectors of the on-chip Flash. To check a single sector use the same 
* "Start" and "End" sector numbers.
*************************************************************************/
void IAP_BlankCheckSec (int StartSecNum, int EndSecNum);


/*************************************************************************
* Function Name: IAP_ReadPartID
* Parameters: none
* Return: int iap_result[0]-- Part Identification Number
* 
* Description: This command is used to read the part identification number
*************************************************************************/
int IAP_ReadPartID ();


/*************************************************************************
* Function Name: IAP_BootCodeID
* Parameters: none
* Return: int iap_result[0] -- 2 bytes of boot code version number 
* 		  in ASCII format. It is to be interpreted as 
* 		  <byte1(Major)>.<byte0(Minor)>
* 
* Description: This command is used to read the boot code version number
*************************************************************************/
int IAP_BootCodeID ();


/*************************************************************************
* Function Name: IAP_Compare
* Parameters: int dst -- Destination Flash or RAM address 
*			  int src -- Source RAM or Flash address 
*			  int number -- Number of bytes to be compared (should be
* 							a mutilple of 4
* 
* Description: This command is used to compare the memory contents 
* at two different locations. 
*************************************************************************/
void IAP_Compare (int dst, int src, int number);

#endif
