
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __RTC__H__
#define __RTC__H__


/*
RTC-prescaler according to user's manual
PCLK  => must be greater than or equal 65.536 KHz
PREINT = int (PCLK / 32768) - 1 => [1 4881]
PREFRAC = PCLK - ((PREINT +1) x 32768) => [0 32767]
*/

/* PCLK defined in system.h */
#define myPREINT ((LPC2106_PCLK/32768)-1)
#define myPREFRAC (LPC2106_PCLK-((myPREINT+1)*32768))

/* AMR Flags*/
#define AMRSEC 		0x1 /* the Second value is compared for the alarm */
#define AMRMIN  	0x2 /* the Minutes value is compared for the alarm */
#define AMRHOUR  	0x4 /* the Hour value is compared for the alarm */
#define AMRDOM  	0x8 /* the Day of Month value is compared for the alarm */
#define AMRDOW  	0x10 /* the Day of Week value is compared for the alarm */
#define AMRDOY  	0x20 /* the Day of Year value is compared for the alarm */
#define AMRMON  	0x40 /* the Month value is compared for the alarm */
#define AMRYEAR  	0x80 /* the Year value is compared for the alarm */

/* filters */ 
#define TIME		AMRHOUR | AMRMIN | AMRSEC /* hh:mm:ss */
#define DATE_TIME	AMRYEAR | AMRMON | AMRDOM | AMRHOUR | AMRMIN | AMRSEC /* yy:MM:dd hh:mm:ss*/

typedef struct _RTCTime {
  char hh;    	/* Hour value - [0,23] */
  char mm;		/* Minute value - [0,59] */
  char ss;		/* Second value - [0,59] */ 
  char dow;  	/* Day of week value - [0,6] */ 
  short yyyy;   /* Year value - [0,4095] */
  short doy;    /* Day of year value - [1,365|366] */
  char MM;     	/* Month value - [1,12] */
  char dd;    	/* Day of the month value - [1,28|29|30|31] */
} RTCTime;

void rtc_init();
void rtc_SetTime(char hours, char minutes, char seconds);
void rtc_SetDate(char day, char month, short year);
void rtc_SetDOW(short dayOfWeek);
void rtc_GetTimeStamp(RTCTime *time_struct);
void rtc_SetAlarm (const RTCTime *t, char alarm_filter);
int rtc_ReadAlarm();
void rtc_SetAlarmInterval(int minutes);
int dateTimeComparator(const RTCTime *dt1, const RTCTime *dt2);

#endif
