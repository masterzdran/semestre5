
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __LPC2106__H__
#define __LPC2106__H__

#include "lpc210x.h"

// I2C pins
#define SCL_PIN 2
#define SDA_PIN 3

#define LPC2106_BASE_TC0 	((LPC210XP_BASE_TC) 	0xE0004000)
#define LPC2106_BASE_TC1 	((LPC210XP_BASE_TC) 	0xE0008000)
#define LPC2106_BASE_I2C 	((LPC210XP_BASE_I2C) 	0xE001C000)
#define LPC2106_BASE_RTC 	((LPC210XP_BASE_RTC) 	0xE0024000)
#define LPC2106_BASE_GPIO0 	((LPC210XP_BASE_GPIO) 	0xE0028000)
#define LPC2106_BASE_PCB0 	((LPC210XP_BASE_PCB) 	0xE002C000)
#define LPC2106_BASE_PLL 	((LPC210XP_BASE_PLL) 	0xE01FC080)
#define LPC2106_BASE_PCON 	((LPC210XP_BASE_PCON) 	0xE01FC0C0)
#define LPC2106_BASE_APBDIV_REG ((LPC210X_REG*) 	0xE01FC100)

#endif
