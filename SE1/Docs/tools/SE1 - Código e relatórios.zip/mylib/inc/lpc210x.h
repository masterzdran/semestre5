
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Luís Brás			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __LPC210X__H__
#define __LPC210X__H__

typedef unsigned int LPC210X_REG;

typedef struct _LPC210X_BASE_GPIO{
	LPC210X_REG IOPIN;	/* PIN Value */
	LPC210X_REG IOSET;	/* Pin Output SET */
	LPC210X_REG IODIR;	/* Pin DIRection */
	LPC210X_REG IOCLR;	/* Pin Output CLeaR */
}LPC210X_BASE_GPIO,*LPC210XP_BASE_GPIO;

typedef struct _LPC210X_BASE_PCB{
	LPC210X_REG PINSEL0;	/* PIN Function SELect 0 */
	LPC210X_REG PINSEL1;	/* PIN Function SELect 1 */
}LPC210X_BASE_PCB,*LPC210XP_BASE_PCB;

typedef struct _LPC210X_BASE_PCON{
	LPC210X_REG PCON;	/* Power CONtrol register */
	LPC210X_REG PCONP;	/* Power CONtrol Peripherals register */
}LPC210X_BASE_PCON,*LPC210XP_BASE_PCON;

typedef struct _LPC210X_BASE_TC {
	LPC210X_REG IR;		/* Interrupt Register */
	LPC210X_REG TCR;	/* Timer Control Register */
	LPC210X_REG TC;		/* Timer Counter */
	LPC210X_REG PR;		/* Prescale Register */
	LPC210X_REG PC;		/* Prescale Counter */
	LPC210X_REG MCR;	/* Match Control Register */
	LPC210X_REG MR0;	/* Match Register 0 */
	LPC210X_REG MR1;	/* Match Register 1 */
	LPC210X_REG MR2;	/* Match Register 2 */
	LPC210X_REG MR3;	/* Match Register 3 */
	LPC210X_REG CCR;	/* Capture Control Register */
	LPC210X_REG CR0;	/* Capture Register 0 */
	LPC210X_REG CR1;	/* Capture Register 1 */
	LPC210X_REG CR2;	/* Capture Register 2 */
	LPC210X_REG CR3;	/* Capture Register 3 */
	LPC210X_REG EMR;	/* External Match Register */
	LPC210X_REG CTCR;	/* CounT Control Register */
} LPC210X_BASE_TC, *LPC210XP_BASE_TC;

typedef struct _LPC210X_BASE_PLL {
	LPC210X_REG PLLCON;		/* CONtrol */
	LPC210X_REG PLLCFG;		/* ConFiGuration */
	LPC210X_REG PLLSTAT;	/* STATus */
	LPC210X_REG PLLFEED;	/* FEED */
}LPC210X_BASE_PLL,*LPC210XP_BASE_PLL;

typedef struct _LPC210X_BASE_I2C {
	LPC210X_REG I2CONSET; 	/* Control Set Register */     
	LPC210X_REG I2STAT;		/* STATus Register */
	LPC210X_REG I2DAT;		/* DATa Register */
	LPC210X_REG I2ADR;		/* Slave ADdress Register */
	LPC210X_REG I2SCLH;		/* SCL Duty Cycle Register - High */
	LPC210X_REG I2SCLL;		/* SCL Duty Cycle Register - Low */
	LPC210X_REG I2CONCLR; 	/* CONtrol CLear Register */
}LPC210X_BASE_I2C,*LPC210XP_BASE_I2C;

typedef struct _LPC210X_BASE_RTC {
	/* Miscellaneous Register Group */
	LPC210X_REG ILR; 		/* Interrupt Location Register */
	LPC210X_REG CTC;		/* Clock Tick Counter */
	LPC210X_REG CCR;		/* Clock Control Register */
	LPC210X_REG CIIR;		/* Counter Increment Interrup Register */
	LPC210X_REG AMR;		/* Alarm Mask Register */
	LPC210X_REG CTIME0;		/* Consolidated Time register 0 */
	LPC210X_REG CTIME1;		/* Consolidated Time register 1 */
	LPC210X_REG CTIME2;		/* Consolidated Time register 2 */
	/* Time Counter Group */
	LPC210X_REG SEC;		/* SEConds counter */
	LPC210X_REG MIN;		/* MINutes register */
	LPC210X_REG HOUR;		/* HOURs register */
	LPC210X_REG DOM;		/* Day Of Month register */
	LPC210X_REG DOW;		/* Day Of Week register */
	LPC210X_REG DOY;		/* Day Of Year register */
	LPC210X_REG MONTH;		/* MONTH register */
	LPC210X_REG YEAR;		/* YEAR register */
	/* DUMMY 32B */
	LPC210X_REG dummy[8];
	
	/* Alarm Register Group */
	LPC210X_REG ALSEC;		/* ALarm value for SEConds */
	LPC210X_REG ALMIN;		/* ALarm value for MINutes */
	LPC210X_REG ALHOUR;		/* ALarm value for HOURs */
	LPC210X_REG ALDOM;		/* ALarm value for Day Of Month */
	LPC210X_REG ALDOW;		/* ALarm value for Day Of Week */
	LPC210X_REG ALDOY;		/* ALarm value for Day Of Year */
	LPC210X_REG ALMON;		/* ALarm value for MONths */
	LPC210X_REG ALYEAR;		/* ALarm value for YEAR */
	/* Reference Clock Divider Group */
	LPC210X_REG PREINT;		/* PREscaler value, INTeger portion */
	LPC210X_REG PREFRAC;	/* PREscaler value, FRACtion portion */
}LPC210X_BASE_RTC,*LPC210XP_BASE_RTC;

#endif
