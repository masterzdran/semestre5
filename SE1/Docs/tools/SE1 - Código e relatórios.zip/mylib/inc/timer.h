
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __TIMER_H_
#define __TIMER_H_

#include <lpc210x.h>

void TIMER_init(LPC210XP_BASE_TC timer_id , unsigned int period);
void TIMER_start(LPC210XP_BASE_TC timer_id);
void TIMER_stop(LPC210XP_BASE_TC timer_id);
unsigned TIMER_elapsed(LPC210XP_BASE_TC timer_id, unsigned int start_time);
void TIMER_delay(LPC210XP_BASE_TC timer_id, unsigned int delay);
void TIMER_reset (LPC210XP_BASE_TC timer_id);

#endif
