
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __TECLADO__H__
#define __TECLADO__H__

void teclado_init(int P_COL0, int P_LIN0);
int teclado_getKey();
int teclado_getKey_inst();
int teclado_scanKey();
void get_key_teclado (int* keys, int num_char );

#endif
