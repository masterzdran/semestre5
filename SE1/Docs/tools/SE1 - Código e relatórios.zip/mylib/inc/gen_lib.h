
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __GEN_LIB_H__
#define __GEN_LIB_H__

#include <timer.h>

void bit_set(unsigned *address , int bit);
void bit_clear(unsigned *address , int bit);

void toggle(unsigned pin, unsigned state, unsigned n, unsigned period, LPC210XP_BASE_TC timer_id);
int memcmp ( const void *s1 , const void *s2, int size);
void memcpy(void *dst , const void *src, int size);

void memset ( void *ptr, char value, int num );

void strreverse(char* begin, char* end);
void itoa(int value, char* str, int base,int width,int show_sign);
char *strcat(char *dest, const char *src);


#endif
