
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __DS1621__H__
#define __DS1621__H__

void DS1621_config(char config_code, char address);
inline void DS1621_start_conversion(char address);
int  DS1621_read_status(char address);
int DS1621_read_temperature (char address);
void DS1621_conv_str (int temperatura, char *string);

#endif
