
/***
 * ISEL :: Sistemas Embebidos 1 :: Semestre Inverno 2009/2010             
 * Desenvolvido por:                                                      
 * 27401 Lu�s Br�s			:: LEIC / LI51N :: lbras@alunos.isel.ipl.pt
 * 28173 Tiago Rodrigues	:: MEET / MT11N :: a32348@alunos.isel.pt
 * 32348 Alessandro Floris	:: MEET / MT11N :: afloris@alunos.isel.ipl.pt 
 */

#ifndef __LCD__H__
#define __LCD__H__

#include "timer.h"

#define LCD_MAX_CHARS 16

enum { LCD_SUCCESS, LCD_LINE_OVERFLOW }; /* define LCD_SUCCESS=0 , LCD_LINE_OVERFLOW=1 */

void LCD_init(int RS_PIN, int RW_PIN, int EN_PIN, int DB7_PIN, LPC210XP_BASE_TC timer_id);
void LCD_write_data4(char data);
void LCD_write_cmd4(char data);
inline void LCD_clear();
inline void LCD_cursor_home();
inline void LCD_gotoxy(int x, int y);
int LCD_print(int x, int y, const char *string);
int LCD_print_direct(const char *string);
void LCD_show_cursor(int show);

#endif
